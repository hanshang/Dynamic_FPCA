rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

AUS_dummy = extract.ages(hmd.mx(country = "AUS", username = "shl8858@telstra.com", password = "hshang85", label = "AUS"), 0:100)
AUS_demo = extract.years(AUS_dummy, 1950:max(AUS_dummy$year))
AUS_smooth = smooth.demogdata(AUS_demo)
n_year = length(AUS_demo$year)

# convert non-stationary series to stationary series

AUS_female_ratio = AUS_male_ratio = AUS_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    AUS_female_ratio[,ik-1] = 2 * (1 - AUS_demo$rate$female[,ik]/AUS_demo$rate$female[,ik-1])/(1 + AUS_demo$rate$female[,ik]/AUS_demo$rate$female[,ik-1])
    AUS_male_ratio[,ik-1]   = 2 * (1 - AUS_demo$rate$male[,ik]/AUS_demo$rate$male[,ik-1])/(1 + AUS_demo$rate$male[,ik]/AUS_demo$rate$male[,ik-1])
    AUS_total_ratio[,ik-1]   = 2 * (1 - AUS_demo$rate$total[,ik]/AUS_demo$rate$total[,ik-1])/(1 + AUS_demo$rate$total[,ik]/AUS_demo$rate$total[,ik-1])
}  

AUS_female_smooth_ratio = AUS_male_smooth_ratio = AUS_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    AUS_female_smooth_ratio[,ik-1] = 2 * (1 - AUS_smooth$rate$female[,ik]/AUS_smooth$rate$female[,ik-1])/(1 + AUS_smooth$rate$female[,ik]/AUS_smooth$rate$female[,ik-1])
    AUS_male_smooth_ratio[,ik-1]   = 2 * (1 - AUS_smooth$rate$male[,ik]/AUS_smooth$rate$male[,ik-1])/(1 + AUS_smooth$rate$male[,ik]/AUS_smooth$rate$male[,ik-1])
    AUS_total_smooth_ratio[,ik-1]   = 2 * (1 - AUS_smooth$rate$total[,ik]/AUS_smooth$rate$total[,ik-1])/(1 + AUS_smooth$rate$total[,ik]/AUS_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(AUS_female_ratio); T_stationary(AUS_male_ratio); T_stationary(AUS_total_ratio) # 0.103 0.027 0.076
T_stationary(AUS_female_smooth_ratio); T_stationary(AUS_male_smooth_ratio); T_stationary(AUS_total_smooth_ratio) # 0.344 0.085 0.145

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

AUS_smooth_dpca_arima_female = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_pca_arima_female = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_female_err = rbind(AUS_smooth_dpca_arima_female$err, AUS_smooth_pca_arima_female$err)
rownames(AUS_smooth_female_err) = c("DPCA", "PCA")


# fh = 5

AUS_smooth_dpca_arima_female_fh_5 = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_pca_arima_female_fh_5 = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_female_err_fh_5 = rbind(AUS_smooth_dpca_arima_female_fh_5$err, AUS_smooth_pca_arima_female_fh_5$err)
rownames(AUS_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_smooth_dpca_arima_female_fh_10 = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_pca_arima_female_fh_10 = dpca_res(data = AUS_female_smooth_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_female_err_fh_10 = rbind(AUS_smooth_dpca_arima_female_fh_10$err, AUS_smooth_pca_arima_female_fh_10$err)
rownames(AUS_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

AUS_smooth_dpca_arima_male = dpca_res(data = AUS_male_smooth_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_pca_arima_male = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_male_err = rbind(AUS_smooth_dpca_arima_male$err, AUS_smooth_pca_arima_male$err)
rownames(AUS_smooth_male_err) = c("DPCA", "PCA")

# fh = 5 

AUS_smooth_dpca_arima_male_fh_5 = dpca_res(data = AUS_male_smooth_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_pca_arima_male_fh_5 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_male_err_fh_5 = rbind(AUS_smooth_dpca_arima_male_fh_5$err, AUS_smooth_pca_arima_male_fh_5$err)
rownames(AUS_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_smooth_dpca_arima_male_fh_10 = dpca_res(data = AUS_male_smooth_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_pca_arima_male_fh_10 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_male_err_fh_10 = rbind(AUS_smooth_dpca_arima_male_fh_10$err, AUS_smooth_pca_arima_male_fh_10$err)
rownames(AUS_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

AUS_smooth_dpca_arima_total = dpca_res(data = AUS_total_smooth_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_pca_arima_total = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUS_smooth_total_err = rbind(AUS_smooth_dpca_arima_total$err, AUS_smooth_pca_arima_total$err)
rownames(AUS_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

AUS_smooth_dpca_arima_total_fh_5 = dpca_res(data = AUS_total_smooth_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_pca_arima_total_fh_5 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUS_smooth_total_err_fh_5 = rbind(AUS_smooth_dpca_arima_total_fh_5$err, AUS_smooth_pca_arima_total_fh_5$err)
rownames(AUS_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_smooth_dpca_arima_total_fh_10 = dpca_res(data = AUS_total_smooth_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_pca_arima_total_fh_10 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUS_smooth_total_err_fh_10 = rbind(AUS_smooth_dpca_arima_total_fh_10$err, AUS_smooth_pca_arima_total_fh_10$err)
rownames(AUS_smooth_total_err_fh_10) = c("DPCA", "PCA")


####################
# Lee-Carter method
####################

## female series

# fh = 1

AUS_dpca_arima_female = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

AUS_pca_arima_female = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

AUS_female_err = rbind(AUS_dpca_arima_female$err, AUS_pca_arima_female$err)
rownames(AUS_female_err) = c("DPCA", "PCA")

# fh = 5

AUS_dpca_arima_female_fh_5 = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

AUS_pca_arima_female_fh_5 = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

AUS_female_err_fh_5 = rbind(AUS_dpca_arima_female_fh_5$err, AUS_pca_arima_female_fh_5$err)
rownames(AUS_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_dpca_arima_female_fh_10 = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

AUS_pca_arima_female_fh_10 = dpca_res(data = AUS_female_ratio, test_data = AUS_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = AUS_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

AUS_female_err_fh_10 = rbind(AUS_dpca_arima_female_fh_10$err, AUS_pca_arima_female_fh_10$err)
rownames(AUS_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

AUS_dpca_arima_male = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

AUS_pca_arima_male = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

AUS_male_err = rbind(AUS_dpca_arima_male$err, AUS_pca_arima_male$err)
rownames(AUS_male_err) = c("DPCA", "PCA")

# fh = 5 

AUS_dpca_arima_male_fh_5 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

AUS_pca_arima_male_fh_5 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

AUS_male_err_fh_5 = rbind(AUS_dpca_arima_male_fh_5$err, AUS_pca_arima_male_fh_5$err)
rownames(AUS_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_dpca_arima_male_fh_10 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

AUS_pca_arima_male_fh_10 = dpca_res(data = AUS_male_ratio, test_data = AUS_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = AUS_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

AUS_male_err_fh_10 = rbind(AUS_dpca_arima_male_fh_10$err, AUS_pca_arima_male_fh_10$err)
rownames(AUS_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

AUS_dpca_arima_total = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

AUS_pca_arima_total = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

AUS_total_err = rbind(AUS_dpca_arima_total$err, AUS_pca_arima_total$err)
rownames(AUS_total_err) = c("DPCA", "PCA")

# fh = 5

AUS_dpca_arima_total_fh_5 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

AUS_pca_arima_total_fh_5 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

AUS_total_err_fh_5 = rbind(AUS_dpca_arima_total_fh_5$err, AUS_pca_arima_total_fh_5$err)
rownames(AUS_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUS_dpca_arima_total_fh_10 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

AUS_pca_arima_total_fh_10 = dpca_res(data = AUS_total_ratio, test_data = AUS_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = AUS_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

AUS_total_err_fh_10 = rbind(AUS_dpca_arima_total_fh_10$err, AUS_pca_arima_total_fh_10$err)
rownames(AUS_total_err_fh_10) = c("DPCA", "PCA")

