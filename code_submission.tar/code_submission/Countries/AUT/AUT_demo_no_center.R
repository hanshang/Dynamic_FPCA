source("DFPCA_no_center.R")

## female series

# fh = 1

AUT_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_pca_arima_female_no_center = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_female_err_no_center = rbind(AUT_smooth_dpca_arima_female_no_center$err, AUT_smooth_pca_arima_female_no_center$err)
rownames(AUT_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

AUT_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_female_err_no_center_fh_5 = rbind(AUT_smooth_dpca_arima_female_no_center_fh_5$err, AUT_smooth_pca_arima_female_no_center_fh_5$err)
rownames(AUT_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = AUT_female_smooth_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_female_no_center_err_fh_10 = rbind(AUT_smooth_dpca_arima_female_no_center_fh_10$err, AUT_smooth_pca_arima_female_no_center_fh_10$err)
rownames(AUT_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

AUT_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = AUT_male_smooth_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_pca_arima_male_no_center = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_male_err_no_center = rbind(AUT_smooth_dpca_arima_male_no_center$err, AUT_smooth_pca_arima_male_no_center$err)
rownames(AUT_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

AUT_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = AUT_male_smooth_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_male_no_center_err_fh_5 = rbind(AUT_smooth_dpca_arima_male_no_center_fh_5$err, AUT_smooth_pca_arima_male_no_center_fh_5$err)
rownames(AUT_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = AUT_male_smooth_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_male_no_center_err_fh_10 = rbind(AUT_smooth_dpca_arima_male_no_center_fh_10$err, AUT_smooth_pca_arima_male_no_center_fh_10$err)
rownames(AUT_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

AUT_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = AUT_total_smooth_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_pca_arima_total_no_center = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

AUT_smooth_total_err_no_center = rbind(AUT_smooth_dpca_arima_total_no_center$err, AUT_smooth_pca_arima_total_no_center$err)
rownames(AUT_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

AUT_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = AUT_total_smooth_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

AUT_smooth_total_no_center_err_fh_5 = rbind(AUT_smooth_dpca_arima_total_no_center_fh_5$err, AUT_smooth_pca_arima_total_no_center_fh_5$err)
rownames(AUT_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = AUT_total_smooth_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

AUT_smooth_total_no_center_err_fh_10 = rbind(AUT_smooth_dpca_arima_total_no_center_fh_10$err, AUT_smooth_pca_arima_total_no_center_fh_10$err)
rownames(AUT_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

AUT_dpca_arima_female_no_center = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

AUT_pca_arima_female_no_center = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

AUT_female_err_no_center = rbind(AUT_dpca_arima_female_no_center$err, AUT_pca_arima_female_no_center$err)
rownames(AUT_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

AUT_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

AUT_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

AUT_female_err_no_center_fh_5 = rbind(AUT_dpca_arima_female_no_center_fh_5$err, AUT_pca_arima_female_no_center_fh_5$err)
rownames(AUT_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

AUT_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = AUT_female_ratio, test_data = AUT_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = AUT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

AUT_female_err_no_center_fh_10 = rbind(AUT_dpca_arima_female_no_center_fh_10$err, AUT_pca_arima_female_no_center_fh_10$err)
rownames(AUT_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

AUT_dpca_arima_male_no_center = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

AUT_pca_arima_male_no_center = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

AUT_male_err_no_center = rbind(AUT_dpca_arima_male_no_center$err, AUT_pca_arima_male_no_center$err)
rownames(AUT_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

AUT_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

AUT_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

AUT_male_err_no_center_fh_5 = rbind(AUT_dpca_arima_male_no_center_fh_5$err, AUT_pca_arima_male_no_center_fh_5$err)
rownames(AUT_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

AUT_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = AUT_male_ratio, test_data = AUT_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = AUT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

AUT_male_err_no_center_fh_10 = rbind(AUT_dpca_arima_male_no_center_fh_10$err, AUT_pca_arima_male_no_center_fh_10$err)
rownames(AUT_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

AUT_dpca_arima_total_no_center = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

AUT_pca_arima_total_no_center = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

AUT_total_err_no_center = rbind(AUT_dpca_arima_total_no_center$err, AUT_pca_arima_total_no_center$err)
rownames(AUT_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

AUT_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

AUT_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

AUT_total_err_no_center_fh_5 = rbind(AUT_dpca_arima_total_no_center_fh_5$err, AUT_pca_arima_total_no_center_fh_5$err)
rownames(AUT_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

AUT_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

AUT_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = AUT_total_ratio, test_data = AUT_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = AUT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

AUT_total_err_no_center_fh_10 = rbind(AUT_dpca_arima_total_no_center_fh_10$err, AUT_pca_arima_total_no_center_fh_10$err)
rownames(AUT_total_err_no_center_fh_10) = c("DPCA", "PCA")

