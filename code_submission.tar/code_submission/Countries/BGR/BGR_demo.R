rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

BGR_dummy = extract.ages(hmd.mx(country = "BGR", username = "shl8858@telstra.com", password = "hshang85", label = "BGR"), 0:100)
BGR_demo = extract.years(BGR_dummy, 1950:max(BGR_dummy$year))
BGR_smooth = smooth.demogdata(BGR_demo)
n_year = length(BGR_demo$year)

# convert non-stationary series to stationary series

BGR_female_ratio = BGR_male_ratio = BGR_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    BGR_female_ratio[,ik-1] = 2 * (1 - BGR_demo$rate$female[,ik]/BGR_demo$rate$female[,ik-1])/(1 + BGR_demo$rate$female[,ik]/BGR_demo$rate$female[,ik-1])
    BGR_male_ratio[,ik-1]   = 2 * (1 - BGR_demo$rate$male[,ik]/BGR_demo$rate$male[,ik-1])/(1 + BGR_demo$rate$male[,ik]/BGR_demo$rate$male[,ik-1])
    BGR_total_ratio[,ik-1]  = 2 * (1 - BGR_demo$rate$total[,ik]/BGR_demo$rate$total[,ik-1])/(1 + BGR_demo$rate$total[,ik]/BGR_demo$rate$total[,ik-1])
}  

BGR_female_smooth_ratio = BGR_male_smooth_ratio = BGR_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    BGR_female_smooth_ratio[,ik-1] = 2 * (1 - BGR_smooth$rate$female[,ik]/BGR_smooth$rate$female[,ik-1])/(1 + BGR_smooth$rate$female[,ik]/BGR_smooth$rate$female[,ik-1])
    BGR_male_smooth_ratio[,ik-1] = 2 * (1 - BGR_smooth$rate$male[,ik]/BGR_smooth$rate$male[,ik-1])/(1 + BGR_smooth$rate$male[,ik]/BGR_smooth$rate$male[,ik-1])
    BGR_total_smooth_ratio[,ik-1] = 2 * (1 - BGR_smooth$rate$total[,ik]/BGR_smooth$rate$total[,ik-1])/(1 + BGR_smooth$rate$total[,ik]/BGR_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(BGR_female_ratio); T_stationary(BGR_male_ratio); T_stationary(BGR_total_ratio)  # 0.067 0.146 0.111
T_stationary(BGR_female_smooth_ratio); T_stationary(BGR_male_smooth_ratio); T_stationary(BGR_total_smooth_ratio)  # 0.087 0.203 0.141


##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

BGR_smooth_dpca_arima_female = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_pca_arima_female = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_female_err = rbind(BGR_smooth_dpca_arima_female$err, BGR_smooth_pca_arima_female$err)
rownames(BGR_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

BGR_smooth_dpca_arima_female_fh_5 = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_pca_arima_female_fh_5 = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_female_err_fh_5 = rbind(BGR_smooth_dpca_arima_female_fh_5$err, BGR_smooth_pca_arima_female_fh_5$err)
rownames(BGR_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_smooth_dpca_arima_female_fh_10 = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_pca_arima_female_fh_10 = dpca_res(data = BGR_female_smooth_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_female_err_fh_10 = rbind(BGR_smooth_dpca_arima_female_fh_10$err, BGR_smooth_pca_arima_female_fh_10$err)
rownames(BGR_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

BGR_smooth_dpca_arima_male = dpca_res(data = BGR_male_smooth_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_pca_arima_male = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_male_err = rbind(BGR_smooth_dpca_arima_male$err, BGR_smooth_pca_arima_male$err)
rownames(BGR_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

BGR_smooth_dpca_arima_male_fh_5 = dpca_res(data = BGR_male_smooth_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_pca_arima_male_fh_5 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_male_err_fh_5 = rbind(BGR_smooth_dpca_arima_male_fh_5$err, BGR_smooth_pca_arima_male_fh_5$err)
rownames(BGR_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_smooth_dpca_arima_male_fh_10 = dpca_res(data = BGR_male_smooth_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_pca_arima_male_fh_10 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_male_err_fh_10 = rbind(BGR_smooth_dpca_arima_male_fh_10$err, BGR_smooth_pca_arima_male_fh_10$err)
rownames(BGR_smooth_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

BGR_smooth_dpca_arima_total = dpca_res(data = BGR_total_smooth_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_pca_arima_total = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

BGR_smooth_total_err = rbind(BGR_smooth_dpca_arima_total$err, BGR_smooth_pca_arima_total$err)
rownames(BGR_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

BGR_smooth_dpca_arima_total_fh_5 = dpca_res(data = BGR_total_smooth_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_pca_arima_total_fh_5 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

BGR_smooth_total_err_fh_5 = rbind(BGR_smooth_dpca_arima_total_fh_5$err, BGR_smooth_pca_arima_total_fh_5$err)
rownames(BGR_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_smooth_dpca_arima_total_fh_10 = dpca_res(data = BGR_total_smooth_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_pca_arima_total_fh_10 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

BGR_smooth_total_err_fh_10 = rbind(BGR_smooth_dpca_arima_total_fh_10$err, BGR_smooth_pca_arima_total_fh_10$err)
rownames(BGR_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

BGR_dpca_arima_female = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

BGR_pca_arima_female = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

BGR_female_err = rbind(BGR_dpca_arima_female$err, BGR_pca_arima_female$err)
rownames(BGR_female_err) = c("DPCA", "PCA")

# fh = 5

BGR_dpca_arima_female_fh_5 = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

BGR_pca_arima_female_fh_5 = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

BGR_female_err_fh_5 = rbind(BGR_dpca_arima_female_fh_5$err, BGR_pca_arima_female_fh_5$err)
rownames(BGR_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_dpca_arima_female_fh_10 = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

BGR_pca_arima_female_fh_10 = dpca_res(data = BGR_female_ratio, test_data = BGR_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = BGR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

BGR_female_err_fh_10 = rbind(BGR_dpca_arima_female_fh_10$err, BGR_pca_arima_female_fh_10$err)
rownames(BGR_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

BGR_dpca_arima_male = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

BGR_pca_arima_male = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

BGR_male_err = rbind(BGR_dpca_arima_male$err, BGR_pca_arima_male$err)
rownames(BGR_male_err) = c("DPCA", "PCA")

# fh = 5

BGR_dpca_arima_male_fh_5 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

BGR_pca_arima_male_fh_5 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

BGR_male_err_fh_5 = rbind(BGR_dpca_arima_male_fh_5$err, BGR_pca_arima_male_fh_5$err)
rownames(BGR_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_dpca_arima_male_fh_10 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

BGR_pca_arima_male_fh_10 = dpca_res(data = BGR_male_ratio, test_data = BGR_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = BGR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

BGR_male_err_fh_10 = rbind(BGR_dpca_arima_male_fh_10$err, BGR_pca_arima_male_fh_10$err)
rownames(BGR_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

BGR_dpca_arima_total = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

BGR_pca_arima_total = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

BGR_total_err = rbind(BGR_dpca_arima_total$err, BGR_pca_arima_total$err)
rownames(BGR_total_err) = c("DPCA", "PCA")

# fh = 5

BGR_dpca_arima_total_fh_5 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

BGR_pca_arima_total_fh_5 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

BGR_total_err_fh_5 = rbind(BGR_dpca_arima_total_fh_5$err, BGR_pca_arima_total_fh_5$err)
rownames(BGR_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

BGR_dpca_arima_total_fh_10 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

BGR_pca_arima_total_fh_10 = dpca_res(data = BGR_total_ratio, test_data = BGR_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = BGR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

BGR_total_err_fh_10 = rbind(BGR_dpca_arima_total_fh_10$err, BGR_pca_arima_total_fh_10$err)
rownames(BGR_total_err_fh_10) = c("DPCA", "PCA")


