rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

CAN_dummy = extract.ages(hmd.mx(country = "CAN", username = "shl8858@telstra.com", password = "hshang85", label = "CAN"), 0:100)
CAN_demo = extract.years(CAN_dummy, 1950:max(CAN_dummy$year))
CAN_smooth = smooth.demogdata(CAN_demo)
n_year = length(CAN_demo$year)

# convert non-stationary series to stationary series

CAN_female_ratio = CAN_male_ratio = CAN_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    CAN_female_ratio[,ik-1] = 2 * (1 - CAN_demo$rate$female[,ik]/CAN_demo$rate$female[,ik-1])/(1 + CAN_demo$rate$female[,ik]/CAN_demo$rate$female[,ik-1])
    CAN_male_ratio[,ik-1]   = 2 * (1 - CAN_demo$rate$male[,ik]/CAN_demo$rate$male[,ik-1])/(1 + CAN_demo$rate$male[,ik]/CAN_demo$rate$male[,ik-1])
    CAN_total_ratio[,ik-1]   = 2 * (1 - CAN_demo$rate$total[,ik]/CAN_demo$rate$total[,ik-1])/(1 + CAN_demo$rate$total[,ik]/CAN_demo$rate$total[,ik-1])
}  

CAN_female_smooth_ratio = CAN_male_smooth_ratio = CAN_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    CAN_female_smooth_ratio[,ik-1] = 2 * (1 - CAN_smooth$rate$female[,ik]/CAN_smooth$rate$female[,ik-1])/(1 + CAN_smooth$rate$female[,ik]/CAN_smooth$rate$female[,ik-1])
    CAN_male_smooth_ratio[,ik-1] = 2 * (1 - CAN_smooth$rate$male[,ik]/CAN_smooth$rate$male[,ik-1])/(1 + CAN_smooth$rate$male[,ik]/CAN_smooth$rate$male[,ik-1])
    CAN_total_smooth_ratio[,ik-1] = 2 * (1 - CAN_smooth$rate$total[,ik]/CAN_smooth$rate$total[,ik-1])/(1 + CAN_smooth$rate$total[,ik]/CAN_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(CAN_female_ratio); T_stationary(CAN_male_ratio); T_stationary(CAN_total_ratio)  # 0.144 0.047 0.172
T_stationary(CAN_female_smooth_ratio); T_stationary(CAN_male_smooth_ratio); T_stationary(CAN_total_smooth_ratio)   # 0.361 0.095 0.322


##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

CAN_smooth_dpca_arima_female = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_pca_arima_female = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_female_err = rbind(CAN_smooth_dpca_arima_female$err, CAN_smooth_pca_arima_female$err)
rownames(CAN_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

CAN_smooth_dpca_arima_female_fh_5 = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_pca_arima_female_fh_5 = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_female_err_fh_5 = rbind(CAN_smooth_dpca_arima_female_fh_5$err, CAN_smooth_pca_arima_female_fh_5$err)
rownames(CAN_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_smooth_dpca_arima_female_fh_10 = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_pca_arima_female_fh_10 = dpca_res(data = CAN_female_smooth_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_female_err_fh_10 = rbind(CAN_smooth_dpca_arima_female_fh_10$err, CAN_smooth_pca_arima_female_fh_10$err)
rownames(CAN_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

CAN_smooth_dpca_arima_male = dpca_res(data = CAN_male_smooth_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_pca_arima_male = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_male_err = rbind(CAN_smooth_dpca_arima_male$err, CAN_smooth_pca_arima_male$err)
rownames(CAN_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

CAN_smooth_dpca_arima_male_fh_5 = dpca_res(data = CAN_male_smooth_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_pca_arima_male_fh_5 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_male_err_fh_5 = rbind(CAN_smooth_dpca_arima_male_fh_5$err, CAN_smooth_pca_arima_male_fh_5$err)
rownames(CAN_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_smooth_dpca_arima_male_fh_10 = dpca_res(data = CAN_male_smooth_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_pca_arima_male_fh_10 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_male_err_fh_10 = rbind(CAN_smooth_dpca_arima_male_fh_10$err, CAN_smooth_pca_arima_male_fh_10$err)
rownames(CAN_smooth_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

CAN_smooth_dpca_arima_total = dpca_res(data = CAN_total_smooth_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_pca_arima_total = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CAN_smooth_total_err = rbind(CAN_smooth_dpca_arima_total$err, CAN_smooth_pca_arima_total$err)
rownames(CAN_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

CAN_smooth_dpca_arima_total_fh_5 = dpca_res(data = CAN_total_smooth_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_pca_arima_total_fh_5 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CAN_smooth_total_err_fh_5 = rbind(CAN_smooth_dpca_arima_total_fh_5$err, CAN_smooth_pca_arima_total_fh_5$err)
rownames(CAN_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_smooth_dpca_arima_total_fh_10 = dpca_res(data = CAN_total_smooth_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_pca_arima_total_fh_10 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CAN_smooth_total_err_fh_10 = rbind(CAN_smooth_dpca_arima_total_fh_10$err, CAN_smooth_pca_arima_total_fh_10$err)
rownames(CAN_smooth_total_err_fh_10) = c("DPCA", "PCA")

########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

CAN_dpca_arima_female = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

CAN_pca_arima_female = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

CAN_female_err = rbind(CAN_dpca_arima_female$err, CAN_pca_arima_female$err)
rownames(CAN_female_err) = c("DPCA", "PCA")

# fh = 5

CAN_dpca_arima_female_fh_5 = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

CAN_pca_arima_female_fh_5 = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

CAN_female_err_fh_5 = rbind(CAN_dpca_arima_female_fh_5$err, CAN_pca_arima_female_fh_5$err)
rownames(CAN_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_dpca_arima_female_fh_10 = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

CAN_pca_arima_female_fh_10 = dpca_res(data = CAN_female_ratio, test_data = CAN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = CAN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

CAN_female_err_fh_10 = rbind(CAN_dpca_arima_female_fh_10$err, CAN_pca_arima_female_fh_10$err)
rownames(CAN_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

CAN_dpca_arima_male = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

CAN_pca_arima_male = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

CAN_male_err = rbind(CAN_dpca_arima_male$err, CAN_pca_arima_male$err)
rownames(CAN_male_err) = c("DPCA", "PCA")

# fh = 5

CAN_dpca_arima_male_fh_5 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

CAN_pca_arima_male_fh_5 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

CAN_male_err_fh_5 = rbind(CAN_dpca_arima_male_fh_5$err, CAN_pca_arima_male_fh_5$err)
rownames(CAN_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_dpca_arima_male_fh_10 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

CAN_pca_arima_male_fh_10 = dpca_res(data = CAN_male_ratio, test_data = CAN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = CAN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

CAN_male_err_fh_10 = rbind(CAN_dpca_arima_male_fh_10$err, CAN_pca_arima_male_fh_10$err)
rownames(CAN_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

CAN_dpca_arima_total = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

CAN_pca_arima_total = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

CAN_total_err = rbind(CAN_dpca_arima_total$err, CAN_pca_arima_total$err)
rownames(CAN_total_err) = c("DPCA", "PCA")

# fh = 5

CAN_dpca_arima_total_fh_5 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

CAN_pca_arima_total_fh_5 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

CAN_total_err_fh_5 = rbind(CAN_dpca_arima_total_fh_5$err, CAN_pca_arima_total_fh_5$err)
rownames(CAN_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CAN_dpca_arima_total_fh_10 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

CAN_pca_arima_total_fh_10 = dpca_res(data = CAN_total_ratio, test_data = CAN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = CAN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

CAN_total_err_fh_10 = rbind(CAN_dpca_arima_total_fh_10$err, CAN_pca_arima_total_fh_10$err)
rownames(CAN_total_err_fh_10) = c("DPCA", "PCA")

