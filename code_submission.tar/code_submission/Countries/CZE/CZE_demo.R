rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

CZE_dummy = extract.ages(hmd.mx(country = "CZE", username = "shl8858@telstra.com", password = "hshang85", label = "CZE"), 0:100)
CZE_demo = extract.years(CZE_dummy, 1950:max(CZE_dummy$year))
CZE_smooth = smooth.demogdata(CZE_demo)
n_year = length(CZE_demo$year)

# convert non-stationary series to stationary series

CZE_female_dummy_ratio = CZE_male_dummy_ratio = CZE_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    CZE_female_dummy_ratio[,ik-1] = 2 * (1 - CZE_demo$rate$female[,ik]/CZE_demo$rate$female[,ik-1])/(1 + CZE_demo$rate$female[,ik]/CZE_demo$rate$female[,ik-1])
    CZE_male_dummy_ratio[,ik-1]   = 2 * (1 - CZE_demo$rate$male[,ik]/CZE_demo$rate$male[,ik-1])/(1 + CZE_demo$rate$male[,ik]/CZE_demo$rate$male[,ik-1])
    CZE_total_ratio[,ik-1]  = 2 * (1 - CZE_demo$rate$total[,ik]/CZE_demo$rate$total[,ik-1])/(1 + CZE_demo$rate$total[,ik]/CZE_demo$rate$total[,ik-1])
}  

CZE_female_ratio = na.locf(CZE_female_dummy_ratio)
CZE_male_ratio = na.locf(CZE_male_dummy_ratio)


CZE_female_smooth_ratio = CZE_male_smooth_ratio = CZE_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    CZE_female_smooth_ratio[,ik-1] = 2 * (1 - CZE_smooth$rate$female[,ik]/CZE_smooth$rate$female[,ik-1])/(1 + CZE_smooth$rate$female[,ik]/CZE_smooth$rate$female[,ik-1]) 
    CZE_male_smooth_ratio[,ik-1] = 2 * (1 - CZE_smooth$rate$male[,ik]/CZE_smooth$rate$male[,ik-1])/(1 + CZE_smooth$rate$male[,ik]/CZE_smooth$rate$male[,ik-1]) 
    CZE_total_smooth_ratio[,ik-1] = 2 * (1 - CZE_smooth$rate$total[,ik]/CZE_smooth$rate$total[,ik-1])/(1 + CZE_smooth$rate$total[,ik]/CZE_smooth$rate$total[,ik-1]) 
}

# compute p-value for the stationary hypothesis tests

T_stationary(CZE_female_ratio); T_stationary(CZE_male_ratio); T_stationary(CZE_total_ratio)  # 0.09 0.02 0.109
T_stationary(CZE_female_smooth_ratio); T_stationary(CZE_male_smooth_ratio); T_stationary(CZE_total_smooth_ratio) # 0.161 0.162 0.208

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

CZE_smooth_dpca_arima_female = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_female = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_female_err = rbind(CZE_smooth_dpca_arima_female$err, CZE_smooth_pca_arima_female$err)
rownames(CZE_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_female_fh_5 = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_female_fh_5 = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_female_err_fh_5 = rbind(CZE_smooth_dpca_arima_female_fh_5$err, CZE_smooth_pca_arima_female_fh_5$err)
rownames(CZE_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_female_fh_10 = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_female_fh_10 = dpca_res(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_female_err_fh_10 = rbind(CZE_smooth_dpca_arima_female_fh_10$err, CZE_smooth_pca_arima_female_fh_10$err)
rownames(CZE_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

CZE_smooth_dpca_arima_male = dpca_res(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_male = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_male_err = rbind(CZE_smooth_dpca_arima_male$err, CZE_smooth_pca_arima_male$err)
rownames(CZE_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_male_fh_5 = dpca_res(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_male_fh_5 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_male_err_fh_5 = rbind(CZE_smooth_dpca_arima_male_fh_5$err, CZE_smooth_pca_arima_male_fh_5$err)
rownames(CZE_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_male_fh_10 = dpca_res(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_male_fh_10 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_male_err_fh_10 = rbind(CZE_smooth_dpca_arima_male_fh_10$err, CZE_smooth_pca_arima_male_fh_10$err)
rownames(CZE_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

CZE_smooth_dpca_arima_total = dpca_res(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_total = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_total_err = rbind(CZE_smooth_dpca_arima_total$err, CZE_smooth_pca_arima_total$err)
rownames(CZE_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_total_fh_5 = dpca_res(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_total_fh_5 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_total_err_fh_5 = rbind(CZE_smooth_dpca_arima_total_fh_5$err, CZE_smooth_pca_arima_total_fh_5$err)
rownames(CZE_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_total_fh_10 = dpca_res(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_total_fh_10 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_total_err_fh_10 = rbind(CZE_smooth_dpca_arima_total_fh_10$err, CZE_smooth_pca_arima_total_fh_10$err)
rownames(CZE_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

CZE_dpca_arima_female = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

CZE_pca_arima_female = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

CZE_female_err = rbind(CZE_dpca_arima_female$err, CZE_pca_arima_female$err)
rownames(CZE_female_err) = c("DPCA", "PCA")

# fh = 5

CZE_dpca_arima_female_fh_5 = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

CZE_pca_arima_female_fh_5 = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

CZE_female_err_fh_5 = rbind(CZE_dpca_arima_female_fh_5$err, CZE_pca_arima_female_fh_5$err)
rownames(CZE_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_female_fh_10 = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

CZE_pca_arima_female_fh_10 = dpca_res(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

CZE_female_err_fh_10 = rbind(CZE_dpca_arima_female_fh_10$err, CZE_pca_arima_female_fh_10$err)
rownames(CZE_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

CZE_dpca_arima_male = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

CZE_pca_arima_male = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

CZE_male_err = rbind(CZE_dpca_arima_male$err, CZE_pca_arima_male$err)
rownames(CZE_male_err) = c("DPCA", "PCA")

# fh = 5

CZE_dpca_arima_male_fh_5 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

CZE_pca_arima_male_fh_5 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

CZE_male_err_fh_5 = rbind(CZE_dpca_arima_male_fh_5$err, CZE_pca_arima_male_fh_5$err)
rownames(CZE_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_male_fh_10 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

CZE_pca_arima_male_fh_10 = dpca_res(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

CZE_male_err_fh_10 = rbind(CZE_dpca_arima_male_fh_10$err, CZE_pca_arima_male_fh_10$err)
rownames(CZE_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

CZE_dpca_arima_total = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

CZE_pca_arima_total = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

CZE_total_err = rbind(CZE_dpca_arima_total$err, CZE_pca_arima_total$err)
rownames(CZE_total_err) = c("DPCA", "PCA")

# fh = 5

CZE_dpca_arima_total_fh_5 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

CZE_pca_arima_total_fh_5 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

CZE_total_err_fh_5 = rbind(CZE_dpca_arima_total_fh_5$err, CZE_pca_arima_total_fh_5$err)
rownames(CZE_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_total_fh_10 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

CZE_pca_arima_total_fh_10 = dpca_res(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

CZE_total_err_fh_10 = rbind(CZE_dpca_arima_total_fh_10$err, CZE_pca_arima_total_fh_10$err)
rownames(CZE_total_err_fh_10) = c("DPCA", "PCA")

