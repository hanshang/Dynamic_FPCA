source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

CZE_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_female_no_center = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_female_err_no_center = rbind(CZE_smooth_dpca_arima_female_no_center$err, CZE_smooth_pca_arima_female_no_center$err)
rownames(CZE_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_female_err_no_center_fh_5 = rbind(CZE_smooth_dpca_arima_female_no_center_fh_5$err, CZE_smooth_pca_arima_female_no_center_fh_5$err)
rownames(CZE_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = CZE_female_smooth_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_female_no_center_err_fh_10 = rbind(CZE_smooth_dpca_arima_female_no_center_fh_10$err, CZE_smooth_pca_arima_female_no_center_fh_10$err)
rownames(CZE_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

CZE_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_male_no_center = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_male_err_no_center = rbind(CZE_smooth_dpca_arima_male_no_center$err, CZE_smooth_pca_arima_male_no_center$err)
rownames(CZE_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_male_no_center_err_fh_5 = rbind(CZE_smooth_dpca_arima_male_no_center_fh_5$err, CZE_smooth_pca_arima_male_no_center_fh_5$err)
rownames(CZE_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = CZE_male_smooth_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_male_no_center_err_fh_10 = rbind(CZE_smooth_dpca_arima_male_no_center_fh_10$err, CZE_smooth_pca_arima_male_no_center_fh_10$err)
rownames(CZE_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

CZE_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_pca_arima_total_no_center = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

CZE_smooth_total_err_no_center = rbind(CZE_smooth_dpca_arima_total_no_center$err, CZE_smooth_pca_arima_total_no_center$err)
rownames(CZE_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

CZE_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

CZE_smooth_total_no_center_err_fh_5 = rbind(CZE_smooth_dpca_arima_total_no_center_fh_5$err, CZE_smooth_pca_arima_total_no_center_fh_5$err)
rownames(CZE_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = CZE_total_smooth_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

CZE_smooth_total_no_center_err_fh_10 = rbind(CZE_smooth_dpca_arima_total_no_center_fh_10$err, CZE_smooth_pca_arima_total_no_center_fh_10$err)
rownames(CZE_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

CZE_dpca_arima_female_no_center = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

CZE_pca_arima_female_no_center = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

CZE_female_err_no_center = rbind(CZE_dpca_arima_female_no_center$err, CZE_pca_arima_female_no_center$err)
rownames(CZE_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

CZE_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

CZE_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

CZE_female_err_no_center_fh_5 = rbind(CZE_dpca_arima_female_no_center_fh_5$err, CZE_pca_arima_female_no_center_fh_5$err)
rownames(CZE_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

CZE_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = CZE_female_ratio, test_data = CZE_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = CZE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

CZE_female_err_no_center_fh_10 = rbind(CZE_dpca_arima_female_no_center_fh_10$err, CZE_pca_arima_female_no_center_fh_10$err)
rownames(CZE_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

CZE_dpca_arima_male_no_center = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

CZE_pca_arima_male_no_center = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

CZE_male_err_no_center = rbind(CZE_dpca_arima_male_no_center$err, CZE_pca_arima_male_no_center$err)
rownames(CZE_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

CZE_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

CZE_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

CZE_male_err_no_center_fh_5 = rbind(CZE_dpca_arima_male_no_center_fh_5$err, CZE_pca_arima_male_no_center_fh_5$err)
rownames(CZE_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

CZE_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = CZE_male_ratio, test_data = CZE_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = CZE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

CZE_male_err_no_center_fh_10 = rbind(CZE_dpca_arima_male_no_center_fh_10$err, CZE_pca_arima_male_no_center_fh_10$err)
rownames(CZE_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

CZE_dpca_arima_total_no_center = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

CZE_pca_arima_total_no_center = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

CZE_total_err_no_center = rbind(CZE_dpca_arima_total_no_center$err, CZE_pca_arima_total_no_center$err)
rownames(CZE_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

CZE_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

CZE_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

CZE_total_err_no_center_fh_5 = rbind(CZE_dpca_arima_total_no_center_fh_5$err, CZE_pca_arima_total_no_center_fh_5$err)
rownames(CZE_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

CZE_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

CZE_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = CZE_total_ratio, test_data = CZE_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = CZE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

CZE_total_err_no_center_fh_10 = rbind(CZE_dpca_arima_total_no_center_fh_10$err, CZE_pca_arima_total_no_center_fh_10$err)
rownames(CZE_total_err_no_center_fh_10) = c("DPCA", "PCA")

