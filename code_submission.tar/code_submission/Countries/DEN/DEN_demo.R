rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

DEN_dummy = extract.ages(hmd.mx(country = "DNK", username = "shl8858@telstra.com", password = "hshang85", label = "DEN"), 0:100)
DEN_demo = extract.years(DEN_dummy, 1950:max(DEN_dummy$year))
DEN_smooth = smooth.demogdata(DEN_demo)
n_year = length(DEN_demo$year)

# convert non-stationary series to stationary series

DEN_female_dummy_ratio = DEN_male_dummy_ratio = DEN_total_dummy_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    DEN_female_dummy_ratio[,ik-1] = 2 * (1 - DEN_demo$rate$female[,ik]/DEN_demo$rate$female[,ik-1])/(1 + DEN_demo$rate$female[,ik]/DEN_demo$rate$female[,ik-1])
    DEN_male_dummy_ratio[,ik-1]   = 2 * (1 - DEN_demo$rate$male[,ik]/DEN_demo$rate$male[,ik-1])/(1 + DEN_demo$rate$male[,ik]/DEN_demo$rate$male[,ik-1])
    DEN_total_dummy_ratio[,ik-1]  = 2 * (1 - DEN_demo$rate$total[,ik]/DEN_demo$rate$total[,ik-1])/(1 + DEN_demo$rate$total[,ik]/DEN_demo$rate$total[,ik-1])
}  

which(!is.finite(DEN_female_dummy_ratio))
which(!is.finite(DEN_male_dummy_ratio))
which(!is.finite(DEN_total_dummy_ratio))

DEN_female_ratio = na.locf(DEN_female_dummy_ratio)
DEN_male_ratio   = na.locf(DEN_male_dummy_ratio)
DEN_total_ratio  = na.locf(DEN_total_dummy_ratio)


DEN_female_smooth_ratio = DEN_male_smooth_ratio = DEN_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    DEN_female_smooth_ratio[,ik-1] = 2 * (1 - DEN_smooth$rate$female[,ik]/DEN_smooth$rate$female[,ik-1])/(1 + DEN_smooth$rate$female[,ik]/DEN_smooth$rate$female[,ik-1])
    DEN_male_smooth_ratio[,ik-1]   = 2 * (1 - DEN_smooth$rate$male[,ik]/DEN_smooth$rate$male[,ik-1])/(1 + DEN_smooth$rate$male[,ik]/DEN_smooth$rate$male[,ik-1])
    DEN_total_smooth_ratio[,ik-1]  = 2 * (1 - DEN_smooth$rate$total[,ik]/DEN_smooth$rate$total[,ik-1])/(1 + DEN_smooth$rate$total[,ik]/DEN_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(DEN_female_ratio); T_stationary(DEN_male_ratio); T_stationary(DEN_total_ratio)  # 0.009 0.009 0.024
T_stationary(DEN_female_smooth_ratio); T_stationary(DEN_male_smooth_ratio); T_stationary(DEN_total_smooth_ratio)   # 0.154 0.059 0.09

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

DEN_smooth_dpca_arima_female = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_pca_arima_female = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_female_err = rbind(DEN_smooth_dpca_arima_female$err, DEN_smooth_pca_arima_female$err)
rownames(DEN_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

DEN_smooth_dpca_arima_female_fh_5 = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_pca_arima_female_fh_5 = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_female_err_fh_5 = rbind(DEN_smooth_dpca_arima_female_fh_5$err, DEN_smooth_pca_arima_female_fh_5$err)
rownames(DEN_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_smooth_dpca_arima_female_fh_10 = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_pca_arima_female_fh_10 = dpca_res(data = DEN_female_smooth_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_female_err_fh_10 = rbind(DEN_smooth_dpca_arima_female_fh_10$err, DEN_smooth_pca_arima_female_fh_10$err)
rownames(DEN_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

DEN_smooth_dpca_arima_male = dpca_res(data = DEN_male_smooth_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_pca_arima_male = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_male_err = rbind(DEN_smooth_dpca_arima_male$err, DEN_smooth_pca_arima_male$err)
rownames(DEN_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

DEN_smooth_dpca_arima_male_fh_5 = dpca_res(data = DEN_male_smooth_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_pca_arima_male_fh_5 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_male_err_fh_5 = rbind(DEN_smooth_dpca_arima_male_fh_5$err, DEN_smooth_pca_arima_male_fh_5$err)
rownames(DEN_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_smooth_dpca_arima_male_fh_10 = dpca_res(data = DEN_male_smooth_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_pca_arima_male_fh_10 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_male_err_fh_10 = rbind(DEN_smooth_dpca_arima_male_fh_10$err, DEN_smooth_pca_arima_male_fh_10$err)
rownames(DEN_smooth_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

DEN_smooth_dpca_arima_total = dpca_res(data = DEN_total_smooth_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_pca_arima_total = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

DEN_smooth_total_err = rbind(DEN_smooth_dpca_arima_total$err, DEN_smooth_pca_arima_total$err)
rownames(DEN_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

DEN_smooth_dpca_arima_total_fh_5 = dpca_res(data = DEN_total_smooth_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_pca_arima_total_fh_5 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

DEN_smooth_total_err_fh_5 = rbind(DEN_smooth_dpca_arima_total_fh_5$err, DEN_smooth_pca_arima_total_fh_5$err)
rownames(DEN_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_smooth_dpca_arima_total_fh_10 = dpca_res(data = DEN_total_smooth_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_pca_arima_total_fh_10 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

DEN_smooth_total_err_fh_10 = rbind(DEN_smooth_dpca_arima_total_fh_10$err, DEN_smooth_pca_arima_total_fh_10$err)
rownames(DEN_smooth_total_err_fh_10) = c("DPCA", "PCA")



########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

DEN_dpca_arima_female = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

DEN_pca_arima_female = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                               jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

DEN_female_err = rbind(DEN_dpca_arima_female$err, DEN_pca_arima_female$err)
rownames(DEN_female_err) = c("DPCA", "PCA")

# fh = 5

DEN_dpca_arima_female_fh_5 = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

DEN_pca_arima_female_fh_5 = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

DEN_female_err_fh_5 = rbind(DEN_dpca_arima_female_fh_5$err, DEN_pca_arima_female_fh_5$err)
rownames(DEN_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_dpca_arima_female_fh_10 = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

DEN_pca_arima_female_fh_10 = dpca_res(data = DEN_female_ratio, test_data = DEN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = DEN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

DEN_female_err_fh_10 = rbind(DEN_dpca_arima_female_fh_10$err, DEN_pca_arima_female_fh_10$err)
rownames(DEN_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

DEN_dpca_arima_male = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                              forecasting_method = "arima", fh = 1)

DEN_pca_arima_male = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                             jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                             forecasting_method = "arima", fh = 1)

DEN_male_err = rbind(DEN_dpca_arima_male$err, DEN_pca_arima_male$err)
rownames(DEN_male_err) = c("DPCA", "PCA")

# fh = 5

DEN_dpca_arima_male_fh_5 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

DEN_pca_arima_male_fh_5 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

DEN_male_err_fh_5 = rbind(DEN_dpca_arima_male_fh_5$err, DEN_pca_arima_male_fh_5$err)
rownames(DEN_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_dpca_arima_male_fh_10 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

DEN_pca_arima_male_fh_10 = dpca_res(data = DEN_male_ratio, test_data = DEN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = DEN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

DEN_male_err_fh_10 = rbind(DEN_dpca_arima_male_fh_10$err, DEN_pca_arima_male_fh_10$err)
rownames(DEN_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

DEN_dpca_arima_total = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

DEN_pca_arima_total = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                              jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

DEN_total_err = rbind(DEN_dpca_arima_total$err, DEN_pca_arima_total$err)
rownames(DEN_total_err) = c("DPCA", "PCA")

# fh = 5

DEN_dpca_arima_total_fh_5 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

DEN_pca_arima_total_fh_5 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

DEN_total_err_fh_5 = rbind(DEN_dpca_arima_total_fh_5$err, DEN_pca_arima_total_fh_5$err)
rownames(DEN_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

DEN_dpca_arima_total_fh_10 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

DEN_pca_arima_total_fh_10 = dpca_res(data = DEN_total_ratio, test_data = DEN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = DEN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

DEN_total_err_fh_10 = rbind(DEN_dpca_arima_total_fh_10$err, DEN_pca_arima_total_fh_10$err)
rownames(DEN_total_err_fh_10) = c("DPCA", "PCA")

