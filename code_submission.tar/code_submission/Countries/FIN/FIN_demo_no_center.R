source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

FIN_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_pca_arima_female_no_center = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_female_err_no_center = rbind(FIN_smooth_dpca_arima_female_no_center$err, FIN_smooth_pca_arima_female_no_center$err)
rownames(FIN_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

FIN_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_female_err_no_center_fh_5 = rbind(FIN_smooth_dpca_arima_female_no_center_fh_5$err, FIN_smooth_pca_arima_female_no_center_fh_5$err)
rownames(FIN_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = FIN_female_smooth_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_female_no_center_err_fh_10 = rbind(FIN_smooth_dpca_arima_female_no_center_fh_10$err, FIN_smooth_pca_arima_female_no_center_fh_10$err)
rownames(FIN_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

FIN_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = FIN_male_smooth_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_pca_arima_male_no_center = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_male_err_no_center = rbind(FIN_smooth_dpca_arima_male_no_center$err, FIN_smooth_pca_arima_male_no_center$err)
rownames(FIN_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

FIN_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = FIN_male_smooth_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_male_no_center_err_fh_5 = rbind(FIN_smooth_dpca_arima_male_no_center_fh_5$err, FIN_smooth_pca_arima_male_no_center_fh_5$err)
rownames(FIN_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = FIN_male_smooth_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_male_no_center_err_fh_10 = rbind(FIN_smooth_dpca_arima_male_no_center_fh_10$err, FIN_smooth_pca_arima_male_no_center_fh_10$err)
rownames(FIN_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

FIN_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = FIN_total_smooth_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_pca_arima_total_no_center = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FIN_smooth_total_err_no_center = rbind(FIN_smooth_dpca_arima_total_no_center$err, FIN_smooth_pca_arima_total_no_center$err)
rownames(FIN_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

FIN_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = FIN_total_smooth_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FIN_smooth_total_no_center_err_fh_5 = rbind(FIN_smooth_dpca_arima_total_no_center_fh_5$err, FIN_smooth_pca_arima_total_no_center_fh_5$err)
rownames(FIN_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = FIN_total_smooth_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FIN_smooth_total_no_center_err_fh_10 = rbind(FIN_smooth_dpca_arima_total_no_center_fh_10$err, FIN_smooth_pca_arima_total_no_center_fh_10$err)
rownames(FIN_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

FIN_dpca_arima_female_no_center = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

FIN_pca_arima_female_no_center = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

FIN_female_err_no_center = rbind(FIN_dpca_arima_female_no_center$err, FIN_pca_arima_female_no_center$err)
rownames(FIN_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

FIN_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

FIN_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

FIN_female_err_no_center_fh_5 = rbind(FIN_dpca_arima_female_no_center_fh_5$err, FIN_pca_arima_female_no_center_fh_5$err)
rownames(FIN_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

FIN_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = FIN_female_ratio, test_data = FIN_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = FIN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

FIN_female_err_no_center_fh_10 = rbind(FIN_dpca_arima_female_no_center_fh_10$err, FIN_pca_arima_female_no_center_fh_10$err)
rownames(FIN_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

FIN_dpca_arima_male_no_center = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

FIN_pca_arima_male_no_center = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

FIN_male_err_no_center = rbind(FIN_dpca_arima_male_no_center$err, FIN_pca_arima_male_no_center$err)
rownames(FIN_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

FIN_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

FIN_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

FIN_male_err_no_center_fh_5 = rbind(FIN_dpca_arima_male_no_center_fh_5$err, FIN_pca_arima_male_no_center_fh_5$err)
rownames(FIN_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

FIN_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = FIN_male_ratio, test_data = FIN_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = FIN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

FIN_male_err_no_center_fh_10 = rbind(FIN_dpca_arima_male_no_center_fh_10$err, FIN_pca_arima_male_no_center_fh_10$err)
rownames(FIN_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

FIN_dpca_arima_total_no_center = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

FIN_pca_arima_total_no_center = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

FIN_total_err_no_center = rbind(FIN_dpca_arima_total_no_center$err, FIN_pca_arima_total_no_center$err)
rownames(FIN_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

FIN_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

FIN_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

FIN_total_err_no_center_fh_5 = rbind(FIN_dpca_arima_total_no_center_fh_5$err, FIN_pca_arima_total_no_center_fh_5$err)
rownames(FIN_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

FIN_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

FIN_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = FIN_total_ratio, test_data = FIN_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = FIN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

FIN_total_err_no_center_fh_10 = rbind(FIN_dpca_arima_total_no_center_fh_10$err, FIN_pca_arima_total_no_center_fh_10$err)
rownames(FIN_total_err_no_center_fh_10) = c("DPCA", "PCA")

