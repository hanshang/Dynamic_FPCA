rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

FRA_dummy = extract.ages(hmd.mx(country = "FRATNP", username = "shl8858@telstra.com", password = "hshang85", label = "FRA"), 0:100)
FRA_demo = extract.years(FRA_dummy, 1950:max(FRA_dummy$year))
FRA_smooth = smooth.demogdata(FRA_demo)
n_year = length(FRA_demo$year)

# convert non-stationary series to stationary series

FRA_female_ratio = FRA_male_ratio = FRA_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    FRA_female_ratio[,ik-1] = 2 * (1 - FRA_demo$rate$female[,ik]/FRA_demo$rate$female[,ik-1])/(1 + FRA_demo$rate$female[,ik]/FRA_demo$rate$female[,ik-1])
    FRA_male_ratio[,ik-1]   = 2 * (1 - FRA_demo$rate$male[,ik]/FRA_demo$rate$male[,ik-1])/(1 + FRA_demo$rate$male[,ik]/FRA_demo$rate$male[,ik-1])
    FRA_total_ratio[,ik-1]   = 2 * (1 - FRA_demo$rate$total[,ik]/FRA_demo$rate$total[,ik-1])/(1 + FRA_demo$rate$total[,ik]/FRA_demo$rate$total[,ik-1])
}  

FRA_female_smooth_ratio = FRA_male_smooth_ratio = FRA_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    FRA_female_smooth_ratio[,ik-1] = 2 * (1 - FRA_smooth$rate$female[,ik]/FRA_smooth$rate$female[,ik-1])/(1 + FRA_smooth$rate$female[,ik]/FRA_smooth$rate$female[,ik-1])
    FRA_male_smooth_ratio[,ik-1]   = 2 * (1 - FRA_smooth$rate$male[,ik]/FRA_smooth$rate$male[,ik-1])/(1 + FRA_smooth$rate$male[,ik]/FRA_smooth$rate$male[,ik-1])
    FRA_total_smooth_ratio[,ik-1]  = 2 * (1 - FRA_smooth$rate$total[,ik]/FRA_smooth$rate$total[,ik-1])/(1 + FRA_smooth$rate$total[,ik]/FRA_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(FRA_female_ratio); T_stationary(FRA_male_ratio); T_stationary(FRA_total_ratio) # 0.243 0.105 0.237
T_stationary(FRA_female_smooth_ratio); T_stationary(FRA_male_smooth_ratio); T_stationary(FRA_total_smooth_ratio)  # 0.359 0.109 0.261

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

FRA_smooth_dpca_arima_female = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_pca_arima_female = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_female_err = rbind(FRA_smooth_dpca_arima_female$err, FRA_smooth_pca_arima_female$err)
rownames(FRA_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

FRA_smooth_dpca_arima_female_fh_5 = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_pca_arima_female_fh_5 = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_female_err_fh_5 = rbind(FRA_smooth_dpca_arima_female_fh_5$err, FRA_smooth_pca_arima_female_fh_5$err)
rownames(FRA_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_smooth_dpca_arima_female_fh_10 = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_pca_arima_female_fh_10 = dpca_res(data = FRA_female_smooth_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_female_err_fh_10 = rbind(FRA_smooth_dpca_arima_female_fh_10$err, FRA_smooth_pca_arima_female_fh_10$err)
rownames(FRA_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

FRA_smooth_dpca_arima_male = dpca_res(data = FRA_male_smooth_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_pca_arima_male = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_male_err = rbind(FRA_smooth_dpca_arima_male$err, FRA_smooth_pca_arima_male$err)
rownames(FRA_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

FRA_smooth_dpca_arima_male_fh_5 = dpca_res(data = FRA_male_smooth_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_pca_arima_male_fh_5 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_male_err_fh_5 = rbind(FRA_smooth_dpca_arima_male_fh_5$err, FRA_smooth_pca_arima_male_fh_5$err)
rownames(FRA_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_smooth_dpca_arima_male_fh_10 = dpca_res(data = FRA_male_smooth_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_pca_arima_male_fh_10 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_male_err_fh_10 = rbind(FRA_smooth_dpca_arima_male_fh_10$err, FRA_smooth_pca_arima_male_fh_10$err)
rownames(FRA_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

FRA_smooth_dpca_arima_total = dpca_res(data = FRA_total_smooth_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_pca_arima_total = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

FRA_smooth_total_err = rbind(FRA_smooth_dpca_arima_total$err, FRA_smooth_pca_arima_total$err)
rownames(FRA_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

FRA_smooth_dpca_arima_total_fh_5 = dpca_res(data = FRA_total_smooth_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_pca_arima_total_fh_5 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

FRA_smooth_total_err_fh_5 = rbind(FRA_smooth_dpca_arima_total_fh_5$err, FRA_smooth_pca_arima_total_fh_5$err)
rownames(FRA_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_smooth_dpca_arima_total_fh_10 = dpca_res(data = FRA_total_smooth_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_pca_arima_total_fh_10 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

FRA_smooth_total_err_fh_10 = rbind(FRA_smooth_dpca_arima_total_fh_10$err, FRA_smooth_pca_arima_total_fh_10$err)
rownames(FRA_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

FRA_dpca_arima_female = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

FRA_pca_arima_female = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                               jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

FRA_female_err = rbind(FRA_dpca_arima_female$err, FRA_pca_arima_female$err)
rownames(FRA_female_err) = c("DPCA", "PCA")

# fh = 5

FRA_dpca_arima_female_fh_5 = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

FRA_pca_arima_female_fh_5 = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

FRA_female_err_fh_5 = rbind(FRA_dpca_arima_female_fh_5$err, FRA_pca_arima_female_fh_5$err)
rownames(FRA_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_dpca_arima_female_fh_10 = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

FRA_pca_arima_female_fh_10 = dpca_res(data = FRA_female_ratio, test_data = FRA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = FRA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

FRA_female_err_fh_10 = rbind(FRA_dpca_arima_female_fh_10$err, FRA_pca_arima_female_fh_10$err)
rownames(FRA_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

FRA_dpca_arima_male = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                              forecasting_method = "arima", fh = 1)

FRA_pca_arima_male = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                             jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                             forecasting_method = "arima", fh = 1)

FRA_male_err = rbind(FRA_dpca_arima_male$err, FRA_pca_arima_male$err)
rownames(FRA_male_err) = c("DPCA", "PCA")

# fh = 5

FRA_dpca_arima_male_fh_5 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

FRA_pca_arima_male_fh_5 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

FRA_male_err_fh_5 = rbind(FRA_dpca_arima_male_fh_5$err, FRA_pca_arima_male_fh_5$err)
rownames(FRA_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_dpca_arima_male_fh_10 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

FRA_pca_arima_male_fh_10 = dpca_res(data = FRA_male_ratio, test_data = FRA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = FRA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

FRA_male_err_fh_10 = rbind(FRA_dpca_arima_male_fh_10$err, FRA_pca_arima_male_fh_10$err)
rownames(FRA_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

FRA_dpca_arima_total = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

FRA_pca_arima_total = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

FRA_total_err = rbind(FRA_dpca_arima_total$err, FRA_pca_arima_total$err)
rownames(FRA_total_err) = c("DPCA", "PCA")

# fh = 5

FRA_dpca_arima_total_fh_5 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

FRA_pca_arima_total_fh_5 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

FRA_total_err_fh_5 = rbind(FRA_dpca_arima_total_fh_5$err, FRA_pca_arima_total_fh_5$err)
rownames(FRA_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

FRA_dpca_arima_total_fh_10 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

FRA_pca_arima_total_fh_10 = dpca_res(data = FRA_total_ratio, test_data = FRA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = FRA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

FRA_total_err_fh_10 = rbind(FRA_dpca_arima_total_fh_10$err, FRA_pca_arima_total_fh_10$err)
rownames(FRA_total_err_fh_10) = c("DPCA", "PCA")

