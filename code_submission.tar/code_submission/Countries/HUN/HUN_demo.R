rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

HUN_dummy = extract.ages(hmd.mx(country = "HUN", username = "shl8858@telstra.com", password = "hshang85", label = "HUN"), 0:100)
HUN_demo = extract.years(HUN_dummy, 1950:max(HUN_dummy$year))
HUN_smooth = smooth.demogdata(HUN_demo)
n_year = length(HUN_demo$year)

# convert non-stationary series to stationary series

HUN_female_dummy_ratio = HUN_male_dummy_ratio = HUN_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    HUN_female_dummy_ratio[,ik-1] = 2 * (1 - HUN_demo$rate$female[,ik]/HUN_demo$rate$female[,ik-1])/(1 + HUN_demo$rate$female[,ik]/HUN_demo$rate$female[,ik-1])
    HUN_male_dummy_ratio[,ik-1]   = 2 * (1 - HUN_demo$rate$male[,ik]/HUN_demo$rate$male[,ik-1])/(1 + HUN_demo$rate$male[,ik]/HUN_demo$rate$male[,ik-1])
    HUN_total_ratio[,ik-1]  = 2 * (1 - HUN_demo$rate$total[,ik]/HUN_demo$rate$total[,ik-1])/(1 + HUN_demo$rate$total[,ik]/HUN_demo$rate$total[,ik-1])
}  

HUN_female_ratio = na.locf(HUN_female_dummy_ratio)
HUN_male_ratio = na.locf(HUN_male_dummy_ratio)

HUN_female_smooth_ratio = HUN_male_smooth_ratio = HUN_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    HUN_female_smooth_ratio[,ik-1] = 2 * (1 - HUN_smooth$rate$female[,ik]/HUN_smooth$rate$female[,ik-1])/(1 + HUN_smooth$rate$female[,ik]/HUN_smooth$rate$female[,ik-1])
    HUN_male_smooth_ratio[,ik-1]   = 2 * (1 - HUN_smooth$rate$male[,ik]/HUN_smooth$rate$male[,ik-1])/(1 + HUN_smooth$rate$male[,ik]/HUN_smooth$rate$male[,ik-1])
    HUN_total_smooth_ratio[,ik-1]  = 2 * (1 - HUN_smooth$rate$total[,ik]/HUN_smooth$rate$total[,ik-1])/(1 + HUN_smooth$rate$total[,ik]/HUN_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(HUN_female_ratio); T_stationary(HUN_male_ratio); T_stationary(HUN_total_ratio)  # 0.136 0.106 0.195
T_stationary(HUN_female_smooth_ratio); T_stationary(HUN_male_smooth_ratio); T_stationary(HUN_total_smooth_ratio)   # 0.234 0.216 0.244 

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

HUN_smooth_dpca_arima_female = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_pca_arima_female = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_female_err = rbind(HUN_smooth_dpca_arima_female$err, HUN_smooth_pca_arima_female$err)
rownames(HUN_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

HUN_smooth_dpca_arima_female_fh_5 = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_pca_arima_female_fh_5 = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_female_err_fh_5 = rbind(HUN_smooth_dpca_arima_female_fh_5$err, HUN_smooth_pca_arima_female_fh_5$err)
rownames(HUN_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_smooth_dpca_arima_female_fh_10 = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_pca_arima_female_fh_10 = dpca_res(data = HUN_female_smooth_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_female_err_fh_10 = rbind(HUN_smooth_dpca_arima_female_fh_10$err, HUN_smooth_pca_arima_female_fh_10$err)
rownames(HUN_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

HUN_smooth_dpca_arima_male = dpca_res(data = HUN_male_smooth_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_pca_arima_male = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_male_err = rbind(HUN_smooth_dpca_arima_male$err, HUN_smooth_pca_arima_male$err)
rownames(HUN_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

HUN_smooth_dpca_arima_male_fh_5 = dpca_res(data = HUN_male_smooth_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_pca_arima_male_fh_5 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_male_err_fh_5 = rbind(HUN_smooth_dpca_arima_male_fh_5$err, HUN_smooth_pca_arima_male_fh_5$err)
rownames(HUN_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_smooth_dpca_arima_male_fh_10 = dpca_res(data = HUN_male_smooth_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_pca_arima_male_fh_10 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_male_err_fh_10 = rbind(HUN_smooth_dpca_arima_male_fh_10$err, HUN_smooth_pca_arima_male_fh_10$err)
rownames(HUN_smooth_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

HUN_smooth_dpca_arima_total = dpca_res(data = HUN_total_smooth_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_pca_arima_total = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

HUN_smooth_total_err = rbind(HUN_smooth_dpca_arima_total$err, HUN_smooth_pca_arima_total$err)
rownames(HUN_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

HUN_smooth_dpca_arima_total_fh_5 = dpca_res(data = HUN_total_smooth_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_pca_arima_total_fh_5 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

HUN_smooth_total_err_fh_5 = rbind(HUN_smooth_dpca_arima_total_fh_5$err, HUN_smooth_pca_arima_total_fh_5$err)
rownames(HUN_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_smooth_dpca_arima_total_fh_10 = dpca_res(data = HUN_total_smooth_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_pca_arima_total_fh_10 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

HUN_smooth_total_err_fh_10 = rbind(HUN_smooth_dpca_arima_total_fh_10$err, HUN_smooth_pca_arima_total_fh_10$err)
rownames(HUN_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

HUN_dpca_arima_female = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

HUN_pca_arima_female = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

HUN_female_err = rbind(HUN_dpca_arima_female$err, HUN_pca_arima_female$err)
rownames(HUN_female_err) = c("DPCA", "PCA")

# fh = 5

HUN_dpca_arima_female_fh_5 = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

HUN_pca_arima_female_fh_5 = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

HUN_female_err_fh_5 = rbind(HUN_dpca_arima_female_fh_5$err, HUN_pca_arima_female_fh_5$err)
rownames(HUN_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_dpca_arima_female_fh_10 = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

HUN_pca_arima_female_fh_10 = dpca_res(data = HUN_female_ratio, test_data = HUN_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = HUN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

HUN_female_err_fh_10 = rbind(HUN_dpca_arima_female_fh_10$err, HUN_pca_arima_female_fh_10$err)
rownames(HUN_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

HUN_dpca_arima_male = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

HUN_pca_arima_male = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

HUN_male_err = rbind(HUN_dpca_arima_male$err, HUN_pca_arima_male$err)
rownames(HUN_male_err) = c("DPCA", "PCA")

# fh = 5

HUN_dpca_arima_male_fh_5 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

HUN_pca_arima_male_fh_5 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

HUN_male_err_fh_5 = rbind(HUN_dpca_arima_male_fh_5$err, HUN_pca_arima_male_fh_5$err)
rownames(HUN_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_dpca_arima_male_fh_10 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

HUN_pca_arima_male_fh_10 = dpca_res(data = HUN_male_ratio, test_data = HUN_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = HUN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

HUN_male_err_fh_10 = rbind(HUN_dpca_arima_male_fh_10$err, HUN_pca_arima_male_fh_10$err)
rownames(HUN_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

HUN_dpca_arima_total = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

HUN_pca_arima_total = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

HUN_total_err = rbind(HUN_dpca_arima_total$err, HUN_pca_arima_total$err)
rownames(HUN_total_err) = c("DPCA", "PCA")

# fh = 5

HUN_dpca_arima_total_fh_5 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

HUN_pca_arima_total_fh_5 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

HUN_total_err_fh_5 = rbind(HUN_dpca_arima_total_fh_5$err, HUN_pca_arima_total_fh_5$err)
rownames(HUN_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

HUN_dpca_arima_total_fh_10 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

HUN_pca_arima_total_fh_10 = dpca_res(data = HUN_total_ratio, test_data = HUN_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = HUN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

HUN_total_err_fh_10 = rbind(HUN_dpca_arima_total_fh_10$err, HUN_pca_arima_total_fh_10$err)
rownames(HUN_total_err_fh_10) = c("DPCA", "PCA")

