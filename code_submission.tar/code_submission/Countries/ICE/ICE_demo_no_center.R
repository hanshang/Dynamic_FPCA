source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

ICE_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_pca_arima_female_no_center = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_female_err_no_center = rbind(ICE_smooth_dpca_arima_female_no_center$err, ICE_smooth_pca_arima_female_no_center$err)
rownames(ICE_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

ICE_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_female_err_no_center_fh_5 = rbind(ICE_smooth_dpca_arima_female_no_center_fh_5$err, ICE_smooth_pca_arima_female_no_center_fh_5$err)
rownames(ICE_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ICE_female_smooth_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_female_no_center_err_fh_10 = rbind(ICE_smooth_dpca_arima_female_no_center_fh_10$err, ICE_smooth_pca_arima_female_no_center_fh_10$err)
rownames(ICE_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

ICE_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = ICE_male_smooth_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_pca_arima_male_no_center = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_male_err_no_center = rbind(ICE_smooth_dpca_arima_male_no_center$err, ICE_smooth_pca_arima_male_no_center$err)
rownames(ICE_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

ICE_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ICE_male_smooth_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_male_no_center_err_fh_5 = rbind(ICE_smooth_dpca_arima_male_no_center_fh_5$err, ICE_smooth_pca_arima_male_no_center_fh_5$err)
rownames(ICE_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ICE_male_smooth_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_male_no_center_err_fh_10 = rbind(ICE_smooth_dpca_arima_male_no_center_fh_10$err, ICE_smooth_pca_arima_male_no_center_fh_10$err)
rownames(ICE_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

ICE_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = ICE_total_smooth_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_pca_arima_total_no_center = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ICE_smooth_total_err_no_center = rbind(ICE_smooth_dpca_arima_total_no_center$err, ICE_smooth_pca_arima_total_no_center$err)
rownames(ICE_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

ICE_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ICE_total_smooth_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ICE_smooth_total_no_center_err_fh_5 = rbind(ICE_smooth_dpca_arima_total_no_center_fh_5$err, ICE_smooth_pca_arima_total_no_center_fh_5$err)
rownames(ICE_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ICE_total_smooth_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ICE_smooth_total_no_center_err_fh_10 = rbind(ICE_smooth_dpca_arima_total_no_center_fh_10$err, ICE_smooth_pca_arima_total_no_center_fh_10$err)
rownames(ICE_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

ICE_dpca_arima_female_no_center = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

ICE_pca_arima_female_no_center = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

ICE_female_err_no_center = rbind(ICE_dpca_arima_female_no_center$err, ICE_pca_arima_female_no_center$err)
rownames(ICE_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

ICE_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

ICE_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

ICE_female_err_no_center_fh_5 = rbind(ICE_dpca_arima_female_no_center_fh_5$err, ICE_pca_arima_female_no_center_fh_5$err)
rownames(ICE_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

ICE_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ICE_female_ratio, test_data = ICE_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = ICE_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

ICE_female_err_no_center_fh_10 = rbind(ICE_dpca_arima_female_no_center_fh_10$err, ICE_pca_arima_female_no_center_fh_10$err)
rownames(ICE_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

ICE_dpca_arima_male_no_center = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

ICE_pca_arima_male_no_center = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

ICE_male_err_no_center = rbind(ICE_dpca_arima_male_no_center$err, ICE_pca_arima_male_no_center$err)
rownames(ICE_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

ICE_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

ICE_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

ICE_male_err_no_center_fh_5 = rbind(ICE_dpca_arima_male_no_center_fh_5$err, ICE_pca_arima_male_no_center_fh_5$err)
rownames(ICE_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

ICE_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ICE_male_ratio, test_data = ICE_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = ICE_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

ICE_male_err_no_center_fh_10 = rbind(ICE_dpca_arima_male_no_center_fh_10$err, ICE_pca_arima_male_no_center_fh_10$err)
rownames(ICE_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

ICE_dpca_arima_total_no_center = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

ICE_pca_arima_total_no_center = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

ICE_total_err_no_center = rbind(ICE_dpca_arima_total_no_center$err, ICE_pca_arima_total_no_center$err)
rownames(ICE_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

ICE_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

ICE_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

ICE_total_err_no_center_fh_5 = rbind(ICE_dpca_arima_total_no_center_fh_5$err, ICE_pca_arima_total_no_center_fh_5$err)
rownames(ICE_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ICE_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

ICE_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ICE_total_ratio, test_data = ICE_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = ICE_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

ICE_total_err_no_center_fh_10 = rbind(ICE_dpca_arima_total_no_center_fh_10$err, ICE_pca_arima_total_no_center_fh_10$err)
rownames(ICE_total_err_no_center_fh_10) = c("DPCA", "PCA")

