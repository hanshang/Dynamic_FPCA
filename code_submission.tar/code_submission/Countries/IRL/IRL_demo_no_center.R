source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

IRL_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_pca_arima_female_no_center = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_female_err_no_center = rbind(IRL_smooth_dpca_arima_female_no_center$err, IRL_smooth_pca_arima_female_no_center$err)
rownames(IRL_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

IRL_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_female_err_no_center_fh_5 = rbind(IRL_smooth_dpca_arima_female_no_center_fh_5$err, IRL_smooth_pca_arima_female_no_center_fh_5$err)
rownames(IRL_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = IRL_female_smooth_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_female_no_center_err_fh_10 = rbind(IRL_smooth_dpca_arima_female_no_center_fh_10$err, IRL_smooth_pca_arima_female_no_center_fh_10$err)
rownames(IRL_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

IRL_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = IRL_male_smooth_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_pca_arima_male_no_center = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_male_err_no_center = rbind(IRL_smooth_dpca_arima_male_no_center$err, IRL_smooth_pca_arima_male_no_center$err)
rownames(IRL_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

IRL_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = IRL_male_smooth_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_male_no_center_err_fh_5 = rbind(IRL_smooth_dpca_arima_male_no_center_fh_5$err, IRL_smooth_pca_arima_male_no_center_fh_5$err)
rownames(IRL_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = IRL_male_smooth_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_male_no_center_err_fh_10 = rbind(IRL_smooth_dpca_arima_male_no_center_fh_10$err, IRL_smooth_pca_arima_male_no_center_fh_10$err)
rownames(IRL_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

IRL_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = IRL_total_smooth_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_pca_arima_total_no_center = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

IRL_smooth_total_err_no_center = rbind(IRL_smooth_dpca_arima_total_no_center$err, IRL_smooth_pca_arima_total_no_center$err)
rownames(IRL_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

IRL_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = IRL_total_smooth_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

IRL_smooth_total_no_center_err_fh_5 = rbind(IRL_smooth_dpca_arima_total_no_center_fh_5$err, IRL_smooth_pca_arima_total_no_center_fh_5$err)
rownames(IRL_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = IRL_total_smooth_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

IRL_smooth_total_no_center_err_fh_10 = rbind(IRL_smooth_dpca_arima_total_no_center_fh_10$err, IRL_smooth_pca_arima_total_no_center_fh_10$err)
rownames(IRL_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

IRL_dpca_arima_female_no_center = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

IRL_pca_arima_female_no_center = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

IRL_female_err_no_center = rbind(IRL_dpca_arima_female_no_center$err, IRL_pca_arima_female_no_center$err)
rownames(IRL_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

IRL_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

IRL_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

IRL_female_err_no_center_fh_5 = rbind(IRL_dpca_arima_female_no_center_fh_5$err, IRL_pca_arima_female_no_center_fh_5$err)
rownames(IRL_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

IRL_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = IRL_female_ratio, test_data = IRL_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = IRL_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

IRL_female_err_no_center_fh_10 = rbind(IRL_dpca_arima_female_no_center_fh_10$err, IRL_pca_arima_female_no_center_fh_10$err)
rownames(IRL_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

IRL_dpca_arima_male_no_center = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

IRL_pca_arima_male_no_center = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

IRL_male_err_no_center = rbind(IRL_dpca_arima_male_no_center$err, IRL_pca_arima_male_no_center$err)
rownames(IRL_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

IRL_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

IRL_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

IRL_male_err_no_center_fh_5 = rbind(IRL_dpca_arima_male_no_center_fh_5$err, IRL_pca_arima_male_no_center_fh_5$err)
rownames(IRL_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

IRL_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = IRL_male_ratio, test_data = IRL_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = IRL_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

IRL_male_err_no_center_fh_10 = rbind(IRL_dpca_arima_male_no_center_fh_10$err, IRL_pca_arima_male_no_center_fh_10$err)
rownames(IRL_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

IRL_dpca_arima_total_no_center = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

IRL_pca_arima_total_no_center = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

IRL_total_err_no_center = rbind(IRL_dpca_arima_total_no_center$err, IRL_pca_arima_total_no_center$err)
rownames(IRL_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

IRL_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

IRL_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

IRL_total_err_no_center_fh_5 = rbind(IRL_dpca_arima_total_no_center_fh_5$err, IRL_pca_arima_total_no_center_fh_5$err)
rownames(IRL_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

IRL_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

IRL_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = IRL_total_ratio, test_data = IRL_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = IRL_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

IRL_total_err_no_center_fh_10 = rbind(IRL_dpca_arima_total_no_center_fh_10$err, IRL_pca_arima_total_no_center_fh_10$err)
rownames(IRL_total_err_no_center_fh_10) = c("DPCA", "PCA")

