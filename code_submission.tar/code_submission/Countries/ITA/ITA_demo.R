rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

ITA_dummy = extract.ages(hmd.mx(country = "ITA", username = "shl8858@telstra.com", password = "hshang85", label = "ITA"), 0:100)
ITA_demo = extract.years(ITA_dummy, 1950:max(ITA_dummy$year))
ITA_smooth = smooth.demogdata(ITA_demo)
n_year = length(ITA_demo$year)

# convert non-stationary series to stationary series

ITA_female_ratio = ITA_male_ratio = ITA_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    ITA_female_ratio[,ik-1] = 2 * (1 - ITA_demo$rate$female[,ik]/ITA_demo$rate$female[,ik-1])/(1 + ITA_demo$rate$female[,ik]/ITA_demo$rate$female[,ik-1])
    ITA_male_ratio[,ik-1]   = 2 * (1 - ITA_demo$rate$male[,ik]/ITA_demo$rate$male[,ik-1])/(1 + ITA_demo$rate$male[,ik]/ITA_demo$rate$male[,ik-1])
    ITA_total_ratio[,ik-1]   = 2 * (1 - ITA_demo$rate$total[,ik]/ITA_demo$rate$total[,ik-1])/(1 + ITA_demo$rate$total[,ik]/ITA_demo$rate$total[,ik-1])
}  

ITA_female_smooth_ratio = ITA_male_smooth_ratio = ITA_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    ITA_female_smooth_ratio[,ik-1] = 2 * (1 - ITA_smooth$rate$female[,ik]/ITA_smooth$rate$female[,ik-1])/(1 + ITA_smooth$rate$female[,ik]/ITA_smooth$rate$female[,ik-1])
    ITA_male_smooth_ratio[,ik-1]   = 2 * (1 - ITA_smooth$rate$male[,ik]/ITA_smooth$rate$male[,ik-1])/(1 + ITA_smooth$rate$male[,ik]/ITA_smooth$rate$male[,ik-1])
    ITA_total_smooth_ratio[,ik-1]  = 2 * (1 - ITA_smooth$rate$total[,ik]/ITA_smooth$rate$total[,ik-1])/(1 + ITA_smooth$rate$total[,ik]/ITA_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(ITA_female_ratio); T_stationary(ITA_male_ratio); T_stationary(ITA_total_ratio)  # 0.113 0.08 0.138
T_stationary(ITA_female_smooth_ratio); T_stationary(ITA_male_smooth_ratio); T_stationary(ITA_total_smooth_ratio) # 0.172 0.088 0.206

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

ITA_smooth_dpca_arima_female = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_female = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_female_err = rbind(ITA_smooth_dpca_arima_female$err, ITA_smooth_pca_arima_female$err)
rownames(ITA_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_female_fh_5 = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_female_fh_5 = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_female_err_fh_5 = rbind(ITA_smooth_dpca_arima_female_fh_5$err, ITA_smooth_pca_arima_female_fh_5$err)
rownames(ITA_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_female_fh_10 = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_female_fh_10 = dpca_res(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_female_err_fh_10 = rbind(ITA_smooth_dpca_arima_female_fh_10$err, ITA_smooth_pca_arima_female_fh_10$err)
rownames(ITA_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1 

ITA_smooth_dpca_arima_male = dpca_res(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_male = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_male_err = rbind(ITA_smooth_dpca_arima_male$err, ITA_smooth_pca_arima_male$err)
rownames(ITA_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_male_fh_5 = dpca_res(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_male_fh_5 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_male_err_fh_5 = rbind(ITA_smooth_dpca_arima_male_fh_5$err, ITA_smooth_pca_arima_male_fh_5$err)
rownames(ITA_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_male_fh_10 = dpca_res(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_male_fh_10 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_male_err_fh_10 = rbind(ITA_smooth_dpca_arima_male_fh_10$err, ITA_smooth_pca_arima_male_fh_10$err)
rownames(ITA_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

ITA_smooth_dpca_arima_total = dpca_res(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_total = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_total_err = rbind(ITA_smooth_dpca_arima_total$err, ITA_smooth_pca_arima_total$err)
rownames(ITA_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_total_fh_5 = dpca_res(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_total_fh_5 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_total_err_fh_5 = rbind(ITA_smooth_dpca_arima_total_fh_5$err, ITA_smooth_pca_arima_total_fh_5$err)
rownames(ITA_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_total_fh_10 = dpca_res(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_total_fh_10 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_total_err_fh_10 = rbind(ITA_smooth_dpca_arima_total_fh_10$err, ITA_smooth_pca_arima_total_fh_10$err)
rownames(ITA_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

ITA_dpca_arima_female = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

ITA_pca_arima_female = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

ITA_female_err = rbind(ITA_dpca_arima_female$err, ITA_pca_arima_female$err)
rownames(ITA_female_err) = c("DPCA", "PCA")

# fh = 5

ITA_dpca_arima_female_fh_5 = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

ITA_pca_arima_female_fh_5 = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

ITA_female_err_fh_5 = rbind(ITA_dpca_arima_female_fh_5$err, ITA_pca_arima_female_fh_5$err)
rownames(ITA_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_female_fh_10 = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

ITA_pca_arima_female_fh_10 = dpca_res(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

ITA_female_err_fh_10 = rbind(ITA_dpca_arima_female_fh_10$err, ITA_pca_arima_female_fh_10$err)
rownames(ITA_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

ITA_dpca_arima_male = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

ITA_pca_arima_male = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

ITA_male_err = rbind(ITA_dpca_arima_male$err, ITA_pca_arima_male$err)
rownames(ITA_male_err) = c("DPCA", "PCA")

# fh = 5

ITA_dpca_arima_male_fh_5 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

ITA_pca_arima_male_fh_5 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

ITA_male_err_fh_5 = rbind(ITA_dpca_arima_male_fh_5$err, ITA_pca_arima_male_fh_5$err)
rownames(ITA_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_male_fh_10 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

ITA_pca_arima_male_fh_10 = dpca_res(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

ITA_male_err_fh_10 = rbind(ITA_dpca_arima_male_fh_10$err, ITA_pca_arima_male_fh_10$err)
rownames(ITA_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

ITA_dpca_arima_total = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

ITA_pca_arima_total = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

ITA_total_err = rbind(ITA_dpca_arima_total$err, ITA_pca_arima_total$err)
rownames(ITA_total_err) = c("DPCA", "PCA")

# fh = 5

ITA_dpca_arima_total_fh_5 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

ITA_pca_arima_total_fh_5 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

ITA_total_err_fh_5 = rbind(ITA_dpca_arima_total_fh_5$err, ITA_pca_arima_total_fh_5$err)
rownames(ITA_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_total_fh_10 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

ITA_pca_arima_total_fh_10 = dpca_res(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

ITA_total_err_fh_10 = rbind(ITA_dpca_arima_total_fh_10$err, ITA_pca_arima_total_fh_10$err)
rownames(ITA_total_err_fh_10) = c("DPCA", "PCA")
