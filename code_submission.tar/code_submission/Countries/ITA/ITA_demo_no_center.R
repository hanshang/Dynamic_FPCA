source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

ITA_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_female_no_center = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_female_err_no_center = rbind(ITA_smooth_dpca_arima_female_no_center$err, ITA_smooth_pca_arima_female_no_center$err)
rownames(ITA_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_female_err_no_center_fh_5 = rbind(ITA_smooth_dpca_arima_female_no_center_fh_5$err, ITA_smooth_pca_arima_female_no_center_fh_5$err)
rownames(ITA_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ITA_female_smooth_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_female_no_center_err_fh_10 = rbind(ITA_smooth_dpca_arima_female_no_center_fh_10$err, ITA_smooth_pca_arima_female_no_center_fh_10$err)
rownames(ITA_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

ITA_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_male_no_center = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_male_err_no_center = rbind(ITA_smooth_dpca_arima_male_no_center$err, ITA_smooth_pca_arima_male_no_center$err)
rownames(ITA_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_male_no_center_err_fh_5 = rbind(ITA_smooth_dpca_arima_male_no_center_fh_5$err, ITA_smooth_pca_arima_male_no_center_fh_5$err)
rownames(ITA_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ITA_male_smooth_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_male_no_center_err_fh_10 = rbind(ITA_smooth_dpca_arima_male_no_center_fh_10$err, ITA_smooth_pca_arima_male_no_center_fh_10$err)
rownames(ITA_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

ITA_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_pca_arima_total_no_center = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

ITA_smooth_total_err_no_center = rbind(ITA_smooth_dpca_arima_total_no_center$err, ITA_smooth_pca_arima_total_no_center$err)
rownames(ITA_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

ITA_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

ITA_smooth_total_no_center_err_fh_5 = rbind(ITA_smooth_dpca_arima_total_no_center_fh_5$err, ITA_smooth_pca_arima_total_no_center_fh_5$err)
rownames(ITA_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ITA_total_smooth_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

ITA_smooth_total_no_center_err_fh_10 = rbind(ITA_smooth_dpca_arima_total_no_center_fh_10$err, ITA_smooth_pca_arima_total_no_center_fh_10$err)
rownames(ITA_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

ITA_dpca_arima_female_no_center = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

ITA_pca_arima_female_no_center = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

ITA_female_err_no_center = rbind(ITA_dpca_arima_female_no_center$err, ITA_pca_arima_female_no_center$err)
rownames(ITA_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

ITA_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

ITA_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

ITA_female_err_no_center_fh_5 = rbind(ITA_dpca_arima_female_no_center_fh_5$err, ITA_pca_arima_female_no_center_fh_5$err)
rownames(ITA_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

ITA_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = ITA_female_ratio, test_data = ITA_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = ITA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

ITA_female_err_no_center_fh_10 = rbind(ITA_dpca_arima_female_no_center_fh_10$err, ITA_pca_arima_female_no_center_fh_10$err)
rownames(ITA_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

ITA_dpca_arima_male_no_center = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

ITA_pca_arima_male_no_center = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

ITA_male_err_no_center = rbind(ITA_dpca_arima_male_no_center$err, ITA_pca_arima_male_no_center$err)
rownames(ITA_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

ITA_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

ITA_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

ITA_male_err_no_center_fh_5 = rbind(ITA_dpca_arima_male_no_center_fh_5$err, ITA_pca_arima_male_no_center_fh_5$err)
rownames(ITA_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

ITA_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = ITA_male_ratio, test_data = ITA_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = ITA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

ITA_male_err_no_center_fh_10 = rbind(ITA_dpca_arima_male_no_center_fh_10$err, ITA_pca_arima_male_no_center_fh_10$err)
rownames(ITA_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

ITA_dpca_arima_total_no_center = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

ITA_pca_arima_total_no_center = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

ITA_total_err_no_center = rbind(ITA_dpca_arima_total_no_center$err, ITA_pca_arima_total_no_center$err)
rownames(ITA_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

ITA_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

ITA_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

ITA_total_err_no_center_fh_5 = rbind(ITA_dpca_arima_total_no_center_fh_5$err, ITA_pca_arima_total_no_center_fh_5$err)
rownames(ITA_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

ITA_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

ITA_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = ITA_total_ratio, test_data = ITA_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = ITA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

ITA_total_err_no_center_fh_10 = rbind(ITA_dpca_arima_total_no_center_fh_10$err, ITA_pca_arima_total_no_center_fh_10$err)
rownames(ITA_total_err_no_center_fh_10) = c("DPCA", "PCA")

