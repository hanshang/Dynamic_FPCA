source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

JPN_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_pca_arima_female_no_center = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_female_err_no_center = rbind(JPN_smooth_dpca_arima_female_no_center$err, JPN_smooth_pca_arima_female_no_center$err)
rownames(JPN_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

JPN_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_female_err_no_center_fh_5 = rbind(JPN_smooth_dpca_arima_female_no_center_fh_5$err, JPN_smooth_pca_arima_female_no_center_fh_5$err)
rownames(JPN_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = JPN_female_smooth_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_female_no_center_err_fh_10 = rbind(JPN_smooth_dpca_arima_female_no_center_fh_10$err, JPN_smooth_pca_arima_female_no_center_fh_10$err)
rownames(JPN_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

JPN_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = JPN_male_smooth_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_pca_arima_male_no_center = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_male_err_no_center = rbind(JPN_smooth_dpca_arima_male_no_center$err, JPN_smooth_pca_arima_male_no_center$err)
rownames(JPN_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

JPN_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = JPN_male_smooth_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_male_no_center_err_fh_5 = rbind(JPN_smooth_dpca_arima_male_no_center_fh_5$err, JPN_smooth_pca_arima_male_no_center_fh_5$err)
rownames(JPN_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = JPN_male_smooth_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_male_no_center_err_fh_10 = rbind(JPN_smooth_dpca_arima_male_no_center_fh_10$err, JPN_smooth_pca_arima_male_no_center_fh_10$err)
rownames(JPN_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

JPN_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = JPN_total_smooth_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_pca_arima_total_no_center = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

JPN_smooth_total_err_no_center = rbind(JPN_smooth_dpca_arima_total_no_center$err, JPN_smooth_pca_arima_total_no_center$err)
rownames(JPN_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

JPN_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = JPN_total_smooth_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

JPN_smooth_total_no_center_err_fh_5 = rbind(JPN_smooth_dpca_arima_total_no_center_fh_5$err, JPN_smooth_pca_arima_total_no_center_fh_5$err)
rownames(JPN_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = JPN_total_smooth_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

JPN_smooth_total_no_center_err_fh_10 = rbind(JPN_smooth_dpca_arima_total_no_center_fh_10$err, JPN_smooth_pca_arima_total_no_center_fh_10$err)
rownames(JPN_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

JPN_dpca_arima_female_no_center = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

JPN_pca_arima_female_no_center = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

JPN_female_err_no_center = rbind(JPN_dpca_arima_female_no_center$err, JPN_pca_arima_female_no_center$err)
rownames(JPN_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

JPN_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

JPN_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

JPN_female_err_no_center_fh_5 = rbind(JPN_dpca_arima_female_no_center_fh_5$err, JPN_pca_arima_female_no_center_fh_5$err)
rownames(JPN_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

JPN_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = JPN_female_ratio, test_data = JPN_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = JPN_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

JPN_female_err_no_center_fh_10 = rbind(JPN_dpca_arima_female_no_center_fh_10$err, JPN_pca_arima_female_no_center_fh_10$err)
rownames(JPN_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

JPN_dpca_arima_male_no_center = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

JPN_pca_arima_male_no_center = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

JPN_male_err_no_center = rbind(JPN_dpca_arima_male_no_center$err, JPN_pca_arima_male_no_center$err)
rownames(JPN_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

JPN_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

JPN_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

JPN_male_err_no_center_fh_5 = rbind(JPN_dpca_arima_male_no_center_fh_5$err, JPN_pca_arima_male_no_center_fh_5$err)
rownames(JPN_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

JPN_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = JPN_male_ratio, test_data = JPN_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = JPN_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

JPN_male_err_no_center_fh_10 = rbind(JPN_dpca_arima_male_no_center_fh_10$err, JPN_pca_arima_male_no_center_fh_10$err)
rownames(JPN_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

JPN_dpca_arima_total_no_center = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

JPN_pca_arima_total_no_center = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

JPN_total_err_no_center = rbind(JPN_dpca_arima_total_no_center$err, JPN_pca_arima_total_no_center$err)
rownames(JPN_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

JPN_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

JPN_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

JPN_total_err_no_center_fh_5 = rbind(JPN_dpca_arima_total_no_center_fh_5$err, JPN_pca_arima_total_no_center_fh_5$err)
rownames(JPN_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

JPN_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

JPN_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = JPN_total_ratio, test_data = JPN_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = JPN_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

JPN_total_err_no_center_fh_10 = rbind(JPN_dpca_arima_total_no_center_fh_10$err, JPN_pca_arima_total_no_center_fh_10$err)
rownames(JPN_total_err_no_center_fh_10) = c("DPCA", "PCA")

