source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

NLD_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_pca_arima_female_no_center = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_female_err_no_center = rbind(NLD_smooth_dpca_arima_female_no_center$err, NLD_smooth_pca_arima_female_no_center$err)
rownames(NLD_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

NLD_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_female_err_no_center_fh_5 = rbind(NLD_smooth_dpca_arima_female_no_center_fh_5$err, NLD_smooth_pca_arima_female_no_center_fh_5$err)
rownames(NLD_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NLD_female_smooth_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_female_no_center_err_fh_10 = rbind(NLD_smooth_dpca_arima_female_no_center_fh_10$err, NLD_smooth_pca_arima_female_no_center_fh_10$err)
rownames(NLD_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

NLD_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = NLD_male_smooth_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_pca_arima_male_no_center = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_male_err_no_center = rbind(NLD_smooth_dpca_arima_male_no_center$err, NLD_smooth_pca_arima_male_no_center$err)
rownames(NLD_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

NLD_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NLD_male_smooth_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_male_no_center_err_fh_5 = rbind(NLD_smooth_dpca_arima_male_no_center_fh_5$err, NLD_smooth_pca_arima_male_no_center_fh_5$err)
rownames(NLD_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NLD_male_smooth_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_male_no_center_err_fh_10 = rbind(NLD_smooth_dpca_arima_male_no_center_fh_10$err, NLD_smooth_pca_arima_male_no_center_fh_10$err)
rownames(NLD_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

NLD_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = NLD_total_smooth_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_pca_arima_total_no_center = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NLD_smooth_total_err_no_center = rbind(NLD_smooth_dpca_arima_total_no_center$err, NLD_smooth_pca_arima_total_no_center$err)
rownames(NLD_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

NLD_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NLD_total_smooth_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NLD_smooth_total_no_center_err_fh_5 = rbind(NLD_smooth_dpca_arima_total_no_center_fh_5$err, NLD_smooth_pca_arima_total_no_center_fh_5$err)
rownames(NLD_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NLD_total_smooth_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NLD_smooth_total_no_center_err_fh_10 = rbind(NLD_smooth_dpca_arima_total_no_center_fh_10$err, NLD_smooth_pca_arima_total_no_center_fh_10$err)
rownames(NLD_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

NLD_dpca_arima_female_no_center = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

NLD_pca_arima_female_no_center = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

NLD_female_err_no_center = rbind(NLD_dpca_arima_female_no_center$err, NLD_pca_arima_female_no_center$err)
rownames(NLD_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

NLD_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

NLD_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

NLD_female_err_no_center_fh_5 = rbind(NLD_dpca_arima_female_no_center_fh_5$err, NLD_pca_arima_female_no_center_fh_5$err)
rownames(NLD_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

NLD_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NLD_female_ratio, test_data = NLD_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = NLD_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

NLD_female_err_no_center_fh_10 = rbind(NLD_dpca_arima_female_no_center_fh_10$err, NLD_pca_arima_female_no_center_fh_10$err)
rownames(NLD_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

NLD_dpca_arima_male_no_center = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

NLD_pca_arima_male_no_center = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

NLD_male_err_no_center = rbind(NLD_dpca_arima_male_no_center$err, NLD_pca_arima_male_no_center$err)
rownames(NLD_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

NLD_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

NLD_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

NLD_male_err_no_center_fh_5 = rbind(NLD_dpca_arima_male_no_center_fh_5$err, NLD_pca_arima_male_no_center_fh_5$err)
rownames(NLD_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

NLD_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NLD_male_ratio, test_data = NLD_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = NLD_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

NLD_male_err_no_center_fh_10 = rbind(NLD_dpca_arima_male_no_center_fh_10$err, NLD_pca_arima_male_no_center_fh_10$err)
rownames(NLD_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

NLD_dpca_arima_total_no_center = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

NLD_pca_arima_total_no_center = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

NLD_total_err_no_center = rbind(NLD_dpca_arima_total_no_center$err, NLD_pca_arima_total_no_center$err)
rownames(NLD_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

NLD_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

NLD_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

NLD_total_err_no_center_fh_5 = rbind(NLD_dpca_arima_total_no_center_fh_5$err, NLD_pca_arima_total_no_center_fh_5$err)
rownames(NLD_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NLD_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

NLD_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NLD_total_ratio, test_data = NLD_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = NLD_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

NLD_total_err_no_center_fh_10 = rbind(NLD_dpca_arima_total_no_center_fh_10$err, NLD_pca_arima_total_no_center_fh_10$err)
rownames(NLD_total_err_no_center_fh_10) = c("DPCA", "PCA")

