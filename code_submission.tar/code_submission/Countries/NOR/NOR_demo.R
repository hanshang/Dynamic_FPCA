rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

NOR_dummy = extract.ages(hmd.mx(country = "NOR", username = "shl8858@telstra.com", password = "hshang85", label = "NOR"), 0:100)
NOR_demo = extract.years(NOR_dummy, 1950:max(NOR_dummy$year))
NOR_smooth = smooth.demogdata(NOR_demo)
n_year = length(NOR_demo$year)

# convert non-stationary series to stationary series

NOR_female_dummy_ratio = NOR_male_dummy_ratio = NOR_total_dummy_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    NOR_female_dummy_ratio[,ik-1] = 2 * (1 - NOR_demo$rate$female[,ik]/NOR_demo$rate$female[,ik-1])/(1 + NOR_demo$rate$female[,ik]/NOR_demo$rate$female[,ik-1])
    NOR_male_dummy_ratio[,ik-1]   = 2 * (1 - NOR_demo$rate$male[,ik]/NOR_demo$rate$male[,ik-1])/(1 + NOR_demo$rate$male[,ik]/NOR_demo$rate$male[,ik-1])
    NOR_total_dummy_ratio[,ik-1]  = 2 * (1 - NOR_demo$rate$total[,ik]/NOR_demo$rate$total[,ik-1])/(1 + NOR_demo$rate$total[,ik]/NOR_demo$rate$total[,ik-1])
}  

which(!is.finite(NOR_female_dummy_ratio))
which(!is.finite(NOR_male_dummy_ratio))
which(!is.finite(NOR_total_dummy_ratio))

NOR_female_ratio = na.locf(NOR_female_dummy_ratio)
NOR_male_ratio   = na.locf(NOR_male_dummy_ratio)
NOR_total_ratio  = na.locf(NOR_total_dummy_ratio)


NOR_female_smooth_ratio = NOR_male_smooth_ratio = NOR_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    NOR_female_smooth_ratio[,ik-1] = 2 * (1 - NOR_smooth$rate$female[,ik]/NOR_smooth$rate$female[,ik-1])/(1 + NOR_smooth$rate$female[,ik]/NOR_smooth$rate$female[,ik-1])
    NOR_male_smooth_ratio[,ik-1]   = 2 * (1 - NOR_smooth$rate$male[,ik]/NOR_smooth$rate$male[,ik-1])/(1 + NOR_smooth$rate$male[,ik]/NOR_smooth$rate$male[,ik-1])
    NOR_total_smooth_ratio[,ik-1]  = 2 * (1 - NOR_smooth$rate$total[,ik]/NOR_smooth$rate$total[,ik-1])/(1 + NOR_smooth$rate$total[,ik]/NOR_smooth$rate$total[,ik-1])
}


# compute p-value for the stationary hypothesis tests

T_stationary(NOR_female_ratio); T_stationary(NOR_male_ratio); T_stationary(NOR_total_ratio)  # 0.005 0.011 0.028
T_stationary(NOR_female_smooth_ratio); T_stationary(NOR_male_smooth_ratio); T_stationary(NOR_total_smooth_ratio)  # 0.282 0.039 0.116

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

NOR_smooth_dpca_arima_female = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_female = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_female_err = rbind(NOR_smooth_dpca_arima_female$err, NOR_smooth_pca_arima_female$err)
rownames(NOR_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_female_fh_5 = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_female_fh_5 = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_female_err_fh_5 = rbind(NOR_smooth_dpca_arima_female_fh_5$err, NOR_smooth_pca_arima_female_fh_5$err)
rownames(NOR_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_female_fh_10 = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_female_fh_10 = dpca_res(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_female_err_fh_10 = rbind(NOR_smooth_dpca_arima_female_fh_10$err, NOR_smooth_pca_arima_female_fh_10$err)
rownames(NOR_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

NOR_smooth_dpca_arima_male = dpca_res(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_male = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_male_err = rbind(NOR_smooth_dpca_arima_male$err, NOR_smooth_pca_arima_male$err)
rownames(NOR_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_male_fh_5 = dpca_res(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_male_fh_5 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_male_err_fh_5 = rbind(NOR_smooth_dpca_arima_male_fh_5$err, NOR_smooth_pca_arima_male_fh_5$err)
rownames(NOR_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_male_fh_10 = dpca_res(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_male_fh_10 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_male_err_fh_10 = rbind(NOR_smooth_dpca_arima_male_fh_10$err, NOR_smooth_pca_arima_male_fh_10$err)
rownames(NOR_smooth_male_err_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

NOR_smooth_dpca_arima_total = dpca_res(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_total = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_total_err = rbind(NOR_smooth_dpca_arima_total$err, NOR_smooth_pca_arima_total$err)
rownames(NOR_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_total_fh_5 = dpca_res(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_total_fh_5 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_total_err_fh_5 = rbind(NOR_smooth_dpca_arima_total_fh_5$err, NOR_smooth_pca_arima_total_fh_5$err)
rownames(NOR_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_total_fh_10 = dpca_res(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_total_fh_10 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_total_err_fh_10 = rbind(NOR_smooth_dpca_arima_total_fh_10$err, NOR_smooth_pca_arima_total_fh_10$err)
rownames(NOR_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

NOR_dpca_arima_female = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

NOR_pca_arima_female = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

NOR_female_err = rbind(NOR_dpca_arima_female$err, NOR_pca_arima_female$err)
rownames(NOR_female_err) = c("DPCA", "PCA")

# fh = 5

NOR_dpca_arima_female_fh_5 = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

NOR_pca_arima_female_fh_5 = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

NOR_female_err_fh_5 = rbind(NOR_dpca_arima_female_fh_5$err, NOR_pca_arima_female_fh_5$err)
rownames(NOR_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_female_fh_10 = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

NOR_pca_arima_female_fh_10 = dpca_res(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

NOR_female_err_fh_10 = rbind(NOR_dpca_arima_female_fh_10$err, NOR_pca_arima_female_fh_10$err)
rownames(NOR_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

NOR_dpca_arima_male = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

NOR_pca_arima_male = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

NOR_male_err = rbind(NOR_dpca_arima_male$err, NOR_pca_arima_male$err)
rownames(NOR_male_err) = c("DPCA", "PCA")

# fh = 5

NOR_dpca_arima_male_fh_5 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

NOR_pca_arima_male_fh_5 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

NOR_male_err_fh_5 = rbind(NOR_dpca_arima_male_fh_5$err, NOR_pca_arima_male_fh_5$err)
rownames(NOR_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_male_fh_10 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

NOR_pca_arima_male_fh_10 = dpca_res(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

NOR_male_err_fh_10 = rbind(NOR_dpca_arima_male_fh_10$err, NOR_pca_arima_male_fh_10$err)
rownames(NOR_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

NOR_dpca_arima_total = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

NOR_pca_arima_total = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

NOR_total_err = rbind(NOR_dpca_arima_total$err, NOR_pca_arima_total$err)
rownames(NOR_total_err) = c("DPCA", "PCA")

# fh = 5

NOR_dpca_arima_total_fh_5 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

NOR_pca_arima_total_fh_5 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

NOR_total_err_fh_5 = rbind(NOR_dpca_arima_total_fh_5$err, NOR_pca_arima_total_fh_5$err)
rownames(NOR_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_total_fh_10 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

NOR_pca_arima_total_fh_10 = dpca_res(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

NOR_total_err_fh_10 = rbind(NOR_dpca_arima_total_fh_10$err, NOR_pca_arima_total_fh_10$err)
rownames(NOR_total_err_fh_10) = c("DPCA", "PCA")

