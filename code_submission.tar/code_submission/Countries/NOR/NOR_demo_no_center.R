source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

NOR_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year],
                                                            jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_female_no_center = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_female_err_no_center = rbind(NOR_smooth_dpca_arima_female_no_center$err, NOR_smooth_pca_arima_female_no_center$err)
rownames(NOR_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_female_err_no_center_fh_5 = rbind(NOR_smooth_dpca_arima_female_no_center_fh_5$err, NOR_smooth_pca_arima_female_no_center_fh_5$err)
rownames(NOR_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                                  jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                  method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NOR_female_smooth_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_female_no_center_err_fh_10 = rbind(NOR_smooth_dpca_arima_female_no_center_fh_10$err, NOR_smooth_pca_arima_female_no_center_fh_10$err)
rownames(NOR_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

NOR_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                          jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_male_no_center = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_male_err_no_center = rbind(NOR_smooth_dpca_arima_male_no_center$err, NOR_smooth_pca_arima_male_no_center$err)
rownames(NOR_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_male_no_center_err_fh_5 = rbind(NOR_smooth_dpca_arima_male_no_center_fh_5$err, NOR_smooth_pca_arima_male_no_center_fh_5$err)
rownames(NOR_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NOR_male_smooth_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                                jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_male_no_center_err_fh_10 = rbind(NOR_smooth_dpca_arima_male_no_center_fh_10$err, NOR_smooth_pca_arima_male_no_center_fh_10$err)
rownames(NOR_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

NOR_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                           jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_pca_arima_total_no_center = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

NOR_smooth_total_err_no_center = rbind(NOR_smooth_dpca_arima_total_no_center$err, NOR_smooth_pca_arima_total_no_center$err)
rownames(NOR_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

NOR_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

NOR_smooth_total_no_center_err_fh_5 = rbind(NOR_smooth_dpca_arima_total_no_center_fh_5$err, NOR_smooth_pca_arima_total_no_center_fh_5$err)
rownames(NOR_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NOR_total_smooth_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                                 jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

NOR_smooth_total_no_center_err_fh_10 = rbind(NOR_smooth_dpca_arima_total_no_center_fh_10$err, NOR_smooth_pca_arima_total_no_center_fh_10$err)
rownames(NOR_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

NOR_dpca_arima_female_no_center = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                     jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                     forecasting_method = "arima", fh = 1)

NOR_pca_arima_female_no_center = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                    forecasting_method = "arima", fh = 1)

NOR_female_err_no_center = rbind(NOR_dpca_arima_female_no_center$err, NOR_pca_arima_female_no_center$err)
rownames(NOR_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

NOR_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 5)

NOR_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 5)

NOR_female_err_no_center_fh_5 = rbind(NOR_dpca_arima_female_no_center_fh_5$err, NOR_pca_arima_female_no_center_fh_5$err)
rownames(NOR_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                           jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           forecasting_method = "arima", fh = 10)

NOR_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = NOR_female_ratio, test_data = NOR_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = NOR_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          forecasting_method = "arima", fh = 10)

NOR_female_err_no_center_fh_10 = rbind(NOR_dpca_arima_female_no_center_fh_10$err, NOR_pca_arima_female_no_center_fh_10$err)
rownames(NOR_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

NOR_dpca_arima_male_no_center = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                   jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

NOR_pca_arima_male_no_center = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

NOR_male_err_no_center = rbind(NOR_dpca_arima_male_no_center$err, NOR_pca_arima_male_no_center$err)
rownames(NOR_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

NOR_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

NOR_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

NOR_male_err_no_center_fh_5 = rbind(NOR_dpca_arima_male_no_center_fh_5$err, NOR_pca_arima_male_no_center_fh_5$err)
rownames(NOR_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

NOR_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = NOR_male_ratio, test_data = NOR_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = NOR_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

NOR_male_err_no_center_fh_10 = rbind(NOR_dpca_arima_male_no_center_fh_10$err, NOR_pca_arima_male_no_center_fh_10$err)
rownames(NOR_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

NOR_dpca_arima_total_no_center = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                    jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

NOR_pca_arima_total_no_center = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

NOR_total_err_no_center = rbind(NOR_dpca_arima_total_no_center$err, NOR_pca_arima_total_no_center$err)
rownames(NOR_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

NOR_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

NOR_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

NOR_total_err_no_center_fh_5 = rbind(NOR_dpca_arima_total_no_center_fh_5$err, NOR_pca_arima_total_no_center_fh_5$err)
rownames(NOR_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

NOR_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

NOR_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = NOR_total_ratio, test_data = NOR_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = NOR_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

NOR_total_err_no_center_fh_10 = rbind(NOR_dpca_arima_total_no_center_fh_10$err, NOR_pca_arima_total_no_center_fh_10$err)
rownames(NOR_total_err_no_center_fh_10) = c("DPCA", "PCA")

