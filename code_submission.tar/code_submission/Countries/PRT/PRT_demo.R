rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

PRT_dummy = extract.ages(hmd.mx(country = "PRT", username = "shl8858@telstra.com", password = "hshang85", label = "PRT"), 0:100)
PRT_demo = extract.years(PRT_dummy, 1950:max(PRT_dummy$year))
PRT_smooth = smooth.demogdata(PRT_demo)
n_year = length(PRT_demo$year)

# convert non-stationary series to stationary series

PRT_female_dummy_ratio = PRT_male_ratio = PRT_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    PRT_female_dummy_ratio[,ik-1] = 2 * (1 - PRT_demo$rate$female[,ik]/PRT_demo$rate$female[,ik-1])/(1 + PRT_demo$rate$female[,ik]/PRT_demo$rate$female[,ik-1])
    PRT_male_ratio[,ik-1]   = 2 * (1 - PRT_demo$rate$male[,ik]/PRT_demo$rate$male[,ik-1])/(1 + PRT_demo$rate$male[,ik]/PRT_demo$rate$male[,ik-1])
    PRT_total_ratio[,ik-1]  = 2 * (1 - PRT_demo$rate$total[,ik]/PRT_demo$rate$total[,ik-1])/(1 + PRT_demo$rate$total[,ik]/PRT_demo$rate$total[,ik-1])
}  

which(!is.finite(PRT_female_dummy_ratio))
PRT_female_ratio = na.locf(PRT_female_dummy_ratio)


PRT_female_smooth_ratio = PRT_male_smooth_ratio = PRT_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    PRT_female_smooth_ratio[,ik-1] = 2 * (1 - PRT_smooth$rate$female[,ik]/PRT_smooth$rate$female[,ik-1])/(1 + PRT_smooth$rate$female[,ik]/PRT_smooth$rate$female[,ik-1])
    PRT_male_smooth_ratio[,ik-1]   = 2 * (1 - PRT_smooth$rate$male[,ik]/PRT_smooth$rate$male[,ik-1])/(1 + PRT_smooth$rate$male[,ik]/PRT_smooth$rate$male[,ik-1])
    PRT_total_smooth_ratio[,ik-1]  = 2 * (1 - PRT_smooth$rate$total[,ik]/PRT_smooth$rate$total[,ik-1])/(1 + PRT_smooth$rate$total[,ik]/PRT_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(PRT_female_ratio); T_stationary(PRT_male_ratio); T_stationary(PRT_total_ratio)  # 0.07 0.157 0.247
T_stationary(PRT_female_smooth_ratio); T_stationary(PRT_male_smooth_ratio); T_stationary(PRT_total_smooth_ratio)    # 0.227 0.278 0.308

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

PRT_smooth_dpca_arima_female = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_female = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_female_err = rbind(PRT_smooth_dpca_arima_female$err, PRT_smooth_pca_arima_female$err)
rownames(PRT_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_female_fh_5 = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_female_fh_5 = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_female_err_fh_5 = rbind(PRT_smooth_dpca_arima_female_fh_5$err, PRT_smooth_pca_arima_female_fh_5$err)
rownames(PRT_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_female_fh_10 = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_female_fh_10 = dpca_res(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_female_err_fh_10 = rbind(PRT_smooth_dpca_arima_female_fh_10$err, PRT_smooth_pca_arima_female_fh_10$err)
rownames(PRT_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

PRT_smooth_dpca_arima_male = dpca_res(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_male = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_male_err = rbind(PRT_smooth_dpca_arima_male$err, PRT_smooth_pca_arima_male$err)
rownames(PRT_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_male_fh_5 = dpca_res(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_male_fh_5 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_male_err_fh_5 = rbind(PRT_smooth_dpca_arima_male_fh_5$err, PRT_smooth_pca_arima_male_fh_5$err)
rownames(PRT_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_male_fh_10 = dpca_res(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_male_fh_10 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_male_err_fh_10 = rbind(PRT_smooth_dpca_arima_male_fh_10$err, PRT_smooth_pca_arima_male_fh_10$err)
rownames(PRT_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

PRT_smooth_dpca_arima_total = dpca_res(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_total = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_total_err = rbind(PRT_smooth_dpca_arima_total$err, PRT_smooth_pca_arima_total$err)
rownames(PRT_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_total_fh_5 = dpca_res(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_total_fh_5 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_total_err_fh_5 = rbind(PRT_smooth_dpca_arima_total_fh_5$err, PRT_smooth_pca_arima_total_fh_5$err)
rownames(PRT_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_total_fh_10 = dpca_res(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_total_fh_10 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_total_err_fh_10 = rbind(PRT_smooth_dpca_arima_total_fh_10$err, PRT_smooth_pca_arima_total_fh_10$err)
rownames(PRT_smooth_total_err_fh_10) = c("DPCA", "PCA")

########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

PRT_dpca_arima_female = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

PRT_pca_arima_female = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

PRT_female_err = rbind(PRT_dpca_arima_female$err, PRT_pca_arima_female$err)
rownames(PRT_female_err) = c("DPCA", "PCA")

# fh = 5

PRT_dpca_arima_female_fh_5 = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

PRT_pca_arima_female_fh_5 = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

PRT_female_err_fh_5 = rbind(PRT_dpca_arima_female_fh_5$err, PRT_pca_arima_female_fh_5$err)
rownames(PRT_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_female_fh_10 = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

PRT_pca_arima_female_fh_10 = dpca_res(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

PRT_female_err_fh_10 = rbind(PRT_dpca_arima_female_fh_10$err, PRT_pca_arima_female_fh_10$err)
rownames(PRT_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

PRT_dpca_arima_male = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

PRT_pca_arima_male = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

PRT_male_err = rbind(PRT_dpca_arima_male$err, PRT_pca_arima_male$err)
rownames(PRT_male_err) = c("DPCA", "PCA")

# fh = 5

PRT_dpca_arima_male_fh_5 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

PRT_pca_arima_male_fh_5 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

PRT_male_err_fh_5 = rbind(PRT_dpca_arima_male_fh_5$err, PRT_pca_arima_male_fh_5$err)
rownames(PRT_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_male_fh_10 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

PRT_pca_arima_male_fh_10 = dpca_res(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

PRT_male_err_fh_10 = rbind(PRT_dpca_arima_male_fh_10$err, PRT_pca_arima_male_fh_10$err)
rownames(PRT_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

PRT_dpca_arima_total = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

PRT_pca_arima_total = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

PRT_total_err = rbind(PRT_dpca_arima_total$err, PRT_pca_arima_total$err)
rownames(PRT_total_err) = c("DPCA", "PCA")

# fh = 5

PRT_dpca_arima_total_fh_5 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

PRT_pca_arima_total_fh_5 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

PRT_total_err_fh_5 = rbind(PRT_dpca_arima_total_fh_5$err, PRT_pca_arima_total_fh_5$err)
rownames(PRT_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_total_fh_10 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

PRT_pca_arima_total_fh_10 = dpca_res(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

PRT_total_err_fh_10 = rbind(PRT_dpca_arima_total_fh_10$err, PRT_pca_arima_total_fh_10$err)
rownames(PRT_total_err_fh_10) = c("DPCA", "PCA")

