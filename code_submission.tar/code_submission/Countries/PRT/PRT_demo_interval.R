# load a file

source("DFPCA.R")
source("Long_run_covariance.R")
source("DFPCA_interval.R")

#################################
# method = "FDM" (female series)
#################################

# fh = 1

PRT_smooth_dpca_arima_female_boot = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                             jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")


PRT_smooth_pca_arima_female_boot = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                            jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_smooth_dpca_arima_female_boot_fh_5 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                  jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                  method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_smooth_pca_arima_female_boot_fh_5 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                 jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                 method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_smooth_dpca_arima_female_boot_fh_10 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                   jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_smooth_pca_arima_female_boot_fh_10 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                  jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

################################
# method = "LC" (female series)
################################

# fh = 1

PRT_dpca_arima_female_boot = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

PRT_pca_arima_female_boot = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_dpca_arima_female_boot_fh_5 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_pca_arima_female_boot_fh_5 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                          jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_dpca_arima_female_boot_fh_10 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_pca_arima_female_boot_fh_10 = dpca_int(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")


########################################################
# interval score & coverage probability (female series)
########################################################

# fh = 1

PRT_smooth_dpca_arima_female_score = interval_score(holdout = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                    lb = PRT_smooth_dpca_arima_female_boot$curve_forecast_lb[,1,],
                                                    ub = PRT_smooth_dpca_arima_female_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_smooth_pca_arima_female_score = interval_score(holdout = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                   lb = PRT_smooth_pca_arima_female_boot$curve_forecast_lb[,1,],
                                                   ub = PRT_smooth_pca_arima_female_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_dpca_arima_female_score = interval_score(holdout = PRT_demo$rate$female[,(n_year-29):n_year], 
                                             lb = PRT_dpca_arima_female_boot$curve_forecast_lb[,1,],
                                             ub = PRT_dpca_arima_female_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_pca_arima_female_score = interval_score(holdout = PRT_demo$rate$female[,(n_year-29):n_year], 
                                            lb = PRT_pca_arima_female_boot$curve_forecast_lb[,1,],
                                            ub = PRT_pca_arima_female_boot$curve_forecast_ub[,1,], alpha = 0.2)

# fh = 5

PRT_smooth_dpca_arima_female_score_fh_5 = PRT_smooth_pca_arima_female_score_fh_5 = 
PRT_dpca_arima_female_score_fh_5 = PRT_pca_arima_female_score_fh_5 = matrix(NA, 5, 2)
for(ik in 1:5)  
{
    PRT_smooth_dpca_arima_female_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,5:30], 
                                                                             lb = PRT_smooth_dpca_arima_female_boot_fh_5$curve_forecast_lb[,ik,],
                                                                             ub = PRT_smooth_dpca_arima_female_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_female_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,5:30], 
                                                                            lb = PRT_smooth_pca_arima_female_boot_fh_5$curve_forecast_lb[,ik,],
                                                                            ub = PRT_smooth_pca_arima_female_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_female_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,5:30], 
                                                                      lb = PRT_dpca_arima_female_boot_fh_5$curve_forecast_lb[,ik,],
                                                                      ub = PRT_dpca_arima_female_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_female_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,5:30], 
                                                                     lb = PRT_pca_arima_female_boot_fh_5$curve_forecast_lb[,ik,],
                                                                     ub = PRT_pca_arima_female_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
}

# fh = 10

PRT_smooth_dpca_arima_female_score_fh_10 = PRT_smooth_pca_arima_female_score_fh_10 = 
PRT_dpca_arima_female_score_fh_10 = PRT_pca_arima_female_score_fh_10 = matrix(NA, 10, 2)
for(ik in 1:10)  
{
    PRT_smooth_dpca_arima_female_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,10:30], 
                                                                              lb = PRT_smooth_dpca_arima_female_boot_fh_10$curve_forecast_lb[,ik,],
                                                                              ub = PRT_smooth_dpca_arima_female_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_female_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,10:30], 
                                                                             lb = PRT_smooth_pca_arima_female_boot_fh_10$curve_forecast_lb[,ik,],
                                                                             ub = PRT_smooth_pca_arima_female_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_female_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,10:30], 
                                                                       lb = PRT_dpca_arima_female_boot_fh_10$curve_forecast_lb[,ik,],
                                                                       ub = PRT_dpca_arima_female_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_female_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$female[,(n_year-29):n_year])[,10:30], 
                                                                      lb = PRT_pca_arima_female_boot_fh_10$curve_forecast_lb[,ik,],
                                                                      ub = PRT_pca_arima_female_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
}

#################################
# method = "FDM" (male series)
#################################

# fh = 1

PRT_smooth_dpca_arima_male_boot = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                           jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")


PRT_smooth_pca_arima_male_boot = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                          jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_smooth_dpca_arima_male_boot_fh_5 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                                jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_smooth_pca_arima_male_boot_fh_5 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                               jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                               method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_smooth_dpca_arima_male_boot_fh_10 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                                 jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                 method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_smooth_pca_arima_male_boot_fh_10 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year],
                                                jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

################################
# method = "LC" (male series)
################################

# fh = 1

PRT_dpca_arima_male_boot = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

PRT_pca_arima_male_boot = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_dpca_arima_male_boot_fh_5 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                         jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                         method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_pca_arima_male_boot_fh_5 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                        jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                        method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_dpca_arima_male_boot_fh_10 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                          method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_pca_arima_male_boot_fh_10 = dpca_int(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                         jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                         method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")


########################################################
# interval score & coverage probability (male series)
########################################################

# fh = 1

PRT_smooth_dpca_arima_male_score = interval_score(holdout = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                  lb = PRT_smooth_dpca_arima_male_boot$curve_forecast_lb[,1,],
                                                  ub = PRT_smooth_dpca_arima_male_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_smooth_pca_arima_male_score = interval_score(holdout = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                 lb = PRT_smooth_pca_arima_male_boot$curve_forecast_lb[,1,],
                                                 ub = PRT_smooth_pca_arima_male_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_dpca_arima_male_score = interval_score(holdout = PRT_demo$rate$male[,(n_year-29):n_year], 
                                           lb = PRT_dpca_arima_male_boot$curve_forecast_lb[,1,],
                                           ub = PRT_dpca_arima_male_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_pca_arima_male_score = interval_score(holdout = PRT_demo$rate$male[,(n_year-29):n_year], 
                                          lb = PRT_pca_arima_male_boot$curve_forecast_lb[,1,],
                                          ub = PRT_pca_arima_male_boot$curve_forecast_ub[,1,], alpha = 0.2)

# fh = 5

PRT_smooth_dpca_arima_male_score_fh_5 = PRT_smooth_pca_arima_male_score_fh_5 = 
PRT_dpca_arima_male_score_fh_5 = PRT_pca_arima_male_score_fh_5 = matrix(NA, 5, 2)
for(ik in 1:5)  
{
    PRT_smooth_dpca_arima_male_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,5:30], 
                                                                           lb = PRT_smooth_dpca_arima_male_boot_fh_5$curve_forecast_lb[,ik,],
                                                                           ub = PRT_smooth_dpca_arima_male_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_male_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,5:30], 
                                                                          lb = PRT_smooth_pca_arima_male_boot_fh_5$curve_forecast_lb[,ik,],
                                                                          ub = PRT_smooth_pca_arima_male_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_male_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,5:30], 
                                                                    lb = PRT_dpca_arima_male_boot_fh_5$curve_forecast_lb[,ik,],
                                                                    ub = PRT_dpca_arima_male_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_male_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,5:30], 
                                                                   lb = PRT_pca_arima_male_boot_fh_5$curve_forecast_lb[,ik,],
                                                                   ub = PRT_pca_arima_male_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
}

# fh = 10

PRT_smooth_dpca_arima_male_score_fh_10 = PRT_smooth_pca_arima_male_score_fh_10 = 
PRT_dpca_arima_male_score_fh_10 = PRT_pca_arima_male_score_fh_10 = matrix(NA, 10, 2)
for(ik in 1:10)  
{
    PRT_smooth_dpca_arima_male_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,10:30], 
                                                                            lb = PRT_smooth_dpca_arima_male_boot_fh_10$curve_forecast_lb[,ik,],
                                                                            ub = PRT_smooth_dpca_arima_male_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_male_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,10:30], 
                                                                           lb = PRT_smooth_pca_arima_male_boot_fh_10$curve_forecast_lb[,ik,],
                                                                           ub = PRT_smooth_pca_arima_male_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_male_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,10:30], 
                                                                     lb = PRT_dpca_arima_male_boot_fh_10$curve_forecast_lb[,ik,],
                                                                     ub = PRT_dpca_arima_male_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_male_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$male[,(n_year-29):n_year])[,10:30], 
                                                                    lb = PRT_pca_arima_male_boot_fh_10$curve_forecast_lb[,ik,],
                                                                    ub = PRT_pca_arima_male_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
}

#################################
# method = "FDM" (total series)
#################################

# fh = 1

PRT_smooth_dpca_arima_total_boot = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                            jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")


PRT_smooth_pca_arima_total_boot = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                           jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_smooth_dpca_arima_total_boot_fh_5 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                                 jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                 method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_smooth_pca_arima_total_boot_fh_5 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                                jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_smooth_dpca_arima_total_boot_fh_10 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                                  jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                  method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_smooth_pca_arima_total_boot_fh_10 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year],
                                                 jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                 method = "FDM", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

################################
# method = "LC" (total series)
################################

# fh = 1

PRT_dpca_arima_total_boot = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

PRT_pca_arima_total_boot = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 1, output = "interval")

# fh = 5

PRT_dpca_arima_total_boot_fh_5 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                          jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                          method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

PRT_pca_arima_total_boot_fh_5 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                         jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                         method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 5, output = "interval")

# fh = 10

PRT_dpca_arima_total_boot_fh_10 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")

PRT_pca_arima_total_boot_fh_10 = dpca_int(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                          jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "LC", forecasting_method = "arima", threshold = 0.8, fh = 10, output = "interval")


########################################################
# interval score & coverage probability (total series)
########################################################

# fh = 1

PRT_smooth_dpca_arima_total_score = interval_score(holdout = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                   lb = PRT_smooth_dpca_arima_total_boot$curve_forecast_lb[,1,],
                                                   ub = PRT_smooth_dpca_arima_total_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_smooth_pca_arima_total_score = interval_score(holdout = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                  lb = PRT_smooth_pca_arima_total_boot$curve_forecast_lb[,1,],
                                                  ub = PRT_smooth_pca_arima_total_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_dpca_arima_total_score = interval_score(holdout = PRT_demo$rate$total[,(n_year-29):n_year], 
                                            lb = PRT_dpca_arima_total_boot$curve_forecast_lb[,1,],
                                            ub = PRT_dpca_arima_total_boot$curve_forecast_ub[,1,], alpha = 0.2)

PRT_pca_arima_total_score = interval_score(holdout = PRT_demo$rate$total[,(n_year-29):n_year], 
                                           lb = PRT_pca_arima_total_boot$curve_forecast_lb[,1,],
                                           ub = PRT_pca_arima_total_boot$curve_forecast_ub[,1,], alpha = 0.2)

# fh = 5

PRT_smooth_dpca_arima_total_score_fh_5 = PRT_smooth_pca_arima_total_score_fh_5 = 
PRT_dpca_arima_total_score_fh_5 = PRT_pca_arima_total_score_fh_5 = matrix(NA, 5, 2)
for(ik in 1:5)  
{
    PRT_smooth_dpca_arima_total_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,5:30], 
                                                                            lb = PRT_smooth_dpca_arima_total_boot_fh_5$curve_forecast_lb[,ik,],
                                                                            ub = PRT_smooth_dpca_arima_total_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_total_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,5:30], 
                                                                           lb = PRT_smooth_pca_arima_total_boot_fh_5$curve_forecast_lb[,ik,],
                                                                           ub = PRT_smooth_pca_arima_total_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_total_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,5:30], 
                                                                     lb = PRT_dpca_arima_total_boot_fh_5$curve_forecast_lb[,ik,],
                                                                     ub = PRT_dpca_arima_total_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_total_score_fh_5[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,5:30], 
                                                                    lb = PRT_pca_arima_total_boot_fh_5$curve_forecast_lb[,ik,],
                                                                    ub = PRT_pca_arima_total_boot_fh_5$curve_forecast_ub[,ik,], alpha = 0.2))
}

# fh = 10

PRT_smooth_dpca_arima_total_score_fh_10 = PRT_smooth_pca_arima_total_score_fh_10 = 
PRT_dpca_arima_total_score_fh_10 = PRT_pca_arima_total_score_fh_10 = matrix(NA, 10, 2)
for(ik in 1:10)  
{
    PRT_smooth_dpca_arima_total_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,10:30], 
                                                                             lb = PRT_smooth_dpca_arima_total_boot_fh_10$curve_forecast_lb[,ik,],
                                                                             ub = PRT_smooth_dpca_arima_total_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_smooth_pca_arima_total_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,10:30], 
                                                                            lb = PRT_smooth_pca_arima_total_boot_fh_10$curve_forecast_lb[,ik,],
                                                                            ub = PRT_smooth_pca_arima_total_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_dpca_arima_total_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,10:30], 
                                                                      lb = PRT_dpca_arima_total_boot_fh_10$curve_forecast_lb[,ik,],
                                                                      ub = PRT_dpca_arima_total_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
    
    PRT_pca_arima_total_score_fh_10[ik,] = as.numeric(interval_score(holdout = (PRT_demo$rate$total[,(n_year-29):n_year])[,10:30], 
                                                                     lb = PRT_pca_arima_total_boot_fh_10$curve_forecast_lb[,ik,],
                                                                     ub = PRT_pca_arima_total_boot_fh_10$curve_forecast_ub[,ik,], alpha = 0.2))
}



PRT_female_score_cover = cbind(rbind(as.numeric(PRT_smooth_dpca_arima_female_score),
                                     as.numeric(PRT_smooth_pca_arima_female_score),
                                     as.numeric(PRT_dpca_arima_female_score),
                                     as.numeric(PRT_pca_arima_female_score)),
                               
                               rbind(colMeans(PRT_smooth_dpca_arima_female_score_fh_5),
                                     colMeans(PRT_smooth_pca_arima_female_score_fh_5),
                                     colMeans(PRT_dpca_arima_female_score_fh_5),
                                     colMeans(PRT_pca_arima_female_score_fh_5)),
                               
                               rbind(colMeans(PRT_smooth_dpca_arima_female_score_fh_10),
                                     colMeans(PRT_smooth_pca_arima_female_score_fh_10),
                                     colMeans(PRT_dpca_arima_female_score_fh_10),
                                     colMeans(PRT_pca_arima_female_score_fh_10)))


PRT_male_score_cover = cbind(rbind(as.numeric(PRT_smooth_dpca_arima_male_score),
                                   as.numeric(PRT_smooth_pca_arima_male_score),
                                   as.numeric(PRT_dpca_arima_male_score),
                                   as.numeric(PRT_pca_arima_male_score)),
                             
                             rbind(colMeans(PRT_smooth_dpca_arima_male_score_fh_5),
                                   colMeans(PRT_smooth_pca_arima_male_score_fh_5),
                                   colMeans(PRT_dpca_arima_male_score_fh_5),
                                   colMeans(PRT_pca_arima_male_score_fh_5)),
                             
                             rbind(colMeans(PRT_smooth_dpca_arima_male_score_fh_10),
                                   colMeans(PRT_smooth_pca_arima_male_score_fh_10),
                                   colMeans(PRT_dpca_arima_male_score_fh_10),
                                   colMeans(PRT_pca_arima_male_score_fh_10)))

PRT_total_score_cover = cbind(rbind(as.numeric(PRT_smooth_dpca_arima_total_score),
                                    as.numeric(PRT_smooth_pca_arima_total_score),
                                    as.numeric(PRT_dpca_arima_total_score),
                                    as.numeric(PRT_pca_arima_total_score)),
                              
                              rbind(colMeans(PRT_smooth_dpca_arima_total_score_fh_5),
                                    colMeans(PRT_smooth_pca_arima_total_score_fh_5),
                                    colMeans(PRT_dpca_arima_total_score_fh_5),
                                    colMeans(PRT_pca_arima_total_score_fh_5)),
                              
                              rbind(colMeans(PRT_smooth_dpca_arima_total_score_fh_10),
                                    colMeans(PRT_smooth_pca_arima_total_score_fh_10),
                                    colMeans(PRT_dpca_arima_total_score_fh_10),
                                    colMeans(PRT_pca_arima_total_score_fh_10)))

rownames(PRT_female_score_cover) = rownames(PRT_male_score_cover) = rownames(PRT_total_score_cover) = c("DPCA_fun", "PCA_fun", "DPCA_LC", "PCA_LC")
colnames(PRT_female_score_cover) = colnames(PRT_male_score_cover) = colnames(PRT_total_score_cover) = c("score (h=1)", "cover (h=1)", "score (h=5)", "cover (h=5)", "score (h=10)", "cover (h=10)")

