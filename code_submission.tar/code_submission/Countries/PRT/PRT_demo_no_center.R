source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

PRT_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_female_no_center = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year],
                                                          jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_female_err_no_center = rbind(PRT_smooth_dpca_arima_female_no_center$err, PRT_smooth_pca_arima_female_no_center$err)
rownames(PRT_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                               jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_female_err_no_center_fh_5 = rbind(PRT_smooth_dpca_arima_female_no_center_fh_5$err, PRT_smooth_pca_arima_female_no_center_fh_5$err)
rownames(PRT_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = PRT_female_smooth_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_female_no_center_err_fh_10 = rbind(PRT_smooth_dpca_arima_female_no_center_fh_10$err, PRT_smooth_pca_arima_female_no_center_fh_10$err)
rownames(PRT_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

PRT_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_male_no_center = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_male_err_no_center = rbind(PRT_smooth_dpca_arima_male_no_center$err, PRT_smooth_pca_arima_male_no_center$err)
rownames(PRT_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                             jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_male_no_center_err_fh_5 = rbind(PRT_smooth_dpca_arima_male_no_center_fh_5$err, PRT_smooth_pca_arima_male_no_center_fh_5$err)
rownames(PRT_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = PRT_male_smooth_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_male_no_center_err_fh_10 = rbind(PRT_smooth_dpca_arima_male_no_center_fh_10$err, PRT_smooth_pca_arima_male_no_center_fh_10$err)
rownames(PRT_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

PRT_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_pca_arima_total_no_center = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

PRT_smooth_total_err_no_center = rbind(PRT_smooth_dpca_arima_total_no_center$err, PRT_smooth_pca_arima_total_no_center$err)
rownames(PRT_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

PRT_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                              jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

PRT_smooth_total_no_center_err_fh_5 = rbind(PRT_smooth_dpca_arima_total_no_center_fh_5$err, PRT_smooth_pca_arima_total_no_center_fh_5$err)
rownames(PRT_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = PRT_total_smooth_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

PRT_smooth_total_no_center_err_fh_10 = rbind(PRT_smooth_dpca_arima_total_no_center_fh_10$err, PRT_smooth_pca_arima_total_no_center_fh_10$err)
rownames(PRT_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

PRT_dpca_arima_female_no_center = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

PRT_pca_arima_female_no_center = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                   jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

PRT_female_err_no_center = rbind(PRT_dpca_arima_female_no_center$err, PRT_pca_arima_female_no_center$err)
rownames(PRT_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

PRT_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

PRT_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                        jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

PRT_female_err_no_center_fh_5 = rbind(PRT_dpca_arima_female_no_center_fh_5$err, PRT_pca_arima_female_no_center_fh_5$err)
rownames(PRT_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

PRT_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = PRT_female_ratio, test_data = PRT_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = PRT_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

PRT_female_err_no_center_fh_10 = rbind(PRT_dpca_arima_female_no_center_fh_10$err, PRT_pca_arima_female_no_center_fh_10$err)
rownames(PRT_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

PRT_dpca_arima_male_no_center = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                  forecasting_method = "arima", fh = 1)

PRT_pca_arima_male_no_center = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                 jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                 forecasting_method = "arima", fh = 1)

PRT_male_err_no_center = rbind(PRT_dpca_arima_male_no_center$err, PRT_pca_arima_male_no_center$err)
rownames(PRT_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

PRT_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                       forecasting_method = "arima", fh = 5)

PRT_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                      jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                      forecasting_method = "arima", fh = 5)

PRT_male_err_no_center_fh_5 = rbind(PRT_dpca_arima_male_no_center_fh_5$err, PRT_pca_arima_male_no_center_fh_5$err)
rownames(PRT_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 10)

PRT_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = PRT_male_ratio, test_data = PRT_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = PRT_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 10)

PRT_male_err_no_center_fh_10 = rbind(PRT_dpca_arima_male_no_center_fh_10$err, PRT_pca_arima_male_no_center_fh_10$err)
rownames(PRT_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

PRT_dpca_arima_total_no_center = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

PRT_pca_arima_total_no_center = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                  jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

PRT_total_err_no_center = rbind(PRT_dpca_arima_total_no_center$err, PRT_pca_arima_total_no_center$err)
rownames(PRT_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

PRT_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

PRT_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                       jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

PRT_total_err_no_center_fh_5 = rbind(PRT_dpca_arima_total_no_center_fh_5$err, PRT_pca_arima_total_no_center_fh_5$err)
rownames(PRT_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

PRT_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

PRT_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = PRT_total_ratio, test_data = PRT_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = PRT_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

PRT_total_err_no_center_fh_10 = rbind(PRT_dpca_arima_total_no_center_fh_10$err, PRT_pca_arima_total_no_center_fh_10$err)
rownames(PRT_total_err_no_center_fh_10) = c("DPCA", "PCA")

