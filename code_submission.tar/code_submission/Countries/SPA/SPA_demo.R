rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

SPA_dummy = extract.ages(hmd.mx(country = "ESP", username = "shl8858@telstra.com", password = "hshang85", label = "SPA"), 0:100)
SPA_demo = extract.years(SPA_dummy, 1950:max(SPA_dummy$year))
SPA_smooth = smooth.demogdata(SPA_demo)
n_year = length(SPA_demo$year)

# convert non-stationary series to stationary series

SPA_female_ratio = SPA_male_ratio = SPA_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    SPA_female_ratio[,ik-1] = 2 * (1 - SPA_demo$rate$female[,ik]/SPA_demo$rate$female[,ik-1])/(1 + SPA_demo$rate$female[,ik]/SPA_demo$rate$female[,ik-1])
    SPA_male_ratio[,ik-1]   = 2 * (1 - SPA_demo$rate$male[,ik]/SPA_demo$rate$male[,ik-1])/(1 + SPA_demo$rate$male[,ik]/SPA_demo$rate$male[,ik-1])
    SPA_total_ratio[,ik-1]  = 2 * (1 - SPA_demo$rate$total[,ik]/SPA_demo$rate$total[,ik-1])/(1 + SPA_demo$rate$total[,ik]/SPA_demo$rate$total[,ik-1])
}  

SPA_female_smooth_ratio = SPA_male_smooth_ratio = SPA_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    SPA_female_smooth_ratio[,ik-1] = 2 * (1 - SPA_smooth$rate$female[,ik]/SPA_smooth$rate$female[,ik-1])/(1 + SPA_smooth$rate$female[,ik]/SPA_smooth$rate$female[,ik-1])
    SPA_male_smooth_ratio[,ik-1]   = 2 * (1 - SPA_smooth$rate$male[,ik]/SPA_smooth$rate$male[,ik-1])/(1 + SPA_smooth$rate$male[,ik]/SPA_smooth$rate$male[,ik-1])
    SPA_total_smooth_ratio[,ik-1]  = 2 * (1 - SPA_smooth$rate$total[,ik]/SPA_smooth$rate$total[,ik-1])/(1 + SPA_smooth$rate$total[,ik]/SPA_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(SPA_female_ratio); T_stationary(SPA_male_ratio); T_stationary(SPA_total_ratio)  # 0.093 0.327 0.282
T_stationary(SPA_female_smooth_ratio); T_stationary(SPA_male_smooth_ratio); T_stationary(SPA_total_smooth_ratio) # 0.128 0.356 0.304

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

SPA_smooth_dpca_arima_female = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_pca_arima_female = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_female_err = rbind(SPA_smooth_dpca_arima_female$err, SPA_smooth_pca_arima_female$err)
rownames(SPA_smooth_female_err) = c("DPCA", "PCA")

# fh = 5 

SPA_smooth_dpca_arima_female_fh_5 = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_pca_arima_female_fh_5 = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_female_err_fh_5 = rbind(SPA_smooth_dpca_arima_female_fh_5$err, SPA_smooth_pca_arima_female_fh_5$err)
rownames(SPA_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_smooth_dpca_arima_female_fh_10 = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_pca_arima_female_fh_10 = dpca_res(data = SPA_female_smooth_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_female_err_fh_10 = rbind(SPA_smooth_dpca_arima_female_fh_10$err, SPA_smooth_pca_arima_female_fh_10$err)
rownames(SPA_smooth_female_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

SPA_smooth_dpca_arima_male = dpca_res(data = SPA_male_smooth_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_pca_arima_male = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_male_err = rbind(SPA_smooth_dpca_arima_male$err, SPA_smooth_pca_arima_male$err)
rownames(SPA_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

SPA_smooth_dpca_arima_male_fh_5 = dpca_res(data = SPA_male_smooth_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_pca_arima_male_fh_5 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_male_err_fh_5 = rbind(SPA_smooth_dpca_arima_male_fh_5$err, SPA_smooth_pca_arima_male_fh_5$err)
rownames(SPA_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_smooth_dpca_arima_male_fh_10 = dpca_res(data = SPA_male_smooth_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_pca_arima_male_fh_10 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_male_err_fh_10 = rbind(SPA_smooth_dpca_arima_male_fh_10$err, SPA_smooth_pca_arima_male_fh_10$err)
rownames(SPA_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

SPA_smooth_dpca_arima_total = dpca_res(data = SPA_total_smooth_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_pca_arima_total = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SPA_smooth_total_err = rbind(SPA_smooth_dpca_arima_total$err, SPA_smooth_pca_arima_total$err)
rownames(SPA_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

SPA_smooth_dpca_arima_total_fh_5 = dpca_res(data = SPA_total_smooth_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_pca_arima_total_fh_5 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SPA_smooth_total_err_fh_5 = rbind(SPA_smooth_dpca_arima_total_fh_5$err, SPA_smooth_pca_arima_total_fh_5$err)
rownames(SPA_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_smooth_dpca_arima_total_fh_10 = dpca_res(data = SPA_total_smooth_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_pca_arima_total_fh_10 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SPA_smooth_total_err_fh_10 = rbind(SPA_smooth_dpca_arima_total_fh_10$err, SPA_smooth_pca_arima_total_fh_10$err)
rownames(SPA_smooth_total_err_fh_10) = c("DPCA", "PCA")

########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

SPA_dpca_arima_female = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

SPA_pca_arima_female = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

SPA_female_err = rbind(SPA_dpca_arima_female$err, SPA_pca_arima_female$err)
rownames(SPA_female_err) = c("DPCA", "PCA")

# fh = 5

SPA_dpca_arima_female_fh_5 = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

SPA_pca_arima_female_fh_5 = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

SPA_female_err_fh_5 = rbind(SPA_dpca_arima_female_fh_5$err, SPA_pca_arima_female_fh_5$err)
rownames(SPA_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_dpca_arima_female_fh_10 = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

SPA_pca_arima_female_fh_10 = dpca_res(data = SPA_female_ratio, test_data = SPA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = SPA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

SPA_female_err_fh_10 = rbind(SPA_dpca_arima_female_fh_10$err, SPA_pca_arima_female_fh_10$err)
rownames(SPA_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

SPA_dpca_arima_male = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

SPA_pca_arima_male = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

SPA_male_err = rbind(SPA_dpca_arima_male$err, SPA_pca_arima_male$err)
rownames(SPA_male_err) = c("DPCA", "PCA")

# fh = 5

SPA_dpca_arima_male_fh_5 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

SPA_pca_arima_male_fh_5 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

SPA_male_err_fh_5 = rbind(SPA_dpca_arima_male_fh_5$err, SPA_pca_arima_male_fh_5$err)
rownames(SPA_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_dpca_arima_male_fh_10 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

SPA_pca_arima_male_fh_10 = dpca_res(data = SPA_male_ratio, test_data = SPA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = SPA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

SPA_male_err_fh_10 = rbind(SPA_dpca_arima_male_fh_10$err, SPA_pca_arima_male_fh_10$err)
rownames(SPA_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

SPA_dpca_arima_total = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

SPA_pca_arima_total = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

SPA_total_err = rbind(SPA_dpca_arima_total$err, SPA_pca_arima_total$err)
rownames(SPA_total_err) = c("DPCA", "PCA")

# fh = 5

SPA_dpca_arima_total_fh_5 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

SPA_pca_arima_total_fh_5 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

SPA_total_err_fh_5 = rbind(SPA_dpca_arima_total_fh_5$err, SPA_pca_arima_total_fh_5$err)
rownames(SPA_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SPA_dpca_arima_total_fh_10 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

SPA_pca_arima_total_fh_10 = dpca_res(data = SPA_total_ratio, test_data = SPA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = SPA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

SPA_total_err_fh_10 = rbind(SPA_dpca_arima_total_fh_10$err, SPA_pca_arima_total_fh_10$err)
rownames(SPA_total_err_fh_10) = c("DPCA", "PCA")

