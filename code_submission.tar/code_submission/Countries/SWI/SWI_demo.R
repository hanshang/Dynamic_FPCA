rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

SWI_dummy = extract.ages(hmd.mx(country = "CHE", username = "shl8858@telstra.com", password = "hshang85", label = "SWI"), 0:100)
SWI_demo = extract.years(SWI_dummy, 1950:max(SWI_dummy$year))
SWI_smooth = smooth.demogdata(SWI_demo)
n_year = length(SWI_demo$year)

# convert non-stationary series to stationary series

SWI_female_dummy_ratio = SWI_male_dummy_ratio = SWI_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    SWI_female_dummy_ratio[,ik-1] = 2 * (1 - SWI_demo$rate$female[,ik]/SWI_demo$rate$female[,ik-1])/(1 + SWI_demo$rate$female[,ik]/SWI_demo$rate$female[,ik-1])
    SWI_male_dummy_ratio[,ik-1]   = 2 * (1 - SWI_demo$rate$male[,ik]/SWI_demo$rate$male[,ik-1])/(1 + SWI_demo$rate$male[,ik]/SWI_demo$rate$male[,ik-1])
    SWI_total_ratio[,ik-1]  = 2 * (1 - SWI_demo$rate$total[,ik]/SWI_demo$rate$total[,ik-1])/(1 + SWI_demo$rate$total[,ik]/SWI_demo$rate$total[,ik-1])
}  

which(!is.finite(SWI_female_dummy_ratio))
which(!is.finite(SWI_male_dummy_ratio))

SWI_female_ratio = na.locf(SWI_female_dummy_ratio)
SWI_male_ratio   = na.locf(SWI_male_dummy_ratio)

SWI_female_smooth_ratio = SWI_male_smooth_ratio = SWI_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    SWI_female_smooth_ratio[,ik-1] = 2 * (1 - SWI_smooth$rate$female[,ik]/SWI_smooth$rate$female[,ik-1])/(1 + SWI_smooth$rate$female[,ik]/SWI_smooth$rate$female[,ik-1])
    SWI_male_smooth_ratio[,ik-1]   = 2 * (1 - SWI_smooth$rate$male[,ik]/SWI_smooth$rate$male[,ik-1])/(1 + SWI_smooth$rate$male[,ik]/SWI_smooth$rate$male[,ik-1])
    SWI_total_smooth_ratio[,ik-1]  = 2 * (1 - SWI_smooth$rate$total[,ik]/SWI_smooth$rate$total[,ik-1])/(1 + SWI_smooth$rate$total[,ik]/SWI_smooth$rate$total[,ik-1])
}

# compute p-value for the stationary hypothesis tests

T_stationary(SWI_female_ratio); T_stationary(SWI_male_ratio); T_stationary(SWI_total_ratio)  # 0.019 0.009 0.03
T_stationary(SWI_female_smooth_ratio); T_stationary(SWI_male_smooth_ratio); T_stationary(SWI_total_smooth_ratio) # 0.271 0.052 0.078

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

SWI_smooth_dpca_arima_female = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_pca_arima_female = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_female_err = rbind(SWI_smooth_dpca_arima_female$err, SWI_smooth_pca_arima_female$err)
rownames(SWI_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

SWI_smooth_dpca_arima_female_fh_5 = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_pca_arima_female_fh_5 = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_female_err_fh_5 = rbind(SWI_smooth_dpca_arima_female_fh_5$err, SWI_smooth_pca_arima_female_fh_5$err)
rownames(SWI_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_smooth_dpca_arima_female_fh_10 = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_pca_arima_female_fh_10 = dpca_res(data = SWI_female_smooth_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_female_err_fh_10 = rbind(SWI_smooth_dpca_arima_female_fh_10$err, SWI_smooth_pca_arima_female_fh_10$err)
rownames(SWI_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

SWI_smooth_dpca_arima_male = dpca_res(data = SWI_male_smooth_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_pca_arima_male = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_male_err = rbind(SWI_smooth_dpca_arima_male$err, SWI_smooth_pca_arima_male$err)
rownames(SWI_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

SWI_smooth_dpca_arima_male_fh_5 = dpca_res(data = SWI_male_smooth_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_pca_arima_male_fh_5 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_male_err_fh_5 = rbind(SWI_smooth_dpca_arima_male_fh_5$err, SWI_smooth_pca_arima_male_fh_5$err)
rownames(SWI_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_smooth_dpca_arima_male_fh_10 = dpca_res(data = SWI_male_smooth_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_pca_arima_male_fh_10 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_male_err_fh_10 = rbind(SWI_smooth_dpca_arima_male_fh_10$err, SWI_smooth_pca_arima_male_fh_10$err)
rownames(SWI_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

SWI_smooth_dpca_arima_total = dpca_res(data = SWI_total_smooth_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_pca_arima_total = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

SWI_smooth_total_err = rbind(SWI_smooth_dpca_arima_total$err, SWI_smooth_pca_arima_total$err)
rownames(SWI_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

SWI_smooth_dpca_arima_total_fh_5 = dpca_res(data = SWI_total_smooth_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_pca_arima_total_fh_5 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

SWI_smooth_total_err_fh_5 = rbind(SWI_smooth_dpca_arima_total_fh_5$err, SWI_smooth_pca_arima_total_fh_5$err)
rownames(SWI_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_smooth_dpca_arima_total_fh_10 = dpca_res(data = SWI_total_smooth_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_pca_arima_total_fh_10 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

SWI_smooth_total_err_fh_10 = rbind(SWI_smooth_dpca_arima_total_fh_10$err, SWI_smooth_pca_arima_total_fh_10$err)
rownames(SWI_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

SWI_dpca_arima_female = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

SWI_pca_arima_female = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

SWI_female_err = rbind(SWI_dpca_arima_female$err, SWI_pca_arima_female$err)
rownames(SWI_female_err) = c("DPCA", "PCA")

# fh = 5

SWI_dpca_arima_female_fh_5 = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

SWI_pca_arima_female_fh_5 = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 5)

SWI_female_err_fh_5 = rbind(SWI_dpca_arima_female_fh_5$err, SWI_pca_arima_female_fh_5$err)
rownames(SWI_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_dpca_arima_female_fh_10 = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

SWI_pca_arima_female_fh_10 = dpca_res(data = SWI_female_ratio, test_data = SWI_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = SWI_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

SWI_female_err_fh_10 = rbind(SWI_dpca_arima_female_fh_10$err, SWI_pca_arima_female_fh_10$err)
rownames(SWI_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

SWI_dpca_arima_male = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

SWI_pca_arima_male = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

SWI_male_err = rbind(SWI_dpca_arima_male$err, SWI_pca_arima_male$err)
rownames(SWI_male_err) = c("DPCA", "PCA")

# fh = 5

SWI_dpca_arima_male_fh_5 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

SWI_pca_arima_male_fh_5 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

SWI_male_err_fh_5 = rbind(SWI_dpca_arima_male_fh_5$err, SWI_pca_arima_male_fh_5$err)
rownames(SWI_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_dpca_arima_male_fh_10 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

SWI_pca_arima_male_fh_10 = dpca_res(data = SWI_male_ratio, test_data = SWI_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = SWI_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

SWI_male_err_fh_10 = rbind(SWI_dpca_arima_male_fh_10$err, SWI_pca_arima_male_fh_10$err)
rownames(SWI_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

SWI_dpca_arima_total = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

SWI_pca_arima_total = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

SWI_total_err = rbind(SWI_dpca_arima_total$err, SWI_pca_arima_total$err)
rownames(SWI_total_err) = c("DPCA", "PCA")

# fh = 5

SWI_dpca_arima_total_fh_5 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

SWI_pca_arima_total_fh_5 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

SWI_total_err_fh_5 = rbind(SWI_dpca_arima_total_fh_5$err, SWI_pca_arima_total_fh_5$err)
rownames(SWI_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

SWI_dpca_arima_total_fh_10 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

SWI_pca_arima_total_fh_10 = dpca_res(data = SWI_total_ratio, test_data = SWI_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = SWI_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

SWI_total_err_fh_10 = rbind(SWI_dpca_arima_total_fh_10$err, SWI_pca_arima_total_fh_10$err)
rownames(SWI_total_err_fh_10) = c("DPCA", "PCA")

