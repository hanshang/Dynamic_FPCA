rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

UK_dummy = extract.ages(hmd.mx(country = "GBR_NP", username = "shl8858@telstra.com", password = "hshang85", label = "UK"), 0:100)
UK_demo = extract.years(UK_dummy, 1950:max(UK_dummy$year))
UK_smooth = smooth.demogdata(UK_demo)
n_year = length(UK_demo$year)

# convert non-stationary series to stationary series

UK_female_ratio = UK_male_ratio = UK_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    UK_female_ratio[,ik-1] = 2 * (1 - UK_demo$rate$female[,ik]/UK_demo$rate$female[,ik-1])/(1 + UK_demo$rate$female[,ik]/UK_demo$rate$female[,ik-1])
    UK_male_ratio[,ik-1]   = 2 * (1 - UK_demo$rate$male[,ik]/UK_demo$rate$male[,ik-1])/(1 + UK_demo$rate$male[,ik]/UK_demo$rate$male[,ik-1])
    UK_total_ratio[,ik-1]   = 2 * (1 - UK_demo$rate$total[,ik]/UK_demo$rate$total[,ik-1])/(1 + UK_demo$rate$total[,ik]/UK_demo$rate$total[,ik-1])
}  

UK_female_smooth_ratio = UK_male_smooth_ratio = UK_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    UK_female_smooth_ratio[,ik-1] = 2 * (1 - UK_smooth$rate$female[,ik]/UK_smooth$rate$female[,ik-1])/(1 + UK_smooth$rate$female[,ik]/UK_smooth$rate$female[,ik-1])
    UK_male_smooth_ratio[,ik-1]   = 2 * (1 - UK_smooth$rate$male[,ik]/UK_smooth$rate$male[,ik-1])/(1 + UK_smooth$rate$male[,ik]/UK_smooth$rate$male[,ik-1])
    UK_total_smooth_ratio[,ik-1]  = 2 * (1 - UK_smooth$rate$total[,ik]/UK_smooth$rate$total[,ik-1])/(1 + UK_smooth$rate$total[,ik]/UK_smooth$rate$total[,ik-1])
}


# compute p-value for the stationary hypothesis tests

T_stationary(UK_female_ratio); T_stationary(UK_male_ratio); T_stationary(UK_total_ratio)  # 0.13 0.043 0.14
T_stationary(UK_female_smooth_ratio); T_stationary(UK_male_smooth_ratio); T_stationary(UK_total_smooth_ratio)   # 0.161 0.077 0.174

##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

UK_smooth_dpca_arima_female = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_pca_arima_female = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_female_err = rbind(UK_smooth_dpca_arima_female$err, UK_smooth_pca_arima_female$err)
rownames(UK_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

UK_smooth_dpca_arima_female_fh_5 = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_pca_arima_female_fh_5 = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                           jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_female_err_fh_5 = rbind(UK_smooth_dpca_arima_female_fh_5$err, UK_smooth_pca_arima_female_fh_5$err)
rownames(UK_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_smooth_dpca_arima_female_fh_10 = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_pca_arima_female_fh_10 = dpca_res(data = UK_female_smooth_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_female_err_fh_10 = rbind(UK_smooth_dpca_arima_female_fh_10$err, UK_smooth_pca_arima_female_fh_10$err)
rownames(UK_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

UK_smooth_dpca_arima_male = dpca_res(data = UK_male_smooth_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_pca_arima_male = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_male_err = rbind(UK_smooth_dpca_arima_male$err, UK_smooth_pca_arima_male$err)
rownames(UK_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

UK_smooth_dpca_arima_male_fh_5 = dpca_res(data = UK_male_smooth_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_pca_arima_male_fh_5 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                         jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_male_err_fh_5 = rbind(UK_smooth_dpca_arima_male_fh_5$err, UK_smooth_pca_arima_male_fh_5$err)
rownames(UK_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_smooth_dpca_arima_male_fh_10 = dpca_res(data = UK_male_smooth_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_pca_arima_male_fh_10 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_male_err_fh_10 = rbind(UK_smooth_dpca_arima_male_fh_10$err, UK_smooth_pca_arima_male_fh_10$err)
rownames(UK_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

UK_smooth_dpca_arima_total = dpca_res(data = UK_total_smooth_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_pca_arima_total = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

UK_smooth_total_err = rbind(UK_smooth_dpca_arima_total$err, UK_smooth_pca_arima_total$err)
rownames(UK_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

UK_smooth_dpca_arima_total_fh_5 = dpca_res(data = UK_total_smooth_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_pca_arima_total_fh_5 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                          jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

UK_smooth_total_err_fh_5 = rbind(UK_smooth_dpca_arima_total_fh_5$err, UK_smooth_pca_arima_total_fh_5$err)
rownames(UK_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_smooth_dpca_arima_total_fh_10 = dpca_res(data = UK_total_smooth_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_pca_arima_total_fh_10 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

UK_smooth_total_err_fh_10 = rbind(UK_smooth_dpca_arima_total_fh_10$err, UK_smooth_pca_arima_total_fh_10$err)
rownames(UK_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

UK_dpca_arima_female = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

UK_pca_arima_female = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

UK_female_err = rbind(UK_dpca_arima_female$err, UK_pca_arima_female$err)
rownames(UK_female_err) = c("DPCA", "PCA")

# fh = 5

UK_dpca_arima_female_fh_5 = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 5)

UK_pca_arima_female_fh_5 = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                    jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 5)

UK_female_err_fh_5 = rbind(UK_dpca_arima_female_fh_5$err, UK_pca_arima_female_fh_5$err)
rownames(UK_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_dpca_arima_female_fh_10 = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

UK_pca_arima_female_fh_10 = dpca_res(data = UK_female_ratio, test_data = UK_demo$rate$female[,(n_year-29):n_year], 
                                     jump_data = UK_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

UK_female_err_fh_10 = rbind(UK_dpca_arima_female_fh_10$err, UK_pca_arima_female_fh_10$err)
rownames(UK_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

UK_dpca_arima_male = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

UK_pca_arima_male = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

UK_male_err = rbind(UK_dpca_arima_male$err, UK_pca_arima_male$err)
rownames(UK_male_err) = c("DPCA", "PCA")

# fh = 5

UK_dpca_arima_male_fh_5 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                   forecasting_method = "arima", fh = 5)

UK_pca_arima_male_fh_5 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                  jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                  forecasting_method = "arima", fh = 5)

UK_male_err_fh_5 = rbind(UK_dpca_arima_male_fh_5$err, UK_pca_arima_male_fh_5$err)
rownames(UK_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_dpca_arima_male_fh_10 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 10)

UK_pca_arima_male_fh_10 = dpca_res(data = UK_male_ratio, test_data = UK_demo$rate$male[,(n_year-29):n_year], 
                                   jump_data = UK_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 10)

UK_male_err_fh_10 = rbind(UK_dpca_arima_male_fh_10$err, UK_pca_arima_male_fh_10$err)
rownames(UK_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

UK_dpca_arima_total = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

UK_pca_arima_total = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                              jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

UK_total_err = rbind(UK_dpca_arima_total$err, UK_pca_arima_total$err)
rownames(UK_total_err) = c("DPCA", "PCA")

# fh = 5

UK_dpca_arima_total_fh_5 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                    forecasting_method = "arima", fh = 5)

UK_pca_arima_total_fh_5 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                   jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                   forecasting_method = "arima", fh = 5)

UK_total_err_fh_5 = rbind(UK_dpca_arima_total_fh_5$err, UK_pca_arima_total_fh_5$err)
rownames(UK_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

UK_dpca_arima_total_fh_10 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

UK_pca_arima_total_fh_10 = dpca_res(data = UK_total_ratio, test_data = UK_demo$rate$total[,(n_year-29):n_year], 
                                    jump_data = UK_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

UK_total_err_fh_10 = rbind(UK_dpca_arima_total_fh_10$err, UK_pca_arima_total_fh_10$err)
rownames(UK_total_err_fh_10) = c("DPCA", "PCA")


