rm(list = ls())
source("DFPCA.R")
source("Long_run_covariance.R")

# read demogdata

USA_dummy = extract.ages(hmd.mx(country = "USA", username = "shl8858@telstra.com", password = "hshang85", label = "USA"), 0:100)
USA_demo = extract.years(USA_dummy, 1950:max(USA_dummy$year))
USA_smooth = smooth.demogdata(USA_demo)
n_year = length(USA_demo$year)

#######################################
# plot female and male mortality rates
#######################################

savepdf("USA_female", width = 12, height = 10, toplines = 0.5)
plot(USA_demo, series = "female", main = "US: female death rates (1950-2015)")
dev.off()

savepdf("USA_male", width = 12, height = 10, toplines = 0.5)
plot(USA_demo, series = "male", main = "US: male death rates (1950-2015)")
dev.off()

# convert non-stationary series to stationary series

USA_female_ratio = USA_male_ratio = USA_total_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    USA_female_ratio[,ik-1] = 2 * (1 - USA_demo$rate$female[,ik]/USA_demo$rate$female[,ik-1])/(1 + USA_demo$rate$female[,ik]/USA_demo$rate$female[,ik-1])
    USA_male_ratio[,ik-1]   = 2 * (1 - USA_demo$rate$male[,ik]/USA_demo$rate$male[,ik-1])/(1 + USA_demo$rate$male[,ik]/USA_demo$rate$male[,ik-1])
    USA_total_ratio[,ik-1]   = 2 * (1 - USA_demo$rate$total[,ik]/USA_demo$rate$total[,ik-1])/(1 + USA_demo$rate$total[,ik]/USA_demo$rate$total[,ik-1])
}  

USA_female_smooth_ratio = USA_male_smooth_ratio = USA_total_smooth_ratio = matrix(NA, 101, (n_year-1))
for(ik in 2:n_year)
{
    USA_female_smooth_ratio[,ik-1] = 2 * (1 - USA_smooth$rate$female[,ik]/USA_smooth$rate$female[,ik-1])/(1 + USA_smooth$rate$female[,ik]/USA_smooth$rate$female[,ik-1])
    USA_male_smooth_ratio[,ik-1]   = 2 * (1 - USA_smooth$rate$male[,ik]/USA_smooth$rate$male[,ik-1])/(1 + USA_smooth$rate$male[,ik]/USA_smooth$rate$male[,ik-1])
    USA_total_smooth_ratio[,ik-1]  = 2 * (1 - USA_smooth$rate$total[,ik]/USA_smooth$rate$total[,ik-1])/(1 + USA_smooth$rate$total[,ik]/USA_smooth$rate$total[,ik-1])
}

savepdf("USA_female_ratio", width = 12, height = 10, toplines = 0.5)
plot(fts(0:100, USA_female_ratio), ylim = c(-0.33, 0.29), xlab = "Age", ylab = "Mortality rate improvement", main = "US: female death rates (1950-2015)")
dev.off()

savepdf("USA_smooth_female_ratio", width = 12, height = 10, toplines = 0.5)
plot(fts(0:100, USA_female_smooth_ratio), ylim = c(-0.33, 0.29), xlab = "Age", ylab = "Mortality rate improvement", main = "US: female death rates (1950-2015)")
dev.off()


# compute p-value for the stationary hypothesis tests

T_stationary(USA_female_ratio); T_stationary(USA_male_ratio); T_stationary(USA_total_ratio) # 0.272 0.439 0.715
T_stationary(USA_female_smooth_ratio); T_stationary(USA_male_smooth_ratio); T_stationary(USA_total_smooth_ratio)   # 0.329 0.49 0.734

#############################################################
# long-run covariance and variance for female mortality data
#############################################################

savepdf("first_eigen_dpca_female", width = 12, height = 10, toplines = 0.8)
plot(0:100, eigen(USA_female_finite_kernel_long_run$C_BT)$vector[,1], xlab = "Age", type = "l", ylab = "First principal component")
dev.off()

savepdf("first_eigen_pca_female", width = 12, height = 10, toplines = 0.8)
plot(0:100, eigen(var(scale_USA_demo_rate_female))$vector[,1], xlab = "Age", type = "l", ylab="")
dev.off()

savepdf("first_eigen_dpca_female_smooth", width = 12, height = 10, toplines = 0.8)
plot(0:100, eigen(USA_smooth_female_finite_kernel_long_run$C_BT)$vector[,1], xlab = "Age", type = "l", ylab = "First principal component")
dev.off()

savepdf("first_eigen_pca_female_smooth", width = 12, height = 10, toplines = 0.8)
plot(0:100, eigen(var(scale_USA_demo_rate_smooth_female))$vector[,1], xlab = "Age", type = "l", ylab="")
dev.off()

# un-smoothed

USA_female_finite_kernel_long_run = finite_kernel_fun(dat = USA_female_ratio)
scale_USA_demo_rate_female = scale(t(USA_female_ratio), center = TRUE, scale = FALSE)

savepdf("long_run_USA_female", width = 12, height = 10, toplines = 0.5)
filled.contour(0:100, 0:100, USA_female_finite_kernel_long_run$C_BT, xlab = "Age", ylab = "Age")
dev.off()

savepdf("variance_USA_female", width = 12, height = 10, toplines = 0.5)
filled.contour(0:100, 0:100, var(scale_USA_demo_rate_female), xlab = "Age", ylab = "Age")
dev.off()

# smoothed

USA_smooth_female_finite_kernel_long_run = finite_kernel_fun(dat = USA_female_smooth_ratio)
scale_USA_demo_rate_smooth_female = scale(t(USA_female_smooth_ratio), center = TRUE, scale = FALSE)

savepdf("long_run_USA_smooth_female", width = 12, height = 10, toplines = 0.5)
filled.contour(0:100, 0:100, USA_smooth_female_finite_kernel_long_run$C_BT, xlab = "Age", ylab = "Age")
dev.off()

savepdf("variance_USA_smooth_female", width = 12, height = 10, toplines = 0.5)
filled.contour(0:100, 0:100, var(scale_USA_demo_rate_smooth_female), xlab = "Age", ylab = "Age")
dev.off()


###########################################################
# long-run covariance and variance for male mortality data
###########################################################

USA_male_finite_kernel_long_run = finite_kernel_fun(dat = USA_male_ratio)
scale_USA_demo_rate_male = scale(t(USA_male_ratio), center = TRUE, scale = FALSE)

savepdf("long_run_USA_male", width = 12, height = 10, toplines = 0.5)
# persp(0:100, 0:100, USA_male_finite_kernel_long_run$C_BT, xlab = "Age", ylab = "Age", zlab = "", phi = 45, theta = 45, ticktype = "detailed")
filled.contour(0:100, 0:100, USA_male_finite_kernel_long_run$C_BT, ylim = c(0, 0.004))
dev.off()

savepdf("variance_USA_male", width=12, height=10, toplines=0.5)
#persp(0:100, 0:100, var(scale_USA_demo_rate_male), xlab = "Age", ylab = "Age", zlab = "", phi = 45, theta = 45, ticktype = "detailed")
filled.contour(0:100, 0:100, var(scale_USA_demo_rate_male), ylim = c(0, 0.004))
dev.off()


##########################
# forecast accuracy (FDM)
##########################

## female series

# fh = 1

USA_smooth_dpca_arima_female = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                        jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_female = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_female_err = rbind(USA_smooth_dpca_arima_female$err, USA_smooth_pca_arima_female$err)
rownames(USA_smooth_female_err) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_female_fh_5 = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_female_fh_5 = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                            jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_female_err_fh_5 = rbind(USA_smooth_dpca_arima_female_fh_5$err, USA_smooth_pca_arima_female_fh_5$err)
rownames(USA_smooth_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_female_fh_10 = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                              jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_female_fh_10 = dpca_res(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                             jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_female_err_fh_10 = rbind(USA_smooth_dpca_arima_female_fh_10$err, USA_smooth_pca_arima_female_fh_10$err)
rownames(USA_smooth_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

USA_smooth_dpca_arima_male = dpca_res(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_male = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_male_err = rbind(USA_smooth_dpca_arima_male$err, USA_smooth_pca_arima_male$err)
rownames(USA_smooth_male_err) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_male_fh_5 = dpca_res(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_male_fh_5 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                          jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_male_err_fh_5 = rbind(USA_smooth_dpca_arima_male_fh_5$err, USA_smooth_pca_arima_male_fh_5$err)
rownames(USA_smooth_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_male_fh_10 = dpca_res(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                            jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_male_fh_10 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                           jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_male_err_fh_10 = rbind(USA_smooth_dpca_arima_male_fh_10$err, USA_smooth_pca_arima_male_fh_10$err)
rownames(USA_smooth_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

USA_smooth_dpca_arima_total = dpca_res(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                       jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_total = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_total_err = rbind(USA_smooth_dpca_arima_total$err, USA_smooth_pca_arima_total$err)
rownames(USA_smooth_total_err) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_total_fh_5 = dpca_res(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_total_fh_5 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                           jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_total_err_fh_5 = rbind(USA_smooth_dpca_arima_total_fh_5$err, USA_smooth_pca_arima_total_fh_5$err)
rownames(USA_smooth_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_total_fh_10 = dpca_res(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                             jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_total_fh_10 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                            jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                            method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_total_err_fh_10 = rbind(USA_smooth_dpca_arima_total_fh_10$err, USA_smooth_pca_arima_total_fh_10$err)
rownames(USA_smooth_total_err_fh_10) = c("DPCA", "PCA")


########################################
# forecast accuracy (Lee-Carter method)
########################################

## female series

# fh = 1

USA_dpca_arima_female = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                 jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                 forecasting_method = "arima", fh = 1)

USA_pca_arima_female = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                forecasting_method = "arima", fh = 1)

USA_female_err = rbind(USA_dpca_arima_female$err, USA_pca_arima_female$err)
rownames(USA_female_err) = c("DPCA", "PCA")

# fh = 5

USA_dpca_arima_female_fh_5 = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 5)

USA_pca_arima_female_fh_5 = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 5)

USA_female_err_fh_5 = rbind(USA_dpca_arima_female_fh_5$err, USA_pca_arima_female_fh_5$err)
rownames(USA_female_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_female_fh_10 = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                       jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                       forecasting_method = "arima", fh = 10)

USA_pca_arima_female_fh_10 = dpca_res(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                      forecasting_method = "arima", fh = 10)

USA_female_err_fh_10 = rbind(USA_dpca_arima_female_fh_10$err, USA_pca_arima_female_fh_10$err)
rownames(USA_female_err_fh_10) = c("DPCA", "PCA")


## male series

# fh = 1

USA_dpca_arima_male = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 1)

USA_pca_arima_male = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 1)

USA_male_err = rbind(USA_dpca_arima_male$err, USA_pca_arima_male$err)
rownames(USA_male_err) = c("DPCA", "PCA")

# fh = 5

USA_dpca_arima_male_fh_5 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                               jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                               forecasting_method = "arima", fh = 5)

USA_pca_arima_male_fh_5 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                              jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                              forecasting_method = "arima", fh = 5)

USA_male_err_fh_5 = rbind(USA_dpca_arima_male_fh_5$err, USA_pca_arima_male_fh_5$err)
rownames(USA_male_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_male_fh_10 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                     jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                     forecasting_method = "arima", fh = 10)

USA_pca_arima_male_fh_10 = dpca_res(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                    jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                    forecasting_method = "arima", fh = 10)

USA_male_err_fh_10 = rbind(USA_dpca_arima_male_fh_10$err, USA_pca_arima_male_fh_10$err)
rownames(USA_male_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

USA_dpca_arima_total = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 1)

USA_pca_arima_total = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 1)

USA_total_err = rbind(USA_dpca_arima_total$err, USA_pca_arima_total$err)
rownames(USA_total_err) = c("DPCA", "PCA")

# fh = 5

USA_dpca_arima_total_fh_5 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                forecasting_method = "arima", fh = 5)

USA_pca_arima_total_fh_5 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                               jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                               forecasting_method = "arima", fh = 5)

USA_total_err_fh_5 = rbind(USA_dpca_arima_total_fh_5$err, USA_pca_arima_total_fh_5$err)
rownames(USA_total_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_total_fh_10 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                      jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                      forecasting_method = "arima", fh = 10)

USA_pca_arima_total_fh_10 = dpca_res(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                     jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                     forecasting_method = "arima", fh = 10)

USA_total_err_fh_10 = rbind(USA_dpca_arima_total_fh_10$err, USA_pca_arima_total_fh_10$err)
rownames(USA_total_err_fh_10) = c("DPCA", "PCA")


# plot figures

savepdf("USA_demo_plot", width = 12, height = 10, toplines = 0.8)
plot(USA_demo, series = "female", main = "US: female death rates (1950-2015)")
dev.off()

savepdf("USA_smooth_plot", width = 12, height = 10, toplines = 0.8)
plot(USA_smooth, series = "female", main = "US: female death rates (1950-2015)")
dev.off()
