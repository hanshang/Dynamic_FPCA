source("DFPCA_no_center.R")
source("DFPCA.R")

## female series

# fh = 1

USA_smooth_dpca_arima_female_no_center = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year],
                                                           jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                           method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_female_no_center = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year],
                                                          jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_female_err_no_center = rbind(USA_smooth_dpca_arima_female_no_center$err, USA_smooth_pca_arima_female_no_center$err)
rownames(USA_smooth_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                               jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_female_err_no_center_fh_5 = rbind(USA_smooth_dpca_arima_female_no_center_fh_5$err, USA_smooth_pca_arima_female_no_center_fh_5$err)
rownames(USA_smooth_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                                 jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                 method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = USA_female_smooth_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                                jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_female_no_center_err_fh_10 = rbind(USA_smooth_dpca_arima_female_no_center_fh_10$err, USA_smooth_pca_arima_female_no_center_fh_10$err)
rownames(USA_smooth_female_no_center_err_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

USA_smooth_dpca_arima_male_no_center = dpca_res_no_center(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                         jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_male_no_center = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_male_err_no_center = rbind(USA_smooth_dpca_arima_male_no_center$err, USA_smooth_pca_arima_male_no_center$err)
rownames(USA_smooth_male_err_no_center) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                             jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                             method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_male_no_center_err_fh_5 = rbind(USA_smooth_dpca_arima_male_no_center_fh_5$err, USA_smooth_pca_arima_male_no_center_fh_5$err)
rownames(USA_smooth_male_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = USA_male_smooth_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                               jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                              jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_male_no_center_err_fh_10 = rbind(USA_smooth_dpca_arima_male_no_center_fh_10$err, USA_smooth_pca_arima_male_no_center_fh_10$err)
rownames(USA_smooth_male_no_center_err_fh_10) = c("DPCA", "PCA")


## total series

# fh = 1

USA_smooth_dpca_arima_total_no_center = dpca_res_no_center(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                          jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_pca_arima_total_no_center = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 1)

USA_smooth_total_err_no_center = rbind(USA_smooth_dpca_arima_total_no_center$err, USA_smooth_pca_arima_total_no_center$err)
rownames(USA_smooth_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

USA_smooth_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                              jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                              method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 5)

USA_smooth_total_no_center_err_fh_5 = rbind(USA_smooth_dpca_arima_total_no_center_fh_5$err, USA_smooth_pca_arima_total_no_center_fh_5$err)
rownames(USA_smooth_total_no_center_err_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_smooth_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = USA_total_smooth_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                                jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                                method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                               jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                               method = "FDM", forecasting_method = "arima", threshold = 0.85, fh = 10)

USA_smooth_total_no_center_err_fh_10 = rbind(USA_smooth_dpca_arima_total_no_center_fh_10$err, USA_smooth_pca_arima_total_no_center_fh_10$err)
rownames(USA_smooth_total_no_center_err_fh_10) = c("DPCA", "PCA")

####################
# Lee-Carter method
####################

## female series

# fh = 1

USA_dpca_arima_female_no_center = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                    jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                    forecasting_method = "arima", fh = 1)

USA_pca_arima_female_no_center = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                   jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                   forecasting_method = "arima", fh = 1)

USA_female_err_no_center = rbind(USA_dpca_arima_female_no_center$err, USA_pca_arima_female_no_center$err)
rownames(USA_female_err_no_center) = c("DPCA", "PCA")

# fh = 5

USA_dpca_arima_female_no_center_fh_5 = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 5)

USA_pca_arima_female_no_center_fh_5 = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                        jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 5)

USA_female_err_no_center_fh_5 = rbind(USA_dpca_arima_female_no_center_fh_5$err, USA_pca_arima_female_no_center_fh_5$err)
rownames(USA_female_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_female_no_center_fh_10 = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                          jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                          forecasting_method = "arima", fh = 10)

USA_pca_arima_female_no_center_fh_10 = dpca_res_no_center(data = USA_female_ratio, test_data = USA_demo$rate$female[,(n_year-29):n_year], 
                                                         jump_data = USA_demo$rate$female[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                         forecasting_method = "arima", fh = 10)

USA_female_err_no_center_fh_10 = rbind(USA_dpca_arima_female_no_center_fh_10$err, USA_pca_arima_female_no_center_fh_10$err)
rownames(USA_female_err_no_center_fh_10) = c("DPCA", "PCA")

## male series

# fh = 1

USA_dpca_arima_male_no_center = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                  jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                  forecasting_method = "arima", fh = 1)

USA_pca_arima_male_no_center = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                 jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                 forecasting_method = "arima", fh = 1)

USA_male_err_no_center = rbind(USA_dpca_arima_male_no_center$err, USA_pca_arima_male_no_center$err)
rownames(USA_male_err_no_center) = c("DPCA", "PCA")

# fh = 5 

USA_dpca_arima_male_no_center_fh_5 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                       forecasting_method = "arima", fh = 5)

USA_pca_arima_male_no_center_fh_5 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                      jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                      forecasting_method = "arima", fh = 5)

USA_male_err_no_center_fh_5 = rbind(USA_dpca_arima_male_no_center_fh_5$err, USA_pca_arima_male_no_center_fh_5$err)
rownames(USA_male_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_male_no_center_fh_10 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                        jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 10)

USA_pca_arima_male_no_center_fh_10 = dpca_res_no_center(data = USA_male_ratio, test_data = USA_demo$rate$male[,(n_year-29):n_year], 
                                                       jump_data = USA_demo$rate$male[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 10)

USA_male_err_no_center_fh_10 = rbind(USA_dpca_arima_male_no_center_fh_10$err, USA_pca_arima_male_no_center_fh_10$err)
rownames(USA_male_err_no_center_fh_10) = c("DPCA", "PCA")

## total series

# fh = 1

USA_dpca_arima_total_no_center = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                   jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                   forecasting_method = "arima", fh = 1)

USA_pca_arima_total_no_center = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                  jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                  forecasting_method = "arima", fh = 1)

USA_total_err_no_center = rbind(USA_dpca_arima_total_no_center$err, USA_pca_arima_total_no_center$err)
rownames(USA_total_err_no_center) = c("DPCA", "PCA")

# fh = 5

USA_dpca_arima_total_no_center_fh_5 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                        forecasting_method = "arima", fh = 5)

USA_pca_arima_total_no_center_fh_5 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                       jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                       forecasting_method = "arima", fh = 5)

USA_total_err_no_center_fh_5 = rbind(USA_dpca_arima_total_no_center_fh_5$err, USA_pca_arima_total_no_center_fh_5$err)
rownames(USA_total_err_no_center_fh_5) = c("DPCA", "PCA")

# fh = 10

USA_dpca_arima_total_no_center_fh_10 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                         jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "TRUE",
                                                         forecasting_method = "arima", fh = 10)

USA_pca_arima_total_no_center_fh_10 = dpca_res_no_center(data = USA_total_ratio, test_data = USA_demo$rate$total[,(n_year-29):n_year], 
                                                        jump_data = USA_demo$rate$total[,(n_year-30):(n_year-1)], long_run_cov = "FALSE",
                                                        forecasting_method = "arima", fh = 10)

USA_total_err_no_center_fh_10 = rbind(USA_dpca_arima_total_no_center_fh_10$err, USA_pca_arima_total_no_center_fh_10$err)
rownames(USA_total_err_no_center_fh_10) = c("DPCA", "PCA")

