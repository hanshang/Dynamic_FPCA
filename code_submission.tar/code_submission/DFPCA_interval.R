##########################
# interval score function
##########################

interval_score <- function(holdout, lb, ub, alpha)
{
    lb_ind = ifelse(holdout < lb, 1, 0)
    ub_ind = ifelse(holdout > ub, 1, 0)
    score = (ub - lb) + 2/alpha * ((lb - holdout) * lb_ind + (holdout - ub) * ub_ind)
    cover = 1 - (length(which(lb_ind == 1)) + length(which(ub_ind == 1)))/length(holdout)
    return(list(score_mean = mean(score), cover = cover))
}

#####################
# Interval forecasts
#####################

dpca_int <- function(data, test_data, jump_data, long_run_cov = c("TRUE", "FALSE"),
                     method = c("LC", "FDM"), forecasting_method = c("arima", "ets"), 
                     threshold, fh, output = c("point", "interval"), B = 399, level = 80)
{
    method = match.arg(method)
    forecasting_method = match.arg(forecasting_method)
    p_sample = nrow(data)
    curve_forecast = matrix(NA, p_sample, (31-fh))
    eigen_val = ncomp_val = vector("numeric", (31-fh))
    curve_forecast_boot = array(NA, dim = c(p_sample, B, fh, (31-fh)))
    curve_forecast_lb = curve_forecast_ub = array(NA, dim = c(p_sample, fh, (31 - fh)))
    
    for(iw in 1:(31-fh))
    {
        mort = data[,1:(iw+(ncol(data)-31))]
        n_sample = ncol(mort)
        result = finite_kernel_fun(dat = mort)
        mort_center = t(scale(t(mort), center = TRUE, scale = FALSE))
        
        mort_mean = rowMeans(mort)
        mort_center_boot = array(rep(as.matrix(mort_mean), B * fh), dim = c(p_sample, B, fh))
        
        if(method == "LC")
        {
            if(long_run_cov == "TRUE")
            {
                eigen_decomp = eigen(result$C_BT)
                eigen_val[iw] = eigen_decomp$values[1]/sum(eigen_decomp$values)
                basis_dpca = eigen_decomp$vectors[,1]
                score_dpca = t(mort_center) %*% basis_dpca
                if(forecasting_method == "arima")
                {
                    score_dpca_forecast = forecast(auto.arima(score_dpca), h = fh)$mean[fh]
                }
                if(forecasting_method == "ets")
                {
                    score_dpca_forecast = forecast(ets(score_dpca), h = fh)$mean[fh]
                }
                if(output == "point")
                {
                    ratio = mort_mean + as.matrix(basis_dpca) %*% score_dpca_forecast
                    curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)     
                }
                if(output == "interval")
                {
                    forerr = vector("numeric", (n_sample - fh))
                    for(i in fh:(n_sample - 1))
                    {
                        k = i + (1 - fh)
                        if(forecasting_method == "arima")
                        {
                            fore = forecast(auto.arima(score_dpca[1:k]), h = fh)$mean[fh]
                        }
                        if(forecasting_method == "ets")
                        {
                            fore = forecast(ets(score_dpca[1:k]), h = fh)$mean[fh]
                        }
                        forerr[i - fh + 1] = score_dpca[k + fh] - fore
                    }
                    resi = mort_center - as.matrix(basis_dpca) %*% t(score_dpca)
                    q = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            q[i,,j] = sample(resi[i,], size = B, replace = TRUE)
                        }
                    }
                    ny = fo = matrix(NA, B, fh)
                    oli = matrix(rep(score_dpca_forecast, B * fh), B, fh)
                    for(j in 1:fh)
                    {
                        ny[,j] = sample(forerr, size = B, replace = TRUE)
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            fo[i,j] = oli[i,j] + ny[i,j]
                        }
                    }
                    pred = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            pred[,i,j] = as.matrix(basis_dpca) %*% fo[i,j] + mort_center_boot[,i,j] + q[,i,j]
                            curve_forecast_boot[,i,j,iw] = jump_data[,iw] * (2 - pred[,i,j])/(2 + pred[,i,j])
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            curve_forecast_lb[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 - level)/200, na.rm = TRUE)
                            curve_forecast_ub[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 + level)/200, na.rm = TRUE)
                        }
                    }
                }
                rm(mort); rm(result); rm(mort_center); rm(eigen_decomp); rm(basis_dpca); rm(score_dpca); rm(score_dpca_forecast)
            }
            if(long_run_cov == "FALSE")
            {
                eigen_pca = eigen(crossprod((scale(t(mort), center = TRUE, scale = FALSE))))
                eigen_val[iw] = eigen_pca$values[1]/sum(eigen_pca$values)
                basis_pca = eigen_pca$vectors[,1]
                score_pca = t(mort_center) %*% basis_pca
                if(forecasting_method == "arima")
                {
                    score_pca_forecast = forecast(auto.arima(score_pca), h = fh)$mean[fh]
                }
                if(forecasting_method == "ets")
                {
                    score_pca_forecast = forecast(ets(score_pca), h = fh)$mean[fh]
                }
                if(output == "point")
                {
                    ratio = mort_mean + as.matrix(basis_pca) %*% score_pca_forecast
                    curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)  
                }
                if(output == "interval")
                {
                    forerr = vector("numeric", (n_sample - fh))
                    for(i in fh:(n_sample - 1))
                    {
                        k = i + (1 - fh)
                        if(forecasting_method == "arima")
                        {
                            fore = forecast(auto.arima(score_pca[1:k]), h = fh)$mean[fh]
                        }
                        if(forecasting_method == "ets")
                        {
                            fore = forecast(ets(score_pca[1:k]), h = fh)$mean[fh]
                        }
                        forerr[i - fh + 1] = score_pca[k + fh] - fore
                    }
                    resi = mort_center - as.matrix(basis_pca) %*% t(score_pca)
                    q = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            q[i,,j] = sample(resi[i,], size = B, replace = TRUE)
                        }
                    }
                    ny = fo = matrix(NA, B, fh)
                    oli = matrix(rep(score_pca_forecast, B * fh), B, fh)
                    for(j in 1:fh)
                    {
                        ny[,j] = sample(forerr, size = B, replace = TRUE)
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            fo[i,j] = oli[i,j] + ny[i,j]
                        }
                    }
                    pred = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            pred[,i,j] = as.matrix(basis_pca) %*% fo[i,j] + mort_center_boot[,i,j] + q[,i,j]
                            curve_forecast_boot[,i,j,iw] = jump_data[,iw] * (2 - pred[,i,j])/(2 + pred[,i,j])
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            curve_forecast_lb[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 - level)/200, na.rm = TRUE)
                            curve_forecast_ub[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 + level)/200, na.rm = TRUE)
                        }
                    }
                }
                rm(mort); rm(result); rm(mort_center); rm(eigen_pca); rm(basis_pca); rm(score_pca); rm(score_pca_forecast)
            }
        }
        if(method == "FDM")
        {
            if(long_run_cov == "TRUE")
            {
                eigen_decomp = eigen(result$C_BT)
                ncomp_val[iw] = ncomp = head(which(cumsum(eigen_decomp$values/sum(eigen_decomp$values)) >= threshold), 1)
                basis_dpca = eigen_decomp$vectors[,1:ncomp]
                score_dpca = t(mort_center) %*% basis_dpca
                score_dpca_forecast = vector("numeric", ncomp)
                if(forecasting_method == "arima")
                {
                    for(ik in 1:ncomp)
                    {
                        score_dpca_forecast[ik] = forecast(auto.arima(score_dpca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(forecasting_method == "ets")
                {
                    for(ik in 1:ncomp)
                    {
                        score_dpca_forecast[ik] = forecast(ets(score_dpca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(output == "point")
                {
                    ratio = mort_mean + as.matrix(basis_dpca) %*% score_dpca_forecast
                    curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)
                }
                if(output == "interval")
                {
                    forerr = matrix(NA, (n_sample - ncomp - fh + 1), ncomp)
                    for(i in fh:(n_sample - ncomp))
                    {
                        k = i + (ncomp - fh)
                        fore = matrix(NA, 1, ncomp)
                        if(forecasting_method == "arima")
                        {
                            for(j in 1:ncomp)
                            {
                                fore[,j] = forecast(auto.arima(score_dpca[1:k, j]), h = fh)$mean[fh]
                            }
                        }
                        if(forecasting_method == "ets")
                        {
                            for(j in 1:ncomp)
                            {
                                fore[,j] = forecast(ets(score_dpca[1:k, j]), h = fh)$mean[fh]
                            }
                        }
                        forerr[i - fh + 1, ] = score_dpca[k + fh, ] - fore
                    }
                    resi = mort_center - as.matrix(basis_dpca) %*% t(score_dpca)
                    q = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            q[i,,j] = sample(resi[i,], size = B, replace = TRUE)
                        }
                    }
                    ny = fo = array(NA, dim = c(ncomp, B, fh))
                    oli = array(rep(score_dpca_forecast, B * fh), dim = c(ncomp, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:ncomp)
                        {
                            ny[i,,j] = sample(forerr[,i], size = B, replace = TRUE)
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            fo[, i, j] = oli[, i, j] + ny[, i, j]
                        }
                    }
                    pred = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            pred[,i,j] = as.matrix(basis_dpca) %*% fo[,i,j] + mort_center_boot[,i,j] + q[,i,j]
                            curve_forecast_boot[,i,j,iw] = jump_data[,iw] * (2 - pred[,i,j])/(2 + pred[,i,j])
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            curve_forecast_lb[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 - level)/200, na.rm = TRUE)
                            curve_forecast_ub[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 + level)/200, na.rm = TRUE)
                        }
                    }
                }
                rm(mort); rm(result); rm(mort_center); rm(eigen_decomp); rm(basis_dpca); rm(score_dpca); rm(score_dpca_forecast)
            }
            if(long_run_cov == "FALSE")
            {
                eigen_pca = eigen(crossprod(scale(t(mort), center = TRUE, scale = FALSE)))
                ncomp_val[iw] = ncomp = head(which(cumsum(eigen_pca$values/sum(eigen_pca$values)) >= threshold), 1)
                basis_pca = eigen_pca$vectors[,1:ncomp]
                score_pca = t(mort_center) %*% basis_pca
                score_pca_forecast = vector("numeric", ncomp)
                if(forecasting_method == "arima")
                {
                    for(ik in 1:ncomp)
                    {
                        score_pca_forecast[ik] = forecast(auto.arima(score_pca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(forecasting_method == "ets")
                {
                    for(ik in 1:ncomp)
                    {
                      score_pca_forecast[ik] = forecast(ets(score_pca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(output == "point")
                {
                    ratio = mort_mean + as.matrix(basis_pca[,1:ncomp]) %*% score_pca_forecast
                    curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)
                }
                if(output == "interval")
                {
                    forerr = matrix(NA, (n_sample - ncomp - fh + 1), ncomp)
                    for(i in fh:(n_sample - ncomp))
                    {
                        k = i + (ncomp - fh)
                        fore = matrix(NA, 1, ncomp)
                        if(forecasting_method == "arima")
                        {
                            for(j in 1:ncomp)
                            {
                                fore[,j] = forecast(auto.arima(score_pca[1:k, j]), h = fh)$mean[fh]
                            }
                        }
                        if(forecasting_method == "ets")
                        {
                            for(j in 1:ncomp)
                            {
                                fore[,j] = forecast(ets(score_pca[1:k, j]), h = fh)$mean[fh]
                            }
                        }
                        forerr[i - fh + 1, ] = score_pca[k + fh, ] - fore
                    }
                    resi = mort_center - as.matrix(basis_pca) %*% t(score_pca)
                    q = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            q[i,,j] = sample(resi[i,], size = B, replace = TRUE)
                        }
                    }
                    ny = fo = array(NA, dim = c(ncomp, B, fh))
                    oli = array(rep(score_pca_forecast, B * fh), dim = c(ncomp, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:ncomp)
                        {
                            ny[i,,j] = sample(forerr[,i], size = B, replace = TRUE)
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            fo[, i, j] = oli[, i, j] + ny[, i, j]
                        }
                    }
                    pred = array(NA, dim = c(p_sample, B, fh))
                    for(j in 1:fh)
                    {
                        for(i in 1:B)
                        {
                            pred[,i,j] = as.matrix(basis_pca) %*% fo[,i,j] + mort_center_boot[,i,j] + q[,i,j]
                            curve_forecast_boot[,i,j,iw] = jump_data[,iw] * (2 - pred[,i,j])/(2 + pred[,i,j])
                        }
                    }
                    for(j in 1:fh)
                    {
                        for(i in 1:p_sample)
                        {
                            curve_forecast_lb[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 - level)/200, na.rm = TRUE)
                            curve_forecast_ub[i,j,iw] = quantile(curve_forecast_boot[i,,j,iw], (100 + level)/200, na.rm = TRUE)
                        }
                    }
                }
                rm(mort); rm(result); rm(mort_center); rm(eigen_pca); rm(basis_pca); rm(score_pca); rm(score_pca_forecast)
            }
        }
        print(iw)
    }    
    if(method == "LC")
    {
        if(output == "point")
        {
            return(list(curve_forecast = curve_forecast, eigen_val = eigen_val))
        }
        if(output == "interval")
        {
            return(list(curve_forecast_lb = curve_forecast_lb, curve_forecast_ub = curve_forecast_ub))
        }
    }
    if(method == "FDM")
    {
        if(output == "point")
        {
            return(list(curve_forecast = curve_forecast, ncomp_val = ncomp_val))
        }
        if(output == "interval")
        {
            return(list(curve_forecast_lb = curve_forecast_lb, curve_forecast_ub = curve_forecast_ub))            
        }
    }
}

