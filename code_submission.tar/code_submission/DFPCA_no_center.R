#######################################
# USA_female_ratio: 1 to 82 years
# USA_demo$rate$female: 1 to 83 years
#######################################

# mean function: Haberman & Renshaw do not remove mean

dpca_res_no_center <- function(data, test_data, jump_data, long_run_cov = c("TRUE", "FALSE"),
                  			   method = c("LC", "FDM"), forecasting_method = c("arima", "ets"), threshold, fh)
{
    method = match.arg(method)
    forecasting_method = match.arg(forecasting_method)
    curve_forecast = matrix(NA, nrow(data), (31-fh))
    eigen_val = ncomp_val = vector("numeric", (31-fh))
    for(iw in 1:(31-fh))
    {
        mort = data[,1:(iw+(ncol(data)-31))]
        sample_size = ncol(mort)
        result = finite_kernel_fun(dat = mort)
        
        if(method == "LC")
        {
            if(long_run_cov == "TRUE")
            {
                eigen_decomp = eigen(result$C_BT)
                basis_dpca = eigen_decomp$vectors
                eigen_val[iw] = eigen_decomp$values[1]/sum(eigen_decomp$values)
                score_dpca = t(mort) %*% basis_dpca
                if(forecasting_method == "arima")
                {
                    score_dpca_forecast = forecast(auto.arima(score_dpca[,1]), h = fh)
                }
                if(forecasting_method == "ets")
                {
                    score_dpca_forecast = forecast(ets(score_dpca[,1]), h = fh)
                }
                ratio = (as.matrix(basis_dpca[,1]) %*% score_dpca_forecast$mean)[,fh]
                curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)     
                rm(mort); rm(result); rm(eigen_decomp); rm(basis_dpca); rm(score_dpca); rm(score_dpca_forecast); rm(ratio)
            }
            if(long_run_cov == "FALSE")
            {
                eigen_pca = eigen(crossprod(t(mort)))
                basis_pca = eigen_pca$vectors
                eigen_val[iw] = eigen_pca$values[1]/sum(eigen_pca$values)
                score_pca = t(mort) %*% eigen_pca$vectors
                if(forecasting_method == "arima")
                {
                    score_pca_forecast = forecast(auto.arima(score_pca[,1]), h = fh)
                }
                if(forecasting_method == "ets")
                {
                    score_pca_forecast = forecast(ets(score_pca[,1]), h = fh)
                }
                ratio = (as.matrix(basis_pca[,1]) %*% score_pca_forecast$mean)[,fh]
                curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)     
                rm(mort); rm(result); rm(eigen_pca); rm(basis_pca); rm(score_pca); rm(score_pca_forecast); rm(ratio)
            }
        }
        if(method == "FDM")
        {
            if(long_run_cov == "TRUE")
            {
                eigen_decomp = eigen(result$C_BT)
                basis_dpca = eigen_decomp$vectors
                ncomp_1 = head(which(cumsum(eigen_decomp$values/sum(eigen_decomp$values)) >= threshold), 1)
                ncomp_2 = head(which(eigen_decomp$values[1]/eigen_decomp$values <= sqrt(sample_size)/(log10(sample_size))), 1)
                ncomp_val[iw] = ncomp = max(ncomp_1, ncomp_2) 
                score_dpca = t(mort) %*% basis_dpca
                score_dpca_forecast = vector("numeric", ncomp)
                if(forecasting_method == "arima")
                {
                    for(ik in 1:ncomp)
                    {
                        score_dpca_forecast[ik] = forecast(auto.arima(score_dpca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(forecasting_method == "ets")
                {
                    for(ik in 1:ncomp)
                    {
                        score_dpca_forecast[ik] = forecast(ets(score_dpca[,ik]), h = fh)$mean[fh]
                    }
                }
                ratio = (as.matrix(basis_dpca[,1:ncomp]) %*% score_dpca_forecast)
                curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)
                rm(mort); rm(result); rm(eigen_decomp); rm(basis_dpca); rm(score_dpca); rm(score_dpca_forecast); rm(ratio)
            }
            if(long_run_cov == "FALSE")
            {
                eigen_pca = eigen(crossprod(t(mort)))
                basis_pca = eigen_pca$vectors
                ncomp_1 = head(which(cumsum(eigen_pca$values/sum(eigen_pca$values)) >= threshold), 1)
                ncomp_2 = head(which(eigen_pca$values[1]/eigen_pca$values <= sqrt(sample_size)/(log10(sample_size))), 1)
                ncomp_val[iw] = ncomp = max(ncomp_1, ncomp_2) 
                score_pca = t(mort) %*% eigen_pca$vectors
                score_pca_forecast = vector("numeric", ncomp)
                if(forecasting_method == "arima")
                {
                    for(ik in 1:ncomp)
                    {
                        score_pca_forecast[ik] = forecast(auto.arima(score_pca[,ik]), h = fh)$mean[fh]
                    }
                }
                if(forecasting_method == "ets")
                {
                    for(ik in 1:ncomp)
                    {
                        score_pca_forecast[ik] = forecast(ets(score_pca[,ik]), h = fh)$mean[fh]
                    }
                }
                ratio = (as.matrix(basis_pca[,1:ncomp]) %*% score_pca_forecast)
                curve_forecast[,iw] = jump_data[,iw] * (2 - ratio)/(2 + ratio)
                rm(mort); rm(result); rm(eigen_pca); rm(basis_pca); rm(score_pca);
                rm(score_pca_forecast); rm(ratio)
            }
        }
        print(iw)
    }    
    err = matrix(c(ftsa:::mae(curve_forecast, test_data[,fh:30]), 
                   ftsa:::rmse(curve_forecast, test_data[,fh:30])), nrow = 1)
    colnames(err) = c("MAFE", "RMSFE")
    if(method == "LC")
    {
        return(list(curve_forecast = curve_forecast, err = err, eigen_val = eigen_val))
    }
    if(method == "FDM")
    {
        return(list(curve_forecast = curve_forecast, err = err, ncomp_val = ncomp_val))
    }
}


