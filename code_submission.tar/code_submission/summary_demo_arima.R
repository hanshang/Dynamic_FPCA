#################
# load R outputs
#################

country = c("AUS", "AUT", "BEL", "BGR", "CAN", "CZE", "DEN", "FIN", "FRA",
            "HUN", "ICE", "IRL", "ITA", "JPN", "NLD", "NOR", "NZ",  "PRT", 
            "SPA", "SVK", "SWE", "SWI", "UK",  "USA")

# please run code within each country

for(i in 1:length(country))
{
    load(paste(paste(paste(paste(paste("/Volumes/MY PASSPORT/Dropbox/Todos/Dynamic FPCA/code/Countries/", country[i], sep=""),"/",sep=""), "arima/", sep=""), country[i], sep=""), "_demo_v2.RData",sep=""))
    print(i)
}

#########
# fh = 1
#########

country_female_err = c("AUS_female_err", "AUT_female_err", "BEL_female_err", "BGR_female_err",
                       "CAN_female_err", "CZE_female_err", "DEN_female_err", "FIN_female_err",
                       "FRA_female_err", "HUN_female_err", "ICE_female_err", "IRL_female_err",
                       "ITA_female_err", "JPN_female_err", "NLD_female_err", "NOR_female_err",
                       "NZ_female_err",  "PRT_female_err", "SPA_female_err", "SVK_female_err",
                       "SWE_female_err", "SWI_female_err", "UK_female_err",  "USA_female_err")

country_male_err = c("AUS_male_err", "AUT_male_err", "BEL_male_err", "BGR_male_err",
                     "CAN_male_err", "CZE_male_err", "DEN_male_err", "FIN_male_err",
                     "FRA_male_err", "HUN_male_err", "ICE_male_err", "IRL_male_err",
                     "ITA_male_err", "JPN_male_err", "NLD_male_err", "NOR_male_err",
                     "NZ_male_err",  "PRT_male_err", "SPA_male_err", "SVK_male_err",
                     "SWE_male_err", "SWI_male_err", "UK_male_err",  "USA_male_err")

country_total_err = c("AUS_total_err", "AUT_total_err", "BEL_total_err", "BGR_total_err",
                      "CAN_total_err", "CZE_total_err", "DEN_total_err", "FIN_total_err",
                      "FRA_total_err", "HUN_total_err", "ICE_total_err", "IRL_total_err",
                      "ITA_total_err", "JPN_total_err", "NLD_total_err", "NOR_total_err",
                      "NZ_total_err",  "PRT_total_err", "SPA_total_err", "SVK_total_err",
                      "SWE_total_err", "SWI_total_err", "UK_total_err",  "USA_total_err")


country_smooth_female_err = c("AUS_smooth_female_err", "AUT_smooth_female_err", "BEL_smooth_female_err", "BGR_smooth_female_err",
                              "CAN_smooth_female_err", "CZE_smooth_female_err", "DEN_smooth_female_err", "FIN_smooth_female_err",
                              "FRA_smooth_female_err", "HUN_smooth_female_err", "ICE_smooth_female_err", "IRL_smooth_female_err",
                              "ITA_smooth_female_err", "JPN_smooth_female_err", "NLD_smooth_female_err", "NOR_smooth_female_err",
                              "NZ_smooth_female_err",  "PRT_smooth_female_err", "SPA_smooth_female_err", "SVK_smooth_female_err",
                              "SWE_smooth_female_err", "SWI_smooth_female_err", "UK_smooth_female_err",  "USA_smooth_female_err")

country_smooth_male_err = c("AUS_smooth_male_err", "AUT_smooth_male_err", "BEL_smooth_male_err", "BGR_smooth_male_err",
                            "CAN_smooth_male_err", "CZE_smooth_male_err", "DEN_smooth_male_err", "FIN_smooth_male_err",
                            "FRA_smooth_male_err", "HUN_smooth_male_err", "ICE_smooth_male_err", "IRL_smooth_male_err",
                            "ITA_smooth_male_err", "JPN_smooth_male_err", "NLD_smooth_male_err", "NOR_smooth_male_err",
                            "NZ_smooth_male_err",  "PRT_smooth_male_err", "SPA_smooth_male_err", "SVK_smooth_male_err",
                            "SWE_smooth_male_err", "SWI_smooth_male_err", "UK_smooth_male_err",  "USA_smooth_male_err")

country_smooth_total_err = c("AUS_smooth_total_err", "AUT_smooth_total_err", "BEL_smooth_total_err", "BGR_smooth_total_err",
                             "CAN_smooth_total_err", "CZE_smooth_total_err", "DEN_smooth_total_err", "FIN_smooth_total_err",
                             "FRA_smooth_total_err", "HUN_smooth_total_err", "ICE_smooth_total_err", "IRL_smooth_total_err",
                             "ITA_smooth_total_err", "JPN_smooth_total_err", "NLD_smooth_total_err", "NOR_smooth_total_err",
                             "NZ_smooth_total_err",  "PRT_smooth_total_err", "SPA_smooth_total_err", "SVK_smooth_total_err",
                             "SWE_smooth_total_err", "SWI_smooth_total_err", "UK_smooth_total_err",  "USA_smooth_total_err")

# no_center

country_female_err_no_center = c("AUS_female_err_no_center", "AUT_female_err_no_center", "BEL_female_err_no_center", "BGR_female_err_no_center",
                                 "CAN_female_err_no_center", "CZE_female_err_no_center", "DEN_female_err_no_center", "FIN_female_err_no_center",
                                 "FRA_female_err_no_center", "HUN_female_err_no_center", "ICE_female_err_no_center", "IRL_female_err_no_center",
                                 "ITA_female_err_no_center", "JPN_female_err_no_center", "NLD_female_err_no_center", "NOR_female_err_no_center",
                                 "NZ_female_err_no_center",  "PRT_female_err_no_center", "SPA_female_err_no_center", "SVK_female_err_no_center",
                                 "SWE_female_err_no_center", "SWI_female_err_no_center", "UK_female_err_no_center",  "USA_female_err_no_center")

country_male_err_no_center = c("AUS_male_err_no_center", "AUT_male_err_no_center", "BEL_male_err_no_center", "BGR_male_err_no_center",
                               "CAN_male_err_no_center", "CZE_male_err_no_center", "DEN_male_err_no_center", "FIN_male_err_no_center",
                               "FRA_male_err_no_center", "HUN_male_err_no_center", "ICE_male_err_no_center", "IRL_male_err_no_center",
                               "ITA_male_err_no_center", "JPN_male_err_no_center", "NLD_male_err_no_center", "NOR_male_err_no_center",
                               "NZ_male_err_no_center",  "PRT_male_err_no_center", "SPA_male_err_no_center", "SVK_male_err_no_center",
                               "SWE_male_err_no_center", "SWI_male_err_no_center", "UK_male_err_no_center",  "USA_male_err_no_center")

country_total_err_no_center = c("AUS_total_err_no_center", "AUT_total_err_no_center", "BEL_total_err_no_center", "BGR_total_err_no_center",
                                "CAN_total_err_no_center", "CZE_total_err_no_center", "DEN_total_err_no_center", "FIN_total_err_no_center",
                                "FRA_total_err_no_center", "HUN_total_err_no_center", "ICE_total_err_no_center", "IRL_total_err_no_center",
                                "ITA_total_err_no_center", "JPN_total_err_no_center", "NLD_total_err_no_center", "NOR_total_err_no_center",
                                "NZ_total_err_no_center",  "PRT_total_err_no_center", "SPA_total_err_no_center", "SVK_total_err_no_center",
                                "SWE_total_err_no_center", "SWI_total_err_no_center", "UK_total_err_no_center",  "USA_total_err_no_center")


country_smooth_female_err_no_center = c("AUS_smooth_female_err_no_center", "AUT_smooth_female_err_no_center", "BEL_smooth_female_err_no_center", "BGR_smooth_female_err_no_center",
                                        "CAN_smooth_female_err_no_center", "CZE_smooth_female_err_no_center", "DEN_smooth_female_err_no_center", "FIN_smooth_female_err_no_center",
                                        "FRA_smooth_female_err_no_center", "HUN_smooth_female_err_no_center", "ICE_smooth_female_err_no_center", "IRL_smooth_female_err_no_center",
                                        "ITA_smooth_female_err_no_center", "JPN_smooth_female_err_no_center", "NLD_smooth_female_err_no_center", "NOR_smooth_female_err_no_center",
                                        "NZ_smooth_female_err_no_center",  "PRT_smooth_female_err_no_center", "SPA_smooth_female_err_no_center", "SVK_smooth_female_err_no_center",
                                        "SWE_smooth_female_err_no_center", "SWI_smooth_female_err_no_center", "UK_smooth_female_err_no_center",  "USA_smooth_female_err_no_center")

country_smooth_male_err_no_center = c("AUS_smooth_male_err_no_center", "AUT_smooth_male_err_no_center", "BEL_smooth_male_err_no_center", "BGR_smooth_male_err_no_center",
                                      "CAN_smooth_male_err_no_center", "CZE_smooth_male_err_no_center", "DEN_smooth_male_err_no_center", "FIN_smooth_male_err_no_center",
                                      "FRA_smooth_male_err_no_center", "HUN_smooth_male_err_no_center", "ICE_smooth_male_err_no_center", "IRL_smooth_male_err_no_center",
                                      "ITA_smooth_male_err_no_center", "JPN_smooth_male_err_no_center", "NLD_smooth_male_err_no_center", "NOR_smooth_male_err_no_center",
                                      "NZ_smooth_male_err_no_center",  "PRT_smooth_male_err_no_center", "SPA_smooth_male_err_no_center", "SVK_smooth_male_err_no_center",
                                      "SWE_smooth_male_err_no_center", "SWI_smooth_male_err_no_center", "UK_smooth_male_err_no_center",  "USA_smooth_male_err_no_center")

country_smooth_total_err_no_center = c("AUS_smooth_total_err_no_center", "AUT_smooth_total_err_no_center", "BEL_smooth_total_err_no_center", "BGR_smooth_total_err_no_center",
                                       "CAN_smooth_total_err_no_center", "CZE_smooth_total_err_no_center", "DEN_smooth_total_err_no_center", "FIN_smooth_total_err_no_center",
                                       "FRA_smooth_total_err_no_center", "HUN_smooth_total_err_no_center", "ICE_smooth_total_err_no_center", "IRL_smooth_total_err_no_center",
                                       "ITA_smooth_total_err_no_center", "JPN_smooth_total_err_no_center", "NLD_smooth_total_err_no_center", "NOR_smooth_total_err_no_center",
                                       "NZ_smooth_total_err_no_center",  "PRT_smooth_total_err_no_center", "SPA_smooth_total_err_no_center", "SVK_smooth_total_err_no_center",
                                       "SWE_smooth_total_err_no_center", "SWI_smooth_total_err_no_center", "UK_smooth_total_err_no_center",  "USA_smooth_total_err_no_center")

#########
# fh = 5
#########

country_female_err_fh_5 = c("AUS_female_err_fh_5", "AUT_female_err_fh_5", "BEL_female_err_fh_5", "BGR_female_err_fh_5",
                            "CAN_female_err_fh_5", "CZE_female_err_fh_5", "DEN_female_err_fh_5", "FIN_female_err_fh_5",
                            "FRA_female_err_fh_5", "HUN_female_err_fh_5", "ICE_female_err_fh_5", "IRL_female_err_fh_5",
                            "ITA_female_err_fh_5", "JPN_female_err_fh_5", "NLD_female_err_fh_5", "NOR_female_err_fh_5",
                            "NZ_female_err_fh_5",  "PRT_female_err_fh_5", "SPA_female_err_fh_5", "SVK_female_err_fh_5",
                            "SWE_female_err_fh_5", "SWI_female_err_fh_5", "UK_female_err_fh_5",  "USA_female_err_fh_5")

country_male_err_fh_5 = c("AUS_male_err_fh_5", "AUT_male_err_fh_5", "BEL_male_err_fh_5", "BGR_male_err_fh_5",
                          "CAN_male_err_fh_5", "CZE_male_err_fh_5", "DEN_male_err_fh_5", "FIN_male_err_fh_5",
                          "FRA_male_err_fh_5", "HUN_male_err_fh_5", "ICE_male_err_fh_5", "IRL_male_err_fh_5",
                          "ITA_male_err_fh_5", "JPN_male_err_fh_5", "NLD_male_err_fh_5", "NOR_male_err_fh_5",
                          "NZ_male_err_fh_5",  "PRT_male_err_fh_5", "SPA_male_err_fh_5", "SVK_male_err_fh_5",
                          "SWE_male_err_fh_5", "SWI_male_err_fh_5", "UK_male_err_fh_5",  "USA_male_err_fh_5")

country_total_err_fh_5 = c("AUS_total_err_fh_5", "AUT_total_err_fh_5", "BEL_total_err_fh_5", "BGR_total_err_fh_5",
                           "CAN_total_err_fh_5", "CZE_total_err_fh_5", "DEN_total_err_fh_5", "FIN_total_err_fh_5",
                           "FRA_total_err_fh_5", "HUN_total_err_fh_5", "ICE_total_err_fh_5", "IRL_total_err_fh_5",
                           "ITA_total_err_fh_5", "JPN_total_err_fh_5", "NLD_total_err_fh_5", "NOR_total_err_fh_5",
                           "NZ_total_err_fh_5",  "PRT_total_err_fh_5", "SPA_total_err_fh_5", "SVK_total_err_fh_5",
                           "SWE_total_err_fh_5", "SWI_total_err_fh_5", "UK_total_err_fh_5",  "USA_total_err_fh_5")


country_smooth_female_err_fh_5 = c("AUS_smooth_female_err_fh_5", "AUT_smooth_female_err_fh_5", "BEL_smooth_female_err_fh_5", "BGR_smooth_female_err_fh_5",
                                   "CAN_smooth_female_err_fh_5", "CZE_smooth_female_err_fh_5", "DEN_smooth_female_err_fh_5", "FIN_smooth_female_err_fh_5",
                                   "FRA_smooth_female_err_fh_5", "HUN_smooth_female_err_fh_5", "ICE_smooth_female_err_fh_5", "IRL_smooth_female_err_fh_5",
                                   "ITA_smooth_female_err_fh_5", "JPN_smooth_female_err_fh_5", "NLD_smooth_female_err_fh_5", "NOR_smooth_female_err_fh_5",
                                   "NZ_smooth_female_err_fh_5",  "PRT_smooth_female_err_fh_5", "SPA_smooth_female_err_fh_5", "SVK_smooth_female_err_fh_5",
                                   "SWE_smooth_female_err_fh_5", "SWI_smooth_female_err_fh_5", "UK_smooth_female_err_fh_5",  "USA_smooth_female_err_fh_5")

country_smooth_male_err_fh_5 = c("AUS_smooth_male_err_fh_5", "AUT_smooth_male_err_fh_5", "BEL_smooth_male_err_fh_5", "BGR_smooth_male_err_fh_5",
                                 "CAN_smooth_male_err_fh_5", "CZE_smooth_male_err_fh_5", "DEN_smooth_male_err_fh_5", "FIN_smooth_male_err_fh_5",
                                 "FRA_smooth_male_err_fh_5", "HUN_smooth_male_err_fh_5", "ICE_smooth_male_err_fh_5", "IRL_smooth_male_err_fh_5",
                                 "ITA_smooth_male_err_fh_5", "JPN_smooth_male_err_fh_5", "NLD_smooth_male_err_fh_5", "NOR_smooth_male_err_fh_5",
                                 "NZ_smooth_male_err_fh_5",  "PRT_smooth_male_err_fh_5", "SPA_smooth_male_err_fh_5", "SVK_smooth_male_err_fh_5",
                                 "SWE_smooth_male_err_fh_5", "SWI_smooth_male_err_fh_5", "UK_smooth_male_err_fh_5",  "USA_smooth_male_err_fh_5")

country_smooth_total_err_fh_5 = c("AUS_smooth_total_err_fh_5", "AUT_smooth_total_err_fh_5", "BEL_smooth_total_err_fh_5", "BGR_smooth_total_err_fh_5",
                                  "CAN_smooth_total_err_fh_5", "CZE_smooth_total_err_fh_5", "DEN_smooth_total_err_fh_5", "FIN_smooth_total_err_fh_5",
                                  "FRA_smooth_total_err_fh_5", "HUN_smooth_total_err_fh_5", "ICE_smooth_total_err_fh_5", "IRL_smooth_total_err_fh_5",
                                  "ITA_smooth_total_err_fh_5", "JPN_smooth_total_err_fh_5", "NLD_smooth_total_err_fh_5", "NOR_smooth_total_err_fh_5",
                                  "NZ_smooth_total_err_fh_5",  "PRT_smooth_total_err_fh_5", "SPA_smooth_total_err_fh_5", "SVK_smooth_total_err_fh_5",
                                  "SWE_smooth_total_err_fh_5", "SWI_smooth_total_err_fh_5", "UK_smooth_total_err_fh_5",  "USA_smooth_total_err_fh_5")



country_female_err_no_center_fh_5 = c("AUS_female_err_no_center_fh_5", "AUT_female_err_no_center_fh_5", "BEL_female_err_no_center_fh_5", "BGR_female_err_no_center_fh_5",
                                      "CAN_female_err_no_center_fh_5", "CZE_female_err_no_center_fh_5", "DEN_female_err_no_center_fh_5", "FIN_female_err_no_center_fh_5",
                                      "FRA_female_err_no_center_fh_5", "HUN_female_err_no_center_fh_5", "ICE_female_err_no_center_fh_5", "IRL_female_err_no_center_fh_5",
                                      "ITA_female_err_no_center_fh_5", "JPN_female_err_no_center_fh_5", "NLD_female_err_no_center_fh_5", "NOR_female_err_no_center_fh_5",
                                      "NZ_female_err_no_center_fh_5",  "PRT_female_err_no_center_fh_5", "SPA_female_err_no_center_fh_5", "SVK_female_err_no_center_fh_5",
                                      "SWE_female_err_no_center_fh_5", "SWI_female_err_no_center_fh_5", "UK_female_err_no_center_fh_5",  "USA_female_err_no_center_fh_5")

country_male_err_no_center_fh_5 = c("AUS_male_err_no_center_fh_5", "AUT_male_err_no_center_fh_5", "BEL_male_err_no_center_fh_5", "BGR_male_err_no_center_fh_5",
                                    "CAN_male_err_no_center_fh_5", "CZE_male_err_no_center_fh_5", "DEN_male_err_no_center_fh_5", "FIN_male_err_no_center_fh_5",
                                    "FRA_male_err_no_center_fh_5", "HUN_male_err_no_center_fh_5", "ICE_male_err_no_center_fh_5", "IRL_male_err_no_center_fh_5",
                                    "ITA_male_err_no_center_fh_5", "JPN_male_err_no_center_fh_5", "NLD_male_err_no_center_fh_5", "NOR_male_err_no_center_fh_5",
                                    "NZ_male_err_no_center_fh_5",  "PRT_male_err_no_center_fh_5", "SPA_male_err_no_center_fh_5", "SVK_male_err_no_center_fh_5",
                                    "SWE_male_err_no_center_fh_5", "SWI_male_err_no_center_fh_5", "UK_male_err_no_center_fh_5",  "USA_male_err_no_center_fh_5")

country_total_err_no_center_fh_5 = c("AUS_total_err_no_center_fh_5", "AUT_total_err_no_center_fh_5", "BEL_total_err_no_center_fh_5", "BGR_total_err_no_center_fh_5",
                                     "CAN_total_err_no_center_fh_5", "CZE_total_err_no_center_fh_5", "DEN_total_err_no_center_fh_5", "FIN_total_err_no_center_fh_5",
                                     "FRA_total_err_no_center_fh_5", "HUN_total_err_no_center_fh_5", "ICE_total_err_no_center_fh_5", "IRL_total_err_no_center_fh_5",
                                     "ITA_total_err_no_center_fh_5", "JPN_total_err_no_center_fh_5", "NLD_total_err_no_center_fh_5", "NOR_total_err_no_center_fh_5",
                                     "NZ_total_err_no_center_fh_5",  "PRT_total_err_no_center_fh_5", "SPA_total_err_no_center_fh_5", "SVK_total_err_no_center_fh_5",
                                     "SWE_total_err_no_center_fh_5", "SWI_total_err_no_center_fh_5", "UK_total_err_no_center_fh_5",  "USA_total_err_no_center_fh_5")


country_smooth_female_err_no_center_fh_5 = c("AUS_smooth_female_err_no_center_fh_5", "AUT_smooth_female_err_no_center_fh_5", "BEL_smooth_female_err_no_center_fh_5", "BGR_smooth_female_err_no_center_fh_5",
                                             "CAN_smooth_female_err_no_center_fh_5", "CZE_smooth_female_err_no_center_fh_5", "DEN_smooth_female_err_no_center_fh_5", "FIN_smooth_female_err_no_center_fh_5",
                                             "FRA_smooth_female_err_no_center_fh_5", "HUN_smooth_female_err_no_center_fh_5", "ICE_smooth_female_err_no_center_fh_5", "IRL_smooth_female_err_no_center_fh_5",
                                             "ITA_smooth_female_err_no_center_fh_5", "JPN_smooth_female_err_no_center_fh_5", "NLD_smooth_female_err_no_center_fh_5", "NOR_smooth_female_err_no_center_fh_5",
                                             "NZ_smooth_female_err_no_center_fh_5",  "PRT_smooth_female_err_no_center_fh_5", "SPA_smooth_female_err_no_center_fh_5", "SVK_smooth_female_err_no_center_fh_5",
                                             "SWE_smooth_female_err_no_center_fh_5", "SWI_smooth_female_err_no_center_fh_5", "UK_smooth_female_err_no_center_fh_5",  "USA_smooth_female_err_no_center_fh_5")



country_smooth_male_no_center_err_fh_5 = c("AUS_smooth_male_no_center_err_fh_5", "AUT_smooth_male_no_center_err_fh_5", "BEL_smooth_male_no_center_err_fh_5", "BGR_smooth_male_no_center_err_fh_5",
                                           "CAN_smooth_male_no_center_err_fh_5", "CZE_smooth_male_no_center_err_fh_5", "DEN_smooth_male_no_center_err_fh_5", "FIN_smooth_male_no_center_err_fh_5",
                                           "FRA_smooth_male_no_center_err_fh_5", "HUN_smooth_male_no_center_err_fh_5", "ICE_smooth_male_no_center_err_fh_5", "IRL_smooth_male_no_center_err_fh_5",
                                           "ITA_smooth_male_no_center_err_fh_5", "JPN_smooth_male_no_center_err_fh_5", "NLD_smooth_male_no_center_err_fh_5", "NOR_smooth_male_no_center_err_fh_5",
                                           "NZ_smooth_male_no_center_err_fh_5",  "PRT_smooth_male_no_center_err_fh_5", "SPA_smooth_male_no_center_err_fh_5", "SVK_smooth_male_no_center_err_fh_5",
                                           "SWE_smooth_male_no_center_err_fh_5", "SWI_smooth_male_no_center_err_fh_5", "UK_smooth_male_no_center_err_fh_5",  "USA_smooth_male_no_center_err_fh_5")

country_smooth_total_no_center_err_fh_5 = c("AUS_smooth_total_no_center_err_fh_5", "AUT_smooth_total_no_center_err_fh_5", "BEL_smooth_total_no_center_err_fh_5", "BGR_smooth_total_no_center_err_fh_5",
                                            "CAN_smooth_total_no_center_err_fh_5", "CZE_smooth_total_no_center_err_fh_5", "DEN_smooth_total_no_center_err_fh_5", "FIN_smooth_total_no_center_err_fh_5",
                                            "FRA_smooth_total_no_center_err_fh_5", "HUN_smooth_total_no_center_err_fh_5", "ICE_smooth_total_no_center_err_fh_5", "IRL_smooth_total_no_center_err_fh_5",
                                            "ITA_smooth_total_no_center_err_fh_5", "JPN_smooth_total_no_center_err_fh_5", "NLD_smooth_total_no_center_err_fh_5", "NOR_smooth_total_no_center_err_fh_5",
                                            "NZ_smooth_total_no_center_err_fh_5",  "PRT_smooth_total_no_center_err_fh_5", "SPA_smooth_total_no_center_err_fh_5", "SVK_smooth_total_no_center_err_fh_5",
                                            "SWE_smooth_total_no_center_err_fh_5", "SWI_smooth_total_no_center_err_fh_5", "UK_smooth_total_no_center_err_fh_5",  "USA_smooth_total_no_center_err_fh_5")

##########
# fh = 10
##########

country_female_err_fh_10 = c("AUS_female_err_fh_10", "AUT_female_err_fh_10", "BEL_female_err_fh_10", "BGR_female_err_fh_10",
                             "CAN_female_err_fh_10", "CZE_female_err_fh_10", "DEN_female_err_fh_10", "FIN_female_err_fh_10",
                             "FRA_female_err_fh_10", "HUN_female_err_fh_10", "ICE_female_err_fh_10", "IRL_female_err_fh_10",
                             "ITA_female_err_fh_10", "JPN_female_err_fh_10", "NLD_female_err_fh_10", "NOR_female_err_fh_10",
                             "NZ_female_err_fh_10",  "PRT_female_err_fh_10", "SPA_female_err_fh_10", "SVK_female_err_fh_10",
                             "SWE_female_err_fh_10", "SWI_female_err_fh_10", "UK_female_err_fh_10",  "USA_female_err_fh_10")

country_male_err_fh_10 = c("AUS_male_err_fh_10", "AUT_male_err_fh_10", "BEL_male_err_fh_10", "BGR_male_err_fh_10",
                           "CAN_male_err_fh_10", "CZE_male_err_fh_10", "DEN_male_err_fh_10", "FIN_male_err_fh_10",
                           "FRA_male_err_fh_10", "HUN_male_err_fh_10", "ICE_male_err_fh_10", "IRL_male_err_fh_10",
                           "ITA_male_err_fh_10", "JPN_male_err_fh_10", "NLD_male_err_fh_10", "NOR_male_err_fh_10",
                           "NZ_male_err_fh_10",  "PRT_male_err_fh_10", "SPA_male_err_fh_10", "SVK_male_err_fh_10",
                           "SWE_male_err_fh_10", "SWI_male_err_fh_10", "UK_male_err_fh_10",  "USA_male_err_fh_10")

country_total_err_fh_10 = c("AUS_total_err_fh_10", "AUT_total_err_fh_10", "BEL_total_err_fh_10", "BGR_total_err_fh_10",
                            "CAN_total_err_fh_10", "CZE_total_err_fh_10", "DEN_total_err_fh_10", "FIN_total_err_fh_10",
                            "FRA_total_err_fh_10", "HUN_total_err_fh_10", "ICE_total_err_fh_10", "IRL_total_err_fh_10",
                            "ITA_total_err_fh_10", "JPN_total_err_fh_10", "NLD_total_err_fh_10", "NOR_total_err_fh_10",
                            "NZ_total_err_fh_10",  "PRT_total_err_fh_10", "SPA_total_err_fh_10", "SVK_total_err_fh_10",
                            "SWE_total_err_fh_10", "SWI_total_err_fh_10", "UK_total_err_fh_10",  "USA_total_err_fh_10")


country_smooth_female_err_fh_10 = c("AUS_smooth_female_err_fh_10", "AUT_smooth_female_err_fh_10", "BEL_smooth_female_err_fh_10", "BGR_smooth_female_err_fh_10",
                                    "CAN_smooth_female_err_fh_10", "CZE_smooth_female_err_fh_10", "DEN_smooth_female_err_fh_10", "FIN_smooth_female_err_fh_10",
                                    "FRA_smooth_female_err_fh_10", "HUN_smooth_female_err_fh_10", "ICE_smooth_female_err_fh_10", "IRL_smooth_female_err_fh_10",
                                    "ITA_smooth_female_err_fh_10", "JPN_smooth_female_err_fh_10", "NLD_smooth_female_err_fh_10", "NOR_smooth_female_err_fh_10",
                                    "NZ_smooth_female_err_fh_10",  "PRT_smooth_female_err_fh_10", "SPA_smooth_female_err_fh_10", "SVK_smooth_female_err_fh_10",
                                    "SWE_smooth_female_err_fh_10", "SWI_smooth_female_err_fh_10", "UK_smooth_female_err_fh_10",  "USA_smooth_female_err_fh_10")

country_smooth_male_err_fh_10 = c("AUS_smooth_male_err_fh_10", "AUT_smooth_male_err_fh_10", "BEL_smooth_male_err_fh_10", "BGR_smooth_male_err_fh_10",
                                  "CAN_smooth_male_err_fh_10", "CZE_smooth_male_err_fh_10", "DEN_smooth_male_err_fh_10", "FIN_smooth_male_err_fh_10",
                                  "FRA_smooth_male_err_fh_10", "HUN_smooth_male_err_fh_10", "ICE_smooth_male_err_fh_10", "IRL_smooth_male_err_fh_10",
                                  "ITA_smooth_male_err_fh_10", "JPN_smooth_male_err_fh_10", "NLD_smooth_male_err_fh_10", "NOR_smooth_male_err_fh_10",
                                  "NZ_smooth_male_err_fh_10",  "PRT_smooth_male_err_fh_10", "SPA_smooth_male_err_fh_10", "SVK_smooth_male_err_fh_10",
                                  "SWE_smooth_male_err_fh_10", "SWI_smooth_male_err_fh_10", "UK_smooth_male_err_fh_10",  "USA_smooth_male_err_fh_10")

country_smooth_total_err_fh_10 = c("AUS_smooth_total_err_fh_10", "AUT_smooth_total_err_fh_10", "BEL_smooth_total_err_fh_10", "BGR_smooth_total_err_fh_10",
                                   "CAN_smooth_total_err_fh_10", "CZE_smooth_total_err_fh_10", "DEN_smooth_total_err_fh_10", "FIN_smooth_total_err_fh_10",
                                   "FRA_smooth_total_err_fh_10", "HUN_smooth_total_err_fh_10", "ICE_smooth_total_err_fh_10", "IRL_smooth_total_err_fh_10",
                                   "ITA_smooth_total_err_fh_10", "JPN_smooth_total_err_fh_10", "NLD_smooth_total_err_fh_10", "NOR_smooth_total_err_fh_10",
                                   "NZ_smooth_total_err_fh_10",  "PRT_smooth_total_err_fh_10", "SPA_smooth_total_err_fh_10", "SVK_smooth_total_err_fh_10",
                                   "SWE_smooth_total_err_fh_10", "SWI_smooth_total_err_fh_10", "UK_smooth_total_err_fh_10",  "USA_smooth_total_err_fh_10")



country_female_err_no_center_fh_10 = c("AUS_female_err_no_center_fh_10", "AUT_female_err_no_center_fh_10", "BEL_female_err_no_center_fh_10", "BGR_female_err_no_center_fh_10",
                                       "CAN_female_err_no_center_fh_10", "CZE_female_err_no_center_fh_10", "DEN_female_err_no_center_fh_10", "FIN_female_err_no_center_fh_10",
                                       "FRA_female_err_no_center_fh_10", "HUN_female_err_no_center_fh_10", "ICE_female_err_no_center_fh_10", "IRL_female_err_no_center_fh_10",
                                       "ITA_female_err_no_center_fh_10", "JPN_female_err_no_center_fh_10", "NLD_female_err_no_center_fh_10", "NOR_female_err_no_center_fh_10",
                                       "NZ_female_err_no_center_fh_10",  "PRT_female_err_no_center_fh_10", "SPA_female_err_no_center_fh_10", "SVK_female_err_no_center_fh_10",
                                       "SWE_female_err_no_center_fh_10", "SWI_female_err_no_center_fh_10", "UK_female_err_no_center_fh_10",  "USA_female_err_no_center_fh_10")

country_male_err_no_center_fh_10 = c("AUS_male_err_no_center_fh_10", "AUT_male_err_no_center_fh_10", "BEL_male_err_no_center_fh_10", "BGR_male_err_no_center_fh_10",
                                     "CAN_male_err_no_center_fh_10", "CZE_male_err_no_center_fh_10", "DEN_male_err_no_center_fh_10", "FIN_male_err_no_center_fh_10",
                                     "FRA_male_err_no_center_fh_10", "HUN_male_err_no_center_fh_10", "ICE_male_err_no_center_fh_10", "IRL_male_err_no_center_fh_10",
                                     "ITA_male_err_no_center_fh_10", "JPN_male_err_no_center_fh_10", "NLD_male_err_no_center_fh_10", "NOR_male_err_no_center_fh_10",
                                     "NZ_male_err_no_center_fh_10",  "PRT_male_err_no_center_fh_10", "SPA_male_err_no_center_fh_10", "SVK_male_err_no_center_fh_10",
                                     "SWE_male_err_no_center_fh_10", "SWI_male_err_no_center_fh_10", "UK_male_err_no_center_fh_10",  "USA_male_err_no_center_fh_10")

country_total_err_no_center_fh_10 = c("AUS_total_err_no_center_fh_10", "AUT_total_err_no_center_fh_10", "BEL_total_err_no_center_fh_10", "BGR_total_err_no_center_fh_10",
                                      "CAN_total_err_no_center_fh_10", "CZE_total_err_no_center_fh_10", "DEN_total_err_no_center_fh_10", "FIN_total_err_no_center_fh_10",
                                      "FRA_total_err_no_center_fh_10", "HUN_total_err_no_center_fh_10", "ICE_total_err_no_center_fh_10", "IRL_total_err_no_center_fh_10",
                                      "ITA_total_err_no_center_fh_10", "JPN_total_err_no_center_fh_10", "NLD_total_err_no_center_fh_10", "NOR_total_err_no_center_fh_10",
                                      "NZ_total_err_no_center_fh_10",  "PRT_total_err_no_center_fh_10", "SPA_total_err_no_center_fh_10", "SVK_total_err_no_center_fh_10",
                                      "SWE_total_err_no_center_fh_10", "SWI_total_err_no_center_fh_10", "UK_total_err_no_center_fh_10",  "USA_total_err_no_center_fh_10")


country_smooth_female_no_center_err_fh_10 = c("AUS_smooth_female_no_center_err_fh_10", "AUT_smooth_female_no_center_err_fh_10", "BEL_smooth_female_no_center_err_fh_10", "BGR_smooth_female_no_center_err_fh_10",
                                              "CAN_smooth_female_no_center_err_fh_10", "CZE_smooth_female_no_center_err_fh_10", "DEN_smooth_female_no_center_err_fh_10", "FIN_smooth_female_no_center_err_fh_10",
                                              "FRA_smooth_female_no_center_err_fh_10", "HUN_smooth_female_no_center_err_fh_10", "ICE_smooth_female_no_center_err_fh_10", "IRL_smooth_female_no_center_err_fh_10",
                                              "ITA_smooth_female_no_center_err_fh_10", "JPN_smooth_female_no_center_err_fh_10", "NLD_smooth_female_no_center_err_fh_10", "NOR_smooth_female_no_center_err_fh_10",
                                              "NZ_smooth_female_no_center_err_fh_10",  "PRT_smooth_female_no_center_err_fh_10", "SPA_smooth_female_no_center_err_fh_10", "SVK_smooth_female_no_center_err_fh_10",
                                              "SWE_smooth_female_no_center_err_fh_10", "SWI_smooth_female_no_center_err_fh_10", "UK_smooth_female_no_center_err_fh_10",  "USA_smooth_female_no_center_err_fh_10")

country_smooth_male_no_center_err_fh_10 = c("AUS_smooth_male_no_center_err_fh_10", "AUT_smooth_male_no_center_err_fh_10", "BEL_smooth_male_no_center_err_fh_10", "BGR_smooth_male_no_center_err_fh_10",
                                            "CAN_smooth_male_no_center_err_fh_10", "CZE_smooth_male_no_center_err_fh_10", "DEN_smooth_male_no_center_err_fh_10", "FIN_smooth_male_no_center_err_fh_10",
                                            "FRA_smooth_male_no_center_err_fh_10", "HUN_smooth_male_no_center_err_fh_10", "ICE_smooth_male_no_center_err_fh_10", "IRL_smooth_male_no_center_err_fh_10",
                                            "ITA_smooth_male_no_center_err_fh_10", "JPN_smooth_male_no_center_err_fh_10", "NLD_smooth_male_no_center_err_fh_10", "NOR_smooth_male_no_center_err_fh_10",
                                            "NZ_smooth_male_no_center_err_fh_10",  "PRT_smooth_male_no_center_err_fh_10", "SPA_smooth_male_no_center_err_fh_10", "SVK_smooth_male_no_center_err_fh_10",
                                            "SWE_smooth_male_no_center_err_fh_10", "SWI_smooth_male_no_center_err_fh_10", "UK_smooth_male_no_center_err_fh_10",  "USA_smooth_male_no_center_err_fh_10")

country_smooth_total_no_center_err_fh_10 = c("AUS_smooth_total_no_center_err_fh_10", "AUT_smooth_total_no_center_err_fh_10", "BEL_smooth_total_no_center_err_fh_10", "BGR_smooth_total_no_center_err_fh_10",
                                             "CAN_smooth_total_no_center_err_fh_10", "CZE_smooth_total_no_center_err_fh_10", "DEN_smooth_total_no_center_err_fh_10", "FIN_smooth_total_no_center_err_fh_10",
                                             "FRA_smooth_total_no_center_err_fh_10", "HUN_smooth_total_no_center_err_fh_10", "ICE_smooth_total_no_center_err_fh_10", "IRL_smooth_total_no_center_err_fh_10",
                                             "ITA_smooth_total_no_center_err_fh_10", "JPN_smooth_total_no_center_err_fh_10", "NLD_smooth_total_no_center_err_fh_10", "NOR_smooth_total_no_center_err_fh_10",
                                             "NZ_smooth_total_no_center_err_fh_10",  "PRT_smooth_total_no_center_err_fh_10", "SPA_smooth_total_no_center_err_fh_10", "SVK_smooth_total_no_center_err_fh_10",
                                             "SWE_smooth_total_no_center_err_fh_10", "SWI_smooth_total_no_center_err_fh_10", "UK_smooth_total_no_center_err_fh_10",  "USA_smooth_total_no_center_err_fh_10")

# with centering

country_total_err_list = country_male_err_list = country_female_err_list = 
country_smooth_total_err_list = country_smooth_male_err_list = country_smooth_female_err_list = array(NA, c(2, 2, length(country)))
for(i in 1:length(country))
{
    country_total_err_list[,,i]  = get(country_total_err[i])
    country_male_err_list[,,i]   = get(country_male_err[i])
    country_female_err_list[,,i] = get(country_female_err[i])

    country_smooth_total_err_list[,,i]  = get(country_smooth_total_err[i])
    country_smooth_male_err_list[,,i]   = get(country_smooth_male_err[i])
    country_smooth_female_err_list[,,i] = get(country_smooth_female_err[i])
}

# without centering

country_total_err_no_center_list = country_male_err_no_center_list = country_female_err_no_center_list = 
country_smooth_total_err_no_center_list = country_smooth_male_err_no_center_list = country_smooth_female_err_no_center_list = array(NA, c(2, 2, length(country)))
for(i in 1:length(country))
{
    country_total_err_no_center_list[,,i]  = get(country_total_err_no_center[i])
    country_male_err_no_center_list[,,i]   = get(country_male_err_no_center[i])
    country_female_err_no_center_list[,,i] = get(country_female_err_no_center[i])
    
    country_smooth_total_err_no_center_list[,,i]  = get(country_smooth_total_err_no_center[i])
    country_smooth_male_err_no_center_list[,,i]   = get(country_smooth_male_err_no_center[i])
    country_smooth_female_err_no_center_list[,,i] = get(country_smooth_female_err_no_center[i])
}


##############
# error x 100
##############

# mean

round(apply(country_total_err_list * 100, c(1,2), mean), 4)
round(apply(country_male_err_list * 100, c(1,2), mean), 4)
round(apply(country_female_err_list * 100, c(1,2), mean), 4)

round(apply(country_smooth_total_err_list * 100, c(1,2), mean), 4)
round(apply(country_smooth_male_err_list * 100, c(1,2), mean), 4)
round(apply(country_smooth_female_err_list * 100, c(1,2), mean), 4)

round(apply(country_total_err_no_center_list * 100, c(1,2), mean), 4)
round(apply(country_male_err_no_center_list * 100, c(1,2), mean), 4)
round(apply(country_female_err_no_center_list * 100, c(1,2), mean), 4)

round(apply(country_smooth_total_err_no_center_list * 100, c(1,2), mean), 4)
round(apply(country_smooth_male_err_no_center_list * 100, c(1,2), mean), 4)
round(apply(country_smooth_female_err_no_center_list * 100, c(1,2), mean), 4)


######
# FDM
######

# fh = 1 (center)

country_female_mat_smooth_err = country_male_mat_smooth_err = country_total_mat_smooth_err = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err[(2*i-1):(2*i),] = get(country_smooth_female_err[i])
    country_male_mat_smooth_err[(2*i-1):(2*i),] = get(country_smooth_male_err[i])
    country_total_mat_smooth_err[(2*i-1):(2*i),] = get(country_smooth_total_err[i])
    print(i)
}

country_smooth_MAFE = cbind(country_female_mat_smooth_err[seq(1,48,by=2),1], country_female_mat_smooth_err[seq(2,48,by=2),1],
                            country_male_mat_smooth_err[seq(1,48,by=2),1],   country_male_mat_smooth_err[seq(2,48,by=2),1],
                            country_total_mat_smooth_err[seq(1,48,by=2),1],  country_total_mat_smooth_err[seq(2,48,by=2),1])

country_smooth_RMSFE = cbind(country_female_mat_smooth_err[seq(1,48,by=2),2], country_female_mat_smooth_err[seq(2,48,by=2),2],
                             country_male_mat_smooth_err[seq(1,48,by=2),2],   country_male_mat_smooth_err[seq(2,48,by=2),2],
                             country_total_mat_smooth_err[seq(1,48,by=2),2],  country_total_mat_smooth_err[seq(2,48,by=2),2])
colnames(country_smooth_RMSFE) = colnames(country_smooth_MAFE) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_smooth_RMSFE) = rownames(country_smooth_MAFE) = country

round(apply(country_smooth_RMSFE, 2, mean), 4)  # 0.0134 0.0134 0.0249 0.0257 0.0123 0.0136
round(apply(country_smooth_MAFE, 2, median), 4) # 0.0029 0.0030 0.0057 0.0062 0.0028 0.0032 


# fh = 1 (no_center)

country_female_mat_smooth_err_no_center = country_male_mat_smooth_err_no_center = country_total_mat_smooth_err_no_center = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err_no_center[(2*i-1):(2*i),] = get(country_smooth_female_err_no_center[i])
    country_male_mat_smooth_err_no_center[(2*i-1):(2*i),] = get(country_smooth_male_err_no_center[i])
    country_total_mat_smooth_err_no_center[(2*i-1):(2*i),] = get(country_smooth_total_err_no_center[i])
    print(i)
}

country_smooth_MAFE_no_center = cbind(country_female_mat_smooth_err_no_center[seq(1,48,by=2),1], country_female_mat_smooth_err_no_center[seq(2,48,by=2),1],
                                      country_male_mat_smooth_err_no_center[seq(1,48,by=2),1],   country_male_mat_smooth_err_no_center[seq(2,48,by=2),1],
                                      country_total_mat_smooth_err_no_center[seq(1,48,by=2),1],  country_total_mat_smooth_err_no_center[seq(2,48,by=2),1])

country_smooth_RMSFE_no_center = cbind(country_female_mat_smooth_err_no_center[seq(1,48,by=2),2], country_female_mat_smooth_err_no_center[seq(2,48,by=2),2],
                                       country_male_mat_smooth_err_no_center[seq(1,48,by=2),2],   country_male_mat_smooth_err_no_center[seq(2,48,by=2),2],
                                       country_total_mat_smooth_err_no_center[seq(1,48,by=2),2],  country_total_mat_smooth_err_no_center[seq(2,48,by=2),2])
colnames(country_smooth_RMSFE_no_center) = colnames(country_smooth_MAFE_no_center) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_smooth_RMSFE_no_center) = rownames(country_smooth_MAFE_no_center) = country

round(apply(country_smooth_RMSFE_no_center, 2, mean), 4)  # 0.0133 0.0133 0.0249 0.0255 0.0122 0.0133
round(apply(country_smooth_MAFE_no_center, 2, median), 4) # 0.0029 0.0029 0.0058 0.0061 0.0029 0.0032 


# fh = 5 (center)

country_female_mat_smooth_err_fh_5 = country_male_mat_smooth_err_fh_5 = 
country_total_mat_smooth_err_fh_5 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err_fh_5[(2*i-1):(2*i),] = get(country_smooth_female_err_fh_5[i])
    country_male_mat_smooth_err_fh_5[(2*i-1):(2*i),]   = get(country_smooth_male_err_fh_5[i])
    country_total_mat_smooth_err_fh_5[(2*i-1):(2*i),]  = get(country_smooth_total_err_fh_5[i])
    print(i)
}

country_smooth_MAFE_fh_5 = cbind(country_female_mat_smooth_err_fh_5[seq(1,48,by=2),1], country_female_mat_smooth_err_fh_5[seq(2,48,by=2),1],
                                 country_male_mat_smooth_err_fh_5[seq(1,48,by=2),1],   country_male_mat_smooth_err_fh_5[seq(2,48,by=2),1],
                                 country_total_mat_smooth_err_fh_5[seq(1,48,by=2),1],  country_total_mat_smooth_err_fh_5[seq(2,48,by=2),1])

country_smooth_RMSFE_fh_5 = cbind(country_female_mat_smooth_err_fh_5[seq(1,48,by=2),2], country_female_mat_smooth_err_fh_5[seq(2,48,by=2),2],
                                  country_male_mat_smooth_err_fh_5[seq(1,48,by=2),2],   country_male_mat_smooth_err_fh_5[seq(2,48,by=2),2],
                                  country_total_mat_smooth_err_fh_5[seq(1,48,by=2),2],  country_total_mat_smooth_err_fh_5[seq(2,48,by=2),2])
colnames(country_smooth_RMSFE_fh_5) = colnames(country_smooth_MAFE_fh_5) = c("DPCA (F)", "PCA (F)", "DPCA (M)", "PCA (M)", "DPCA (T)", "PCA (T)")
rownames(country_smooth_RMSFE_fh_5) = rownames(country_smooth_MAFE_fh_5) = country

round(apply(country_smooth_RMSFE_fh_5, 2, mean), 4)  # 0.0141 0.0141 0.0257 0.0261 0.0131 0.0134 
round(apply(country_smooth_MAFE_fh_5, 2, median), 4) # 0.0038 0.0037 0.0067 0.0068 0.0039 0.0038  

# fh = 5 (non_center)

country_female_mat_smooth_err_no_center_fh_5 = country_male_mat_smooth_err_no_center_fh_5 = 
country_total_mat_smooth_err_no_center_fh_5 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err_no_center_fh_5[(2*i-1):(2*i),] = get(country_smooth_female_err_no_center_fh_5[i])
    country_male_mat_smooth_err_no_center_fh_5[(2*i-1):(2*i),]   = get(country_smooth_male_no_center_err_fh_5[i])
    country_total_mat_smooth_err_no_center_fh_5[(2*i-1):(2*i),]  = get(country_smooth_total_no_center_err_fh_5[i])
    print(i)
}

country_smooth_MAFE_no_center_fh_5 = cbind(country_female_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),1], country_female_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),1],
                                           country_male_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),1],   country_male_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),1],
                                           country_total_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),1],  country_total_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),1])

country_smooth_RMSFE_no_center_fh_5 = cbind(country_female_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),2], country_female_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),2],
                                            country_male_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),2],   country_male_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),2],
                                            country_total_mat_smooth_err_no_center_fh_5[seq(1,48,by=2),2],  country_total_mat_smooth_err_no_center_fh_5[seq(2,48,by=2),2])
colnames(country_smooth_RMSFE_no_center_fh_5) = colnames(country_smooth_MAFE_no_center_fh_5) = c("DPCA (F)", "PCA (F)", "DPCA (M)", "PCA (M)", "DPCA (T)", "PCA (T)")
rownames(country_smooth_RMSFE_no_center_fh_5) = rownames(country_smooth_MAFE_no_center_fh_5) = country

round(apply(country_smooth_RMSFE_no_center_fh_5, 2, mean), 4)  # 0.0139 0.0140 0.0256 0.0260 0.0130 0.0133 
round(apply(country_smooth_MAFE_no_center_fh_5, 2, median), 4) # 0.0037 0.0037 0.0067 0.0068 0.0038 0.0038  

###################
# fh = 10 (center)
###################

country_female_mat_smooth_err_fh_10 = country_male_mat_smooth_err_fh_10 = 
country_total_mat_smooth_err_fh_10 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err_fh_10[(2*i-1):(2*i),] = get(country_smooth_female_err_fh_10[i])
    country_male_mat_smooth_err_fh_10[(2*i-1):(2*i),]   = get(country_smooth_male_err_fh_10[i])
    country_total_mat_smooth_err_fh_10[(2*i-1):(2*i),]  = get(country_smooth_total_err_fh_10[i])
    print(i)
}

country_smooth_MAFE_fh_10 = cbind(country_female_mat_smooth_err_fh_10[seq(1,48,by=2),1], country_female_mat_smooth_err_fh_10[seq(2,48,by=2),1],
                                  country_male_mat_smooth_err_fh_10[seq(1,48,by=2),1],   country_male_mat_smooth_err_fh_10[seq(2,48,by=2),1],
                                  country_total_mat_smooth_err_fh_10[seq(1,48,by=2),1],  country_total_mat_smooth_err_fh_10[seq(2,48,by=2),1])

country_smooth_RMSFE_fh_10 = cbind(country_female_mat_smooth_err_fh_10[seq(1,48,by=2),2], country_female_mat_smooth_err_fh_10[seq(2,48,by=2),2],
                                   country_male_mat_smooth_err_fh_10[seq(1,48,by=2),2],   country_male_mat_smooth_err_fh_10[seq(2,48,by=2),2],
                                   country_total_mat_smooth_err_fh_10[seq(1,48,by=2),2],  country_total_mat_smooth_err_fh_10[seq(2,48,by=2),2])
colnames(country_smooth_RMSFE_fh_10) = colnames(country_smooth_MAFE_fh_10) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_smooth_RMSFE_fh_10) = rownames(country_smooth_MAFE_fh_10) = country

round(apply(country_smooth_RMSFE_fh_10, 2, mean), 4)  # 0.0166 0.0165 0.0282 0.0281 0.0161 0.0164
round(apply(country_smooth_MAFE_fh_10, 2, median), 4) # 0.0053 0.0052 0.0089 0.0090 0.0056 0.0057

#######################
# fh = 10 (non-center)
#######################

country_female_mat_smooth_err_no_center_fh_10 = country_male_mat_smooth_err_no_center_fh_10 = 
country_total_mat_smooth_err_no_center_fh_10 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_smooth_err_no_center_fh_10[(2*i-1):(2*i),] = get(country_smooth_female_no_center_err_fh_10[i])
    country_male_mat_smooth_err_no_center_fh_10[(2*i-1):(2*i),]   = get(country_smooth_male_no_center_err_fh_10[i])
    country_total_mat_smooth_err_no_center_fh_10[(2*i-1):(2*i),]  = get(country_smooth_total_no_center_err_fh_10[i])
    print(i)
}

country_smooth_MAFE_no_center_fh_10 = cbind(country_female_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),1], country_female_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),1],
                                  country_male_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),1],   country_male_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),1],
                                  country_total_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),1],  country_total_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),1])

country_smooth_RMSFE_no_center_fh_10 = cbind(country_female_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),2], country_female_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),2],
                                   country_male_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),2],   country_male_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),2],
                                   country_total_mat_smooth_err_no_center_fh_10[seq(1,48,by=2),2],  country_total_mat_smooth_err_no_center_fh_10[seq(2,48,by=2),2])

colnames(country_smooth_RMSFE_no_center_fh_10) = colnames(country_smooth_MAFE_no_center_fh_10) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_smooth_RMSFE_no_center_fh_10) = rownames(country_smooth_MAFE_no_center_fh_10) = country

round(apply(country_smooth_RMSFE_no_center_fh_10, 2, mean), 4)  # 0.0163 0.0165 0.0281 0.0283 0.0159 0.0163
round(apply(country_smooth_MAFE_no_center_fh_10, 2, median), 4) # 0.0052 0.0052 0.0089 0.0089 0.0056 0.0057

####################
# Lee-Carter method
####################

##################
# fh = 1 (center)
##################

country_female_mat_err = country_male_mat_err = country_total_mat_err = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err[(2*i-1):(2*i),] = get(country_female_err[i]) 
    country_male_mat_err[(2*i-1):(2*i),]   = get(country_male_err[i]) 
    country_total_mat_err[(2*i-1):(2*i),]  = get(country_total_err[i]) 
    print(i)
}

country_MAFE = cbind(country_female_mat_err[seq(1,48,by=2),1], country_female_mat_err[seq(2,48,by=2),1],
                     country_male_mat_err[seq(1,48,by=2),1],   country_male_mat_err[seq(2,48,by=2),1],
                     country_total_mat_err[seq(1,48,by=2),1],  country_total_mat_err[seq(2,48,by=2),1])
  
country_RMSFE = cbind(country_female_mat_err[seq(1,48,by=2),2], country_female_mat_err[seq(2,48,by=2),2],
                      country_male_mat_err[seq(1,48,by=2),2],   country_male_mat_err[seq(2,48,by=2),2],
                      country_total_mat_err[seq(1,48,by=2),2],  country_total_mat_err[seq(2,48,by=2),2])
colnames(country_RMSFE) = colnames(country_MAFE) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_RMSFE) = rownames(country_MAFE) = country

round(apply(country_RMSFE, 2, mean), 4)  # 0.0137 0.0148 0.0253 0.0266 0.0125 0.0133
round(apply(country_MAFE, 2, median), 4) # 0.0030 0.0033 0.0058 0.0060 0.0029 0.0030

######################
# fh = 1 (non-center)
######################

country_female_mat_err_no_center = country_male_mat_err_no_center = country_total_mat_err_no_center = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err_no_center[(2*i-1):(2*i),] = get(country_female_err_no_center[i]) 
    country_male_mat_err_no_center[(2*i-1):(2*i),]   = get(country_male_err_no_center[i]) 
    country_total_mat_err_no_center[(2*i-1):(2*i),]  = get(country_total_err_no_center[i]) 
    print(i)
}

country_MAFE_no_center = cbind(country_female_mat_err_no_center[seq(1,48,by=2),1], country_female_mat_err_no_center[seq(2,48,by=2),1],
                               country_male_mat_err_no_center[seq(1,48,by=2),1],   country_male_mat_err_no_center[seq(2,48,by=2),1],
                               country_total_mat_err_no_center[seq(1,48,by=2),1],  country_total_mat_err_no_center[seq(2,48,by=2),1])

country_RMSFE_no_center = cbind(country_female_mat_err_no_center[seq(1,48,by=2),2], country_female_mat_err_no_center[seq(2,48,by=2),2],
                                country_male_mat_err_no_center[seq(1,48,by=2),2],   country_male_mat_err_no_center[seq(2,48,by=2),2],
                                country_total_mat_err_no_center[seq(1,48,by=2),2],  country_total_mat_err_no_center[seq(2,48,by=2),2])
colnames(country_MAFE_no_center) = colnames(country_RMSFE_no_center) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_MAFE_no_center) = rownames(country_RMSFE_no_center) = country

round(apply(country_RMSFE_no_center, 2, mean), 4)   # 0.0137 0.0146 0.0255 0.0264 0.0125 0.0131 
round(apply(country_MAFE_no_center, 2, median), 4)  # 0.0030 0.0034 0.0059 0.0060 0.0029 0.0030


##################
# fh = 5 (center)
##################

country_female_mat_err_fh_5 = country_male_mat_err_fh_5 = country_total_mat_err_fh_5 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err_fh_5[(2*i-1):(2*i),] = get(country_female_err_fh_5[i]) 
    country_male_mat_err_fh_5[(2*i-1):(2*i),]   = get(country_male_err_fh_5[i]) 
    country_total_mat_err_fh_5[(2*i-1):(2*i),]  = get(country_total_err_fh_5[i]) 
    print(i)
}

country_MAFE_fh_5 = cbind(country_female_mat_err_fh_5[seq(1,48,by=2),1], country_female_mat_err_fh_5[seq(2,48,by=2),1],
                          country_male_mat_err_fh_5[seq(1,48,by=2),1],   country_male_mat_err_fh_5[seq(2,48,by=2),1],
                          country_total_mat_err_fh_5[seq(1,48,by=2),1],  country_total_mat_err_fh_5[seq(2,48,by=2),1])

country_RMSFE_fh_5 = cbind(country_female_mat_err_fh_5[seq(1,48,by=2),2], country_female_mat_err_fh_5[seq(2,48,by=2),2],
                           country_male_mat_err_fh_5[seq(1,48,by=2),2],   country_male_mat_err_fh_5[seq(2,48,by=2),2],
                           country_total_mat_err_fh_5[seq(1,48,by=2),2],  country_total_mat_err_fh_5[seq(2,48,by=2),2])
colnames(country_RMSFE_fh_5) = colnames(country_MAFE_fh_5) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_RMSFE_fh_5) = rownames(country_MAFE_fh_5) = country

round(apply(country_RMSFE_fh_5, 2, mean), 4)  # 0.0144 0.0143 0.0262 0.0263 0.0133 0.0134
round(apply(country_MAFE_fh_5, 2, median), 4) # 0.0037 0.0038 0.0067 0.0068 0.0038 0.0039 

#####################
# fh = 5 (no center)
#####################

country_female_mat_err_no_center_fh_5 = country_male_mat_err_no_center_fh_5 = country_total_mat_err_no_center_fh_5 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err_no_center_fh_5[(2*i-1):(2*i),] = get(country_female_err_no_center_fh_5[i]) 
    country_male_mat_err_no_center_fh_5[(2*i-1):(2*i),]   = get(country_male_err_no_center_fh_5[i]) 
    country_total_mat_err_no_center_fh_5[(2*i-1):(2*i),]  = get(country_total_err_no_center_fh_5[i]) 
    print(i)
}

country_MAFE_no_center_fh_5 = cbind(country_female_mat_err_no_center_fh_5[seq(1,48,by=2),1], country_female_mat_err_no_center_fh_5[seq(2,48,by=2),1],
                                    country_male_mat_err_no_center_fh_5[seq(1,48,by=2),1],   country_male_mat_err_no_center_fh_5[seq(2,48,by=2),1],
                                    country_total_mat_err_no_center_fh_5[seq(1,48,by=2),1],  country_total_mat_err_no_center_fh_5[seq(2,48,by=2),1])

country_RMSFE_no_center_fh_5 = cbind(country_female_mat_err_no_center_fh_5[seq(1,48,by=2),2], country_female_mat_err_no_center_fh_5[seq(2,48,by=2),2],
                                     country_male_mat_err_no_center_fh_5[seq(1,48,by=2),2],   country_male_mat_err_no_center_fh_5[seq(2,48,by=2),2],
                                     country_total_mat_err_no_center_fh_5[seq(1,48,by=2),2],  country_total_mat_err_no_center_fh_5[seq(2,48,by=2),2])
colnames(country_RMSFE_no_center_fh_5) = colnames(country_MAFE_no_center_fh_5) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_RMSFE_no_center_fh_5) = rownames(country_MAFE_no_center_fh_5) = country

round(apply(country_RMSFE_no_center_fh_5, 2, mean), 4)  # 0.0146 0.0141 0.0265 0.0264 0.0134 0.0133
round(apply(country_MAFE_no_center_fh_5, 2, median), 4) # 0.0039 0.0039 0.0069 0.0069 0.0040 0.0040


###################
# fh = 10 (center)
###################

country_female_mat_err_fh_10 = country_male_mat_err_fh_10 = country_total_mat_err_fh_10 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err_fh_10[(2*i-1):(2*i),] = get(country_female_err_fh_10[i]) 
    country_male_mat_err_fh_10[(2*i-1):(2*i),]   = get(country_male_err_fh_10[i]) 
    country_total_mat_err_fh_10[(2*i-1):(2*i),]  = get(country_total_err_fh_10[i]) 
    print(i)
}

country_MAFE_fh_10 = cbind(country_female_mat_err_fh_10[seq(1,48,by=2),1], country_female_mat_err_fh_10[seq(2,48,by=2),1],
                          country_male_mat_err_fh_10[seq(1,48,by=2),1],   country_male_mat_err_fh_10[seq(2,48,by=2),1],
                          country_total_mat_err_fh_10[seq(1,48,by=2),1],  country_total_mat_err_fh_10[seq(2,48,by=2),1])

country_RMSFE_fh_10 = cbind(country_female_mat_err_fh_10[seq(1,48,by=2),2], country_female_mat_err_fh_10[seq(2,48,by=2),2],
                           country_male_mat_err_fh_10[seq(1,48,by=2),2],   country_male_mat_err_fh_10[seq(2,48,by=2),2],
                           country_total_mat_err_fh_10[seq(1,48,by=2),2],  country_total_mat_err_fh_10[seq(2,48,by=2),2])
colnames(country_RMSFE_fh_10) = colnames(country_MAFE_fh_10) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_RMSFE_fh_10) = rownames(country_MAFE_fh_10) = country

round(apply(country_RMSFE_fh_10, 2, mean), 4)  # 0.0170 0.0170 0.0284 0.0286 0.0163 0.0164
round(apply(country_MAFE_fh_10, 2, median), 4) # 0.0054 0.0053 0.0090 0.0090 0.0056 0.0056


#####################
# fh = 10 (no center)
#####################

country_female_mat_err_no_center_fh_10 = country_male_mat_err_no_center_fh_10 = country_total_mat_err_no_center_fh_10 = matrix(NA, 48, 2)
for(i in 1:length(country))
{
    country_female_mat_err_no_center_fh_10[(2*i-1):(2*i),] = get(country_female_err_no_center_fh_10[i]) 
    country_male_mat_err_no_center_fh_10[(2*i-1):(2*i),]   = get(country_male_err_no_center_fh_10[i]) 
    country_total_mat_err_no_center_fh_10[(2*i-1):(2*i),]  = get(country_total_err_no_center_fh_10[i]) 
    print(i)
}

country_MAFE_no_center_fh_10 = cbind(country_female_mat_err_no_center_fh_10[seq(1,48,by=2),1], country_female_mat_err_no_center_fh_10[seq(2,48,by=2),1],
                                     country_male_mat_err_no_center_fh_10[seq(1,48,by=2),1],   country_male_mat_err_no_center_fh_10[seq(2,48,by=2),1],
                                     country_total_mat_err_no_center_fh_10[seq(1,48,by=2),1],  country_total_mat_err_no_center_fh_10[seq(2,48,by=2),1])

country_RMSFE_no_center_fh_10 = cbind(country_female_mat_err_no_center_fh_10[seq(1,48,by=2),2], country_female_mat_err_no_center_fh_10[seq(2,48,by=2),2],
                                      country_male_mat_err_no_center_fh_10[seq(1,48,by=2),2],   country_male_mat_err_no_center_fh_10[seq(2,48,by=2),2],
                                      country_total_mat_err_no_center_fh_10[seq(1,48,by=2),2],  country_total_mat_err_no_center_fh_10[seq(2,48,by=2),2])
colnames(country_RMSFE_no_center_fh_10) = colnames(country_MAFE_no_center_fh_10) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
rownames(country_RMSFE_no_center_fh_10) = rownames(country_MAFE_no_center_fh_10) = country

round(apply(country_RMSFE_no_center_fh_10, 2, mean), 4)  # 0.0173 0.0168 0.0288 0.0289 0.0165 0.0162
round(apply(country_MAFE_no_center_fh_10, 2, median), 4) # 0.0056 0.0053 0.0091 0.0091 0.0059 0.0056


#####################
## importing outputs
## centering
#####################

# Lee-Carter model

require(xtable)
xtable(cbind(rbind(country_MAFE, colMeans(country_MAFE), apply(country_MAFE, 2, median)), 
             rbind(country_RMSFE, colMeans(country_RMSFE), apply(country_RMSFE, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_MAFE_fh_5, colMeans(country_MAFE_fh_5), apply(country_MAFE_fh_5, 2, median)), 
             rbind(country_RMSFE_fh_5, colMeans(country_RMSFE_fh_5), apply(country_RMSFE_fh_5, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_MAFE_fh_10, colMeans(country_MAFE_fh_10), apply(country_MAFE_fh_10, 2, median)), 
             rbind(country_RMSFE_fh_10, colMeans(country_RMSFE_fh_10), apply(country_RMSFE_fh_10, 2, median))) * 100, digits = 2)


xtable(cbind(rbind(country_MAFE_no_center, colMeans(country_MAFE_no_center), apply(country_MAFE_no_center, 2, median)), 
             rbind(country_RMSFE_no_center, colMeans(country_RMSFE_no_center), apply(country_RMSFE_no_center, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_MAFE_no_center_fh_5, colMeans(country_MAFE_no_center_fh_5), apply(country_MAFE_no_center_fh_5, 2, median)), 
             rbind(country_RMSFE_no_center_fh_5, colMeans(country_RMSFE_no_center_fh_5), apply(country_RMSFE_no_center_fh_5, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_MAFE_no_center_fh_10, colMeans(country_MAFE_no_center_fh_10), apply(country_MAFE_no_center_fh_10, 2, median)), 
             rbind(country_RMSFE_no_center_fh_10, colMeans(country_RMSFE_no_center_fh_10), apply(country_RMSFE_no_center_fh_10, 2, median))) * 100, digits = 2)




# FDM

xtable(cbind(rbind(country_smooth_MAFE, colMeans(country_smooth_MAFE), apply(country_smooth_MAFE, 2, median)),
             rbind(country_smooth_RMSFE, colMeans(country_smooth_RMSFE), apply(country_smooth_RMSFE, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_smooth_MAFE_fh_5, colMeans(country_smooth_MAFE_fh_5), apply(country_smooth_MAFE_fh_5, 2, median)),
             rbind(country_smooth_RMSFE_fh_5, colMeans(country_smooth_RMSFE_fh_5), apply(country_smooth_RMSFE_fh_5, 2, median))) * 100, digits = 2)

xtable(cbind(rbind(country_smooth_MAFE_fh_10, colMeans(country_smooth_MAFE_fh_10), apply(country_smooth_MAFE_fh_10, 2, median)),
             rbind(country_smooth_RMSFE_fh_10, colMeans(country_smooth_RMSFE_fh_10), apply(country_smooth_RMSFE_fh_10, 2, median))) * 100, digits = 2)

#####################
## importing outputs
## no centering
#####################

# Lee-Carter model




########################################
# interval score & coverage probability
########################################

country_female_score_cover = c("AUS_female_score_cover", "AUT_female_score_cover", "BEL_female_score_cover", 
                               "BGR_female_score_cover", "CAN_female_score_cover", "CZE_female_score_cover", 
                               "DEN_female_score_cover", "FIN_female_score_cover", "FRA_female_score_cover", 
                               "HUN_female_score_cover", "ICE_female_score_cover", "IRL_female_score_cover",
                               "ITA_female_score_cover", "JPN_female_score_cover", "NLD_female_score_cover", 
                               "NOR_female_score_cover", "NZ_female_score_cover",  "PRT_female_score_cover", 
                               "SPA_female_score_cover", "SVK_female_score_cover", "SWE_female_score_cover", 
                               "SWI_female_score_cover", "UK_female_score_cover",  "USA_female_score_cover")

country_male_score_cover = c("AUS_male_score_cover", "AUT_male_score_cover", "BEL_male_score_cover", 
                             "BGR_male_score_cover", "CAN_male_score_cover", "CZE_male_score_cover", 
                             "DEN_male_score_cover", "FIN_male_score_cover", "FRA_male_score_cover", 
                             "HUN_male_score_cover", "ICE_male_score_cover", "IRL_male_score_cover",
                             "ITA_male_score_cover", "JPN_male_score_cover", "NLD_male_score_cover", 
                             "NOR_male_score_cover", "NZ_male_score_cover",  "PRT_male_score_cover", 
                             "SPA_male_score_cover", "SVK_male_score_cover", "SWE_male_score_cover", 
                             "SWI_male_score_cover", "UK_male_score_cover",  "USA_male_score_cover")

country_total_score_cover = c("AUS_total_score_cover", "AUT_total_score_cover", "BEL_total_score_cover", 
                              "BGR_total_score_cover", "CAN_total_score_cover", "CZE_total_score_cover", 
                              "DEN_total_score_cover", "FIN_total_score_cover", "FRA_total_score_cover", 
                              "HUN_total_score_cover", "ICE_total_score_cover", "IRL_total_score_cover",
                              "ITA_total_score_cover", "JPN_total_score_cover", "NLD_total_score_cover", 
                              "NOR_total_score_cover", "NZ_total_score_cover",  "PRT_total_score_cover", 
                              "SPA_total_score_cover", "SVK_total_score_cover", "SWE_total_score_cover", 
                              "SWI_total_score_cover", "UK_total_score_cover",  "USA_total_score_cover")


all_country_female_score_cover = all_country_male_score_cover = all_country_total_score_cover = array(NA, dim = c(4, 6, length(country)))
for(ik in 1:length(country))
{
    all_country_female_score_cover[,,ik] = get(country_female_score_cover[ik])
    all_country_male_score_cover[,,ik]   = get(country_male_score_cover[ik])
    all_country_total_score_cover[,,ik]  = get(country_total_score_cover[ik])
}

#########
# fh = 1
#########

# interval score

all_country_score_h1 = cbind(t(all_country_female_score_cover[3:4,1,]), t(all_country_male_score_cover[3:4,1,]),
                                   t(all_country_total_score_cover[3:4,1,]))
all_country_score_h1_summary = rbind(all_country_score_h1, apply(all_country_score_h1, 2, median))
rownames(all_country_score_h1_summary) = c(country, "Median")
colnames(all_country_score_h1_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
require(xtable)
xtable(all_country_score_h1_summary * 100,  digits = 2)

# coverage probability deviance

all_country_cpd_h1 = abs(cbind(t(all_country_female_score_cover[3:4,2,]), t(all_country_male_score_cover[3:4,2,]),
                             t(all_country_total_score_cover[3:4,2,])) - 0.8)
all_country_cpd_h1_summary = rbind(all_country_cpd_h1, apply(all_country_cpd_h1, 2, median))
rownames(all_country_cpd_h1_summary) = c(country, "Median")
colnames(all_country_cpd_h1_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_cpd_h1_summary * 100, digits = 2)

#########
# fh = 5
#########

# interval score

all_country_score_h5 = cbind(t(all_country_female_score_cover[3:4,3,]), t(all_country_male_score_cover[3:4,3,]),
                             t(all_country_total_score_cover[3:4,3,]))
all_country_score_h5_summary = rbind(all_country_score_h5, apply(all_country_score_h5, 2, median))
rownames(all_country_score_h5_summary) = c(country, "Median")
colnames(all_country_score_h5_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_score_h5_summary * 100, digits = 2)

# coverage probability deviance

all_country_cpd_h5 = abs(cbind(t(all_country_female_score_cover[3:4,4,]), t(all_country_male_score_cover[3:4,4,]),
                               t(all_country_total_score_cover[3:4,4,])) - 0.8)
all_country_cpd_h5_summary = rbind(all_country_cpd_h5, apply(all_country_cpd_h5, 2, median))
rownames(all_country_cpd_h5_summary) = c(country, "Median")
colnames(all_country_cpd_h5_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_cpd_h5_summary * 100, digits = 2)

##########
# fh = 10
##########

# interval score

all_country_score_h10 = cbind(t(all_country_female_score_cover[3:4,5,]), t(all_country_male_score_cover[3:4,5,]),
                              t(all_country_total_score_cover[3:4,5,]))
all_country_score_h10_summary = rbind(all_country_score_h10, apply(all_country_score_h10, 2, median))
rownames(all_country_score_h10_summary) = c(country, "Median")
colnames(all_country_score_h10_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_score_h10_summary * 100, digits = 2)

# coverage probability deviance

all_country_cpd_h10 = abs(cbind(t(all_country_female_score_cover[3:4,6,]), t(all_country_male_score_cover[3:4,6,]),
                                t(all_country_total_score_cover[3:4,6,])) - 0.8)
all_country_cpd_h10_summary = rbind(all_country_cpd_h10, apply(all_country_cpd_h10, 2, median))
rownames(all_country_cpd_h10_summary) = c(country, "Median")
colnames(all_country_cpd_h10_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_cpd_h10_summary * 100, digits = 2)


###############
# FDM (fh = 1)
###############

# interval score

all_country_fdm_score_h1 = cbind(t(all_country_female_score_cover[1:2,1,]), t(all_country_male_score_cover[1:2,1,]),
                                 t(all_country_total_score_cover[1:2,1,]))
all_country_fdm_score_h1_summary = rbind(all_country_fdm_score_h1, apply(all_country_fdm_score_h1, 2, median))
rownames(all_country_fdm_score_h1_summary) = c(country, "Median")
colnames(all_country_fdm_score_h1_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_score_h1_summary * 100, digits = 2)

# coverage probability deviance

all_country_fdm_cpd_h1 = abs(cbind(t(all_country_female_score_cover[1:2,2,]), t(all_country_male_score_cover[1:2,2,]),
                                   t(all_country_total_score_cover[1:2,2,])) - 0.8)
all_country_fdm_cpd_h1_summary = rbind(all_country_fdm_cpd_h1, apply(all_country_fdm_cpd_h1, 2, median))
rownames(all_country_fdm_cpd_h1_summary) = c(country, "Median")
colnames(all_country_fdm_cpd_h1_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_cpd_h1_summary * 100, digits = 2)


###############
# FDM (fh = 5)
###############

# interval score

all_country_fdm_score_h5 = cbind(t(all_country_female_score_cover[1:2,3,]), t(all_country_male_score_cover[1:2,3,]),
                                 t(all_country_total_score_cover[1:2,3,]))
all_country_fdm_score_h5_summary = rbind(all_country_fdm_score_h5, apply(all_country_fdm_score_h5, 2, median))
rownames(all_country_fdm_score_h5_summary) = c(country, "Median")
colnames(all_country_fdm_score_h5_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_score_h5_summary * 100, digits = 2)

# coverage probability deviance

all_country_fdm_cpd_h5 = abs(cbind(t(all_country_female_score_cover[1:2,4,]), t(all_country_male_score_cover[1:2,4,]),
                                   t(all_country_total_score_cover[1:2,4,])) - 0.8)
all_country_fdm_cpd_h5_summary = rbind(all_country_fdm_cpd_h5, apply(all_country_fdm_cpd_h5, 2, median))
rownames(all_country_fdm_cpd_h5_summary) = c(country, "Median")
colnames(all_country_fdm_cpd_h5_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_cpd_h5_summary * 100, digits = 2)

################
# FDM (fh = 10)
################

# interval score

all_country_fdm_score_h10 = cbind(t(all_country_female_score_cover[1:2,5,]), t(all_country_male_score_cover[1:2,5,]),
                                  t(all_country_total_score_cover[1:2,5,]))
all_country_fdm_score_h10_summary = rbind(all_country_fdm_score_h10, apply(all_country_fdm_score_h10, 2, median))
rownames(all_country_fdm_score_h10_summary) = c(country, "Median")
colnames(all_country_fdm_score_h10_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_score_h10_summary * 100, digits = 2)

# coverage probability deviance

all_country_fdm_cpd_h10 = abs(cbind(t(all_country_female_score_cover[1:2,6,]), t(all_country_male_score_cover[1:2,6,]),
                                    t(all_country_total_score_cover[1:2,6,])) - 0.8)
all_country_fdm_cpd_h10_summary = rbind(all_country_fdm_cpd_h10, apply(all_country_fdm_cpd_h10, 2, median))
rownames(all_country_fdm_cpd_h10_summary) = c(country, "Median")
colnames(all_country_fdm_cpd_h10_summary) = c("DPCA", "PCA", "DPCA", "PCA", "DPCA", "PCA")
xtable(all_country_fdm_cpd_h10_summary * 100, digits = 2)




round(apply(all_country_female_score_cover, c(1, 2), mean), 4)
round(apply(all_country_male_score_cover, c(1, 2), mean), 4)
round(apply(all_country_total_score_cover, c(1, 2), mean), 4)

